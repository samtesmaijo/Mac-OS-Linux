#!/bin/sh
# macoslinux-ctl — controle central da interface Mac OS Linux.
# Cada subcomando executa uma ação REAL (sem efeitos decorativos) e registra
# falhas em ~/.cache/macoslinux/ui.log. Veja "macoslinux-ctl help".
# shellcheck source=/usr/lib/macoslinux/common.sh
. "${MACOSLINUX_LIB:-/usr/lib/macoslinux}/common.sh" || exit 1

PICOM_DIR=/etc/xdg/picom
TINT2_STATIC=/etc/xdg/tint2/macoslinux.tint2rc

notify() { # resumo [corpo]
    have notify-send || return 0
    notify-send -a macoslinux-ctl "$@" >/dev/null 2>&1
    return 0
}

osd() { # título [percentual] [ícone]
    have notify-send || return 0
    if [ -n "$2" ]; then
        notify-send -a macoslinux-osd -h string:x-dunst-stack-tag:ml-osd -h "int:value:$2" -i "${3:-macoslinux-audio}" "$1" >/dev/null 2>&1
    else
        notify-send -a macoslinux-osd -h string:x-dunst-stack-tag:ml-osd -i "${3:-macoslinux-audio}" "$1" >/dev/null 2>&1
    fi
    return 0
}

# ======================= aplicação de tema/efeitos =======================
apply_gtk() {
    f="${XDG_CONFIG_HOME:-$HOME/.config}/gtk-3.0/settings.ini"
    dark=0; [ "$(ml_theme)" = dark ] && dark=1
    mkdir -p "$(dirname "$f")" 2>/dev/null
    [ -f "$f" ] || printf '[Settings]\n' >"$f"
    if grep -q '^gtk-theme-name=' "$f"; then
        sed -i 's/^gtk-theme-name=.*/gtk-theme-name=MacOSLinux/' "$f"
    else
        printf 'gtk-theme-name=MacOSLinux\n' >>"$f"
    fi
    if grep -q '^gtk-application-prefer-dark-theme=' "$f"; then
        sed -i "s/^gtk-application-prefer-dark-theme=.*/gtk-application-prefer-dark-theme=$dark/" "$f"
    else
        printf 'gtk-application-prefer-dark-theme=%s\n' "$dark" >>"$f"
    fi
}

apply_openbox() {
    have openbox || return 0
    rc="${XDG_CONFIG_HOME:-$HOME/.config}/openbox/rc.xml"
    [ -f "$rc" ] || return 0
    if [ "$(ml_theme)" = light ]; then name=MacOSLinux-Light; else name=MacOSLinux-Dark; fi
    sed -i "s|<name>MacOSLinux-[A-Za-z]*</name>|<name>$name</name>|" "$rc"
    [ -n "$DISPLAY" ] && openbox --reconfigure >/dev/null 2>&1
    return 0
}

apply_wallpaper() {
    [ -n "$DISPLAY" ] || return 0
    wp=$(ml_get WALLPAPER "")
    if [ -z "$wp" ] || [ ! -r "$wp" ]; then
        wp=$(sed -n 's/^THEME_WALLPAPER="\(.*\)"$/\1/p' "$ML_SHARE/themes/$(ml_theme).conf" 2>/dev/null)
    fi
    if have feh && [ -r "$wp" ]; then
        feh --no-fehbg --bg-fill "$wp" 2>/dev/null && return 0
        ml_log "wallpaper: feh falhou com $wp"
    fi
    have xsetroot && xsetroot -solid '#14161d' 2>/dev/null
    return 0
}

start_picom() {
    have picom || { ml_log "picom: não instalado"; return 0; }
    [ -n "$DISPLAY" ] || return 0
    if [ "$(ml_motion)" = reduced ]; then first="$PICOM_DIR/macoslinux-lite.conf"
    elif [ "$(ml_bool BLUR 0)" = 1 ]; then first="$PICOM_DIR/macoslinux-blur.conf"
    else first="$PICOM_DIR/macoslinux.conf"; fi
    ml_stop picom
    # cadeia: perfil escolhido -> completo (sem desfoque) -> seguro -> sem compositor
    for cfg in "$first" "$PICOM_DIR/macoslinux.conf" "$PICOM_DIR/macoslinux-safe.conf"; do
        [ -r "$cfg" ] || continue
        ml_bg picom --config "$cfg"
        sleep 0.8
        if ml_running picom; then ml_log "picom: ok ($cfg)"; return 0; fi
        ml_log "picom: falhou com $cfg"
    done
    ml_log "picom: sem compositor — a sessão segue sem sombras/transparência"
    return 0
}

# Executa o tint2 sem poluir o log: a saída normal (inclui avisos repetitivos do Imlib2,
# a cada atualização de executor) é descartada; só se ele FALHAR ao iniciar é que o erro
# real é recuperado, filtrado e gravado no ui.log.
tint2_try() { # arquivo-de-configuração
    nohup tint2 -c "$1" >/dev/null 2>&1 </dev/null &
    sleep 0.8
    if ml_running tint2; then return 0; fi
    timeout 3 tint2 -c "$1" 2>&1 </dev/null | grep -v -E 'Imlib2|Developer Warning|parameter|being NULL|fix your program|^[[:space:]]*$|changes|^\s*image$' | head -n 6 |
        while IFS= read -r l; do ml_log "tint2: $l"; done
    return 1
}

start_tint2() {
    have tint2 || { ml_log "tint2: não instalado"; return 0; }
    [ -n "$DISPLAY" ] || { ml_log "tint2: sem DISPLAY"; return 0; }
    rc="$ML_CACHE_DIR/tint2.rc"
    ml_render "$ML_SHARE/templates/tint2.tpl" "$rc" || { ml_log "tint2: modelo falhou, usando configuração estática"; rc="$TINT2_STATIC"; }
    ml_stop tint2
    if tint2_try "$rc"; then ml_log "tint2: ok ($rc)"; return 0; fi
    ml_log "tint2: falhou com $rc"
    if [ "$rc" != "$TINT2_STATIC" ]; then
        if tint2_try "$TINT2_STATIC"; then ml_log "tint2: ok com configuração estática"; else ml_log "tint2: também falhou com a estática"; fi
    fi
    return 0
}

plank_defaults() { # garante o keyfile de preferências (homes criados antes do R4-UI)
    kf="${XDG_CONFIG_HOME:-$HOME/.config}/glib-2.0/settings/keyfile"
    [ -s "$kf" ] && grep -q 'net/launchpad/plank/docks/dock1' "$kf" 2>/dev/null && return 0
    mkdir -p "$(dirname "$kf")" 2>/dev/null
    cat >>"$kf" <<'KF'
[net/launchpad/plank/docks/dock1]
theme='MacOSLinux'
icon-size=46
zoom-enabled=true
zoom-percent=135
hide-mode='none'
position='bottom'
alignment='center'
items-alignment='center'
tooltips-enabled=true
show-dock-item=false
pressure-reveal=false
KF
}

plank_launchers() { # garante os atalhos do dock (homes antigos)
    d="${XDG_CONFIG_HOME:-$HOME/.config}/plank/dock1/launchers"
    [ -d "$d" ] && [ -n "$(ls "$d" 2>/dev/null)" ] && return 0
    [ -d /etc/skel/.config/plank/dock1/launchers ] || return 0
    mkdir -p "$d" && cp -n /etc/skel/.config/plank/dock1/launchers/* "$d"/ 2>/dev/null
    return 0
}

plank_prefs() { # reflete o estado (ui.conf) nas preferências do Plank
    have gsettings || return 0
    plank_defaults
    ml_plank_set theme "'MacOSLinux'"
    if [ "$(ml_bool DOCK_AUTOHIDE 0)" = 1 ]; then ml_plank_set hide-mode "'intelligent'"; else ml_plank_set hide-mode "'none'"; fi
    zoom=$(ml_bool DOCK_ZOOM 1)
    [ "$(ml_motion)" = reduced ] && zoom=0
    if [ "$zoom" = 1 ]; then ml_plank_set zoom-enabled true; else ml_plank_set zoom-enabled false; fi
    size=$(ml_get DOCK_SIZE 46)
    case "$size" in 36 | 46 | 56) ;; *) size=46 ;; esac
    ml_plank_set icon-size "$size"
    return 0
}

start_plank() {
    have plank || { ml_log "plank: não instalado"; return 0; }
    [ -n "$DISPLAY" ] || return 0
    plank_launchers
    plank_prefs
    ml_render "$ML_SHARE/templates/plank-dock.theme.tpl" \
        "${XDG_DATA_HOME:-$HOME/.local/share}/plank/themes/MacOSLinux/dock.theme" ||
        ml_log "plank: tema renderizado falhou; usa o tema do sistema"
    ml_stop plank
    ml_bg env GSETTINGS_BACKEND=keyfile plank
    sleep 0.6
    ml_running plank || ml_log "plank: não iniciou"
    return 0
}

start_dunst() {
    have dunst || { ml_log "dunst: não instalado"; return 0; }
    [ -n "$DISPLAY" ] || return 0
    rc="${XDG_CONFIG_HOME:-$HOME/.config}/dunst/dunstrc"
    ml_render "$ML_SHARE/templates/dunstrc.tpl" "$rc" || ml_log "dunst: modelo falhou; usa /etc/xdg/dunst/dunstrc"
    ml_stop dunst
    ml_bg dunst
    return 0
}

apply_all() {
    apply_gtk; apply_openbox; apply_wallpaper
    start_picom; start_tint2; start_plank; start_dunst
}

# ============================== subcomandos ==============================
cmd_theme() {
    case "$1" in
        dark | light) ml_set THEME "$1" ;;
        toggle) if [ "$(ml_theme)" = dark ]; then ml_set THEME light; else ml_set THEME dark; fi ;;
        *) echo "uso: macoslinux-ctl theme dark|light|toggle"; return 2 ;;
    esac
    apply_gtk; apply_openbox; apply_wallpaper; start_tint2; start_plank; start_dunst
}

cmd_transparency() {
    case "$1" in
        glass | reduced | solid) ml_set TRANSPARENCY "$1" ;;
        *) echo "uso: macoslinux-ctl transparency glass|reduced|solid"; return 2 ;;
    esac
    start_tint2; start_plank; start_dunst
}

cmd_motion() {
    case "$1" in
        full | reduced) ml_set MOTION "$1" ;;
        toggle) if [ "$(ml_motion)" = full ]; then ml_set MOTION reduced; else ml_set MOTION full; fi ;;
        *) echo "uso: macoslinux-ctl motion full|reduced|toggle"; return 2 ;;
    esac
    start_picom; start_plank
}

cmd_blur() {
    case "$1" in
        on) ml_set BLUR 1 ;;
        off) ml_set BLUR 0 ;;
        toggle) if [ "$(ml_bool BLUR 0)" = 1 ]; then ml_set BLUR 0; else ml_set BLUR 1; fi ;;
        *) echo "uso: macoslinux-ctl blur on|off|toggle   (experimental: pesado em hardware antigo)"; return 2 ;;
    esac
    start_picom
}

cmd_dock() {
    what="$1"; val="$2"
    case "$what" in
        autohide | zoom)
            key=DOCK_AUTOHIDE; [ "$what" = zoom ] && key=DOCK_ZOOM
            case "$val" in
                on) ml_set "$key" 1 ;;
                off) ml_set "$key" 0 ;;
                toggle) if [ "$(ml_bool "$key" 0)" = 1 ]; then ml_set "$key" 0; else ml_set "$key" 1; fi ;;
                *) echo "uso: macoslinux-ctl dock $what on|off|toggle"; return 2 ;;
            esac ;;
        size)
            case "$val" in 36 | 46 | 56) ml_set DOCK_SIZE "$val" ;; *) echo "uso: macoslinux-ctl dock size 36|46|56"; return 2 ;; esac ;;
        *) echo "uso: macoslinux-ctl dock autohide|zoom|size ..."; return 2 ;;
    esac
    plank_prefs
}

cmd_volume() {
    case "$1" in
        up)
            if have wpctl && wpctl get-volume @DEFAULT_AUDIO_SINK@ >/dev/null 2>&1; then
                wpctl set-mute @DEFAULT_AUDIO_SINK@ 0 2>/dev/null
                wpctl set-volume -l 1.0 @DEFAULT_AUDIO_SINK@ 5%+ 2>/dev/null
            elif have pactl; then
                pactl set-sink-mute @DEFAULT_SINK@ 0; cur=$(ml_vol_get | cut -d' ' -f1)
                if [ "${cur:-0}" -ge 95 ]; then pactl set-sink-volume @DEFAULT_SINK@ 100%; else pactl set-sink-volume @DEFAULT_SINK@ +5%; fi
            else notify "Som indisponível" "Nenhum servidor de áudio encontrado."; return 1; fi ;;
        down)
            if have wpctl && wpctl get-volume @DEFAULT_AUDIO_SINK@ >/dev/null 2>&1; then wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%- 2>/dev/null
            elif have pactl; then pactl set-sink-volume @DEFAULT_SINK@ -5%
            else notify "Som indisponível" "Nenhum servidor de áudio encontrado."; return 1; fi ;;
        mute)
            if have wpctl && wpctl get-volume @DEFAULT_AUDIO_SINK@ >/dev/null 2>&1; then wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle 2>/dev/null
            elif have pactl; then pactl set-sink-mute @DEFAULT_SINK@ toggle
            else notify "Som indisponível" "Nenhum servidor de áudio encontrado."; return 1; fi ;;
        set)
            case "$2" in '' | *[!0-9]*) echo "uso: macoslinux-ctl volume set 0-100"; return 2 ;; esac
            [ "$2" -gt 100 ] && set -- set 100
            if have wpctl && wpctl get-volume @DEFAULT_AUDIO_SINK@ >/dev/null 2>&1; then wpctl set-mute @DEFAULT_AUDIO_SINK@ 0; wpctl set-volume @DEFAULT_AUDIO_SINK@ "$2%"
            elif have pactl; then pactl set-sink-mute @DEFAULT_SINK@ 0; pactl set-sink-volume @DEFAULT_SINK@ "$2%"
            else return 1; fi ;;
        get) ml_vol_get; return $? ;;
        *) echo "uso: macoslinux-ctl volume up|down|mute|set N|get"; return 2 ;;
    esac
    st=$(ml_vol_get) || return 1
    v=${st% *}; m=${st#* }
    if [ "$m" = muted ]; then osd "Som desativado" "0"; else osd "Volume" "$v"; fi
}

cmd_output() { # define a saída de áudio padrão pelo nome do sink
    have pactl || return 1
    [ -n "$1" ] || { echo "uso: macoslinux-ctl output NOME_DO_SINK"; return 2; }
    pactl set-default-sink "$1" 2>/dev/null || { notify "Saída de áudio" "Não foi possível trocar para $1."; return 1; }
    # move reproduções em andamento para a nova saída
    pactl list short sink-inputs 2>/dev/null | cut -f1 | while read -r id; do pactl move-sink-input "$id" "$1" 2>/dev/null; done
    osd "Saída de áudio alterada" ""
}

backlight_dev() { # primeiro dispositivo de backlight, se houver
    for d in /sys/class/backlight/*; do
        [ -e "$d/brightness" ] && { printf '%s' "$d"; return 0; }
    done
    return 1
}

cmd_brightness() {
    dev=$(backlight_dev)
    if [ -z "$dev" ] || ! have brightnessctl; then
        notify "Brilho" "Este computador não expõe controle de brilho (normal em desktops)."
        return 1
    fi
    case "$1" in
        up) brightnessctl -q set 10%+ ;;
        down) brightnessctl -q set 10%- ;;
        get) brightnessctl -m 2>/dev/null | cut -d, -f4; return 0 ;;
        *) echo "uso: macoslinux-ctl brightness up|down|get"; return 2 ;;
    esac
    osd "Brilho" "$(brightnessctl -m 2>/dev/null | cut -d, -f4 | tr -d '%')" display-brightness
}

cmd_wifi() {
    have nmcli || { notify "Wi-Fi" "NetworkManager não encontrado."; return 1; }
    case "$1" in
        on | off) nmcli radio wifi "$1" 2>/dev/null ;;
        toggle) if [ "$(LC_ALL=C nmcli radio wifi 2>/dev/null)" = enabled ]; then nmcli radio wifi off 2>/dev/null; else nmcli radio wifi on 2>/dev/null; fi ;;
        *) echo "uso: macoslinux-ctl wifi on|off|toggle"; return 2 ;;
    esac || notify "Wi-Fi" "Não foi possível alterar o estado do Wi-Fi."
    osd "Wi-Fi: $(if [ "$(LC_ALL=C nmcli radio wifi 2>/dev/null)" = enabled ]; then echo ligado; else echo desligado; fi)" "" macoslinux-network
}

cmd_wifi_connect() { # SSID
    have nmcli || return 1
    ssid="$1"; [ -n "$ssid" ] || return 2
    if LC_ALL=C nmcli -t -f NAME connection show 2>/dev/null | grep -Fxq -- "$ssid"; then
        nmcli connection up id "$ssid" >/dev/null 2>&1 && { osd "Conectado a $ssid" "" macoslinux-network; return 0; }
    fi
    sec=$(LC_ALL=C nmcli -t -f SSID,SECURITY device wifi list 2>/dev/null | awk -F: -v s="$ssid" '$1==s {print $2; exit}')
    if [ -z "$sec" ] || [ "$sec" = "--" ]; then
        nmcli device wifi connect "$ssid" >/dev/null 2>&1 && { osd "Conectado a $ssid" "" macoslinux-network; return 0; }
    fi
    # rede protegida e desconhecida: nmtui pede a senha no terminal
    if have nmtui-connect; then
        if have macoslinux-terminal; then macoslinux-terminal -e nmtui-connect "$ssid" & else lxterminal -e nmtui-connect "$ssid" & fi
    else notify "Wi-Fi" "Abra 'Rede' no Dock para informar a senha de $ssid."; fi
}

cmd_dnd() {
    have dunstctl || { notify "Não perturbe" "dunst não encontrado."; return 1; }
    case "$1" in
        on) dunstctl set-paused true ;;
        off) dunstctl set-paused false ;;
        toggle) dunstctl set-paused toggle ;;
        *) echo "uso: macoslinux-ctl dnd on|off|toggle"; return 2 ;;
    esac
    [ "$(dunstctl is-paused 2>/dev/null)" = true ] || osd "Não perturbe desligado" "" macoslinux-control-center
}

cmd_screenshot() {
    have scrot || { notify "Captura de tela" "scrot não está instalado."; return 1; }
    dir="$HOME/Imagens"; [ -d "$dir" ] || dir="$HOME/Pictures"
    mkdir -p "$dir" 2>/dev/null
    f="$dir/Captura-$(date +%Y%m%d-%H%M%S).png"
    case "$1" in
        area) scrot -s -f "$f" 2>/dev/null ;;
        *) scrot "$f" 2>/dev/null ;;
    esac && [ -f "$f" ] && notify "Captura salva" "$f"
}

cmd_menu() { # abre superfícies GTK ou menus Openbox legados
    case "$1" in
        system | settings)
            have macoslinux-settings || { ml_log "settings: GTK Settings não instalado"; return 1; }
            macoslinux-settings "${2:-appearance}" >/dev/null 2>&1 &
            ;;
        apps | apps-here)
            have macoslinux-launcher || { ml_log "launcher: GTK Launcher não instalado"; return 1; }
            macoslinux-launcher >/dev/null 2>&1 &
            ;;
        control)
            have macoslinux-control-center || { ml_log "control-center: GTK Control Center não instalado"; return 1; }
            macoslinux-control-center >/dev/null 2>&1 &
            ;;
        file | window | help)
            case "$1" in file) k=super+alt+f ;; window) k=super+alt+w ;; help) k=super+alt+h ;; esac
            have xdotool || { ml_log "menu: xdotool ausente"; return 1; }
            if [ "$1" = file ]; then
                eval "$(xdotool getmouselocation --shell 2>/dev/null)"
                [ -n "$X" ] && [ "${Y:-0}" -lt 29 ] && xdotool mousemove "$X" 29
            fi
            xdotool key --clearmodifiers "$k"
            ;;
        *) echo "uso: macoslinux-ctl menu system|settings|file|window|help|apps|control"; return 2 ;;
    esac
}

cmd_power() {
    case "$1" in
        logout) openbox --exit ;;
        reboot) systemctl reboot 2>/dev/null || sudo -n systemctl reboot 2>/dev/null || notify "Reiniciar" "Sem permissão para reiniciar." ;;
        poweroff) systemctl poweroff 2>/dev/null || sudo -n systemctl poweroff 2>/dev/null || notify "Desligar" "Sem permissão para desligar." ;;
        *) echo "uso: macoslinux-ctl power logout|reboot|poweroff"; return 2 ;;
    esac
}

cmd_status() {
    theme=$(ml_theme)
    case "$1" in
        volume)
            if st=$(ml_vol_get); then
                v=${st% *}; m=${st#* }
                if [ "$m" = muted ] || [ "$v" -eq 0 ]; then icon=vol-mute; elif [ "$v" -lt 50 ]; then icon=vol-low; else icon=vol-high; fi
                printf '%s\n' "$ML_SHARE/status/$theme/$icon.png"
                if [ "$m" = muted ]; then echo "mudo"; else printf '%s%%\n' "$v"; fi
            else
                printf '%s\n' "$ML_SHARE/status/$theme/vol-mute.png"
            fi ;;
        network)
            out=""
            have nmcli && out=$(LC_ALL=C timeout 3 nmcli -t -f TYPE,STATE device 2>/dev/null)
            if printf '%s\n' "$out" | grep -q '^ethernet:connected'; then icon=net-wired
            elif printf '%s\n' "$out" | grep -q '^wifi:connected'; then icon=net-wifi
            else icon=net-off; fi
            printf '%s\n' "$ML_SHARE/status/$theme/$icon.png" ;;
        *) echo "uso: macoslinux-ctl status volume|network"; return 2 ;;
    esac
}

cmd_about() {
    v=$(head -n 1 "$ML_SHARE/BUILD-STATUS.txt" 2>/dev/null)
    mem=$(awk '/MemTotal/ {printf "%.1f GiB", $2/1048576}' /proc/meminfo 2>/dev/null)
    notify "Sobre o Mac OS Linux" "${v:-Mac OS Linux}\nKernel $(uname -r)\nMemória $mem\nBase: Debian 13 (Trixie)\nTema: $(ml_theme)"
}

cmd_shortcuts() {
    f="$ML_SHARE/ATALHOS.txt"
    [ -r "$f" ] || return 1
    if have macoslinux-terminal; then macoslinux-terminal -e less "$f" &
    elif have lxterminal; then lxterminal -e less "$f" &
    else notify "Atalhos" "Veja $f"; fi
}

cmd_doctor() {
    echo "== Mac OS Linux — diagnóstico da interface"
    echo "tema=$(ml_theme) transparência=$(ml_transparency) movimento=$(ml_motion) desfoque=$(ml_bool BLUR 0) autohide=$(ml_bool DOCK_AUTOHIDE 0) zoom=$(ml_bool DOCK_ZOOM 1)"
    echo "DISPLAY=${DISPLAY:-?} DBUS=${DBUS_SESSION_BUS_ADDRESS:+definido} XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-?}"
    echo "-- componentes"
    for p in openbox picom tint2 plank dunst pipewire wireplumber pipewire-pulse; do
        if ml_running "$p"; then printf '  %-15s rodando (RSS %s KiB)\n' "$p" "$(ps -u "$(id -u)" -o rss=,comm= | awk -v n="$p" '$2==n {print $1; exit}')"; else printf '  %-15s PARADO\n' "$p"; fi
    done
    echo "-- ferramentas"
    for c in feh xdotool notify-send wpctl pactl nmcli brightnessctl scrot xprop gsettings; do
        if have "$c"; then printf '  %-15s ok\n' "$c"; else printf '  %-15s ausente\n' "$c"; fi
    done
    echo "-- últimas linhas do log ($ML_LOG)"
    tail -n 15 "$ML_LOG" 2>/dev/null || echo "  (vazio)"
}

cmd_help() {
    cat <<'TXT'
macoslinux-ctl — controle da interface
  theme dark|light|toggle        modo escuro/claro (Openbox, barra, dock, notificações, wallpaper)
  transparency glass|reduced|solid
  motion full|reduced|toggle     reduz fade/zoom/cantos (modo leve do compositor)
  blur on|off|toggle             desfoque do vidro (EXPERIMENTAL; pesado em hardware antigo)
  dock autohide|zoom on|off|toggle   |   dock size 36|46|56
  volume up|down|mute|set N|get  |   output NOME_DO_SINK
  brightness up|down|get         (só quando há backlight)
  wifi on|off|toggle  |  dnd on|off|toggle
  screenshot full|area
  menu system|settings|file|window|help|apps|control
  apply all|gtk|openbox|wallpaper|picom|tint2|plank|dunst  |  restart-ui
  power logout|reboot|poweroff  |  doctor  |  about  |  shortcuts
TXT
}

c="$1"; [ "$#" -gt 0 ] && shift
case "$c" in
    theme) cmd_theme "$@" ;;
    transparency) cmd_transparency "$@" ;;
    motion) cmd_motion "$@" ;;
    dock) cmd_dock "$@" ;;
    blur) cmd_blur "$@" ;;
    volume) cmd_volume "$@" ;;
    output) cmd_output "$@" ;;
    brightness) cmd_brightness "$@" ;;
    wifi) cmd_wifi "$@" ;;
    wifi-connect) cmd_wifi_connect "$@" ;;
    dnd) cmd_dnd "$@" ;;
    screenshot) cmd_screenshot "$@" ;;
    menu) cmd_menu "$@" ;;
    power) cmd_power "$@" ;;
    status) cmd_status "$@" ;;
    about) cmd_about ;;
    shortcuts) cmd_shortcuts ;;
    doctor) cmd_doctor ;;
    apply)
        case "$1" in
            all | "") apply_all ;;
            gtk) apply_gtk ;; openbox) apply_openbox ;; wallpaper) apply_wallpaper ;;
            picom) start_picom ;; tint2) start_tint2 ;; plank) start_plank ;; dunst) start_dunst ;;
            *) echo "uso: macoslinux-ctl apply all|gtk|openbox|wallpaper|picom|tint2|plank|dunst"; exit 2 ;;
        esac ;;
    restart-ui) apply_all ;;
    start-picom) start_picom ;; start-tint2) start_tint2 ;; start-plank) start_plank ;; start-dunst) start_dunst ;;
    help | -h | --help | "") cmd_help ;;
    *) echo "macoslinux-ctl: subcomando desconhecido: $c"; cmd_help; exit 2 ;;
esac
