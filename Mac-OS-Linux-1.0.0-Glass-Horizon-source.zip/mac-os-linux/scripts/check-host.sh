#!/usr/bin/env bash
set -Eeuo pipefail

# Read-only inspection for the Debian live-build workflow.
# This script does not install packages, change settings, or modify disks.

section() { printf '\n\033[1m%s\033[0m\n' "$1"; }
status() { printf '  %-28s %s\n' "$1" "$2"; }

section "Mac OS Linux — build host report"
printf '  Date:       %s\n' "$(date -Is 2>/dev/null || date)"
printf '  Hostname:   %s\n' "$(hostname 2>/dev/null || printf unknown)"
printf '  OS:         %s\n' "$(. /etc/os-release 2>/dev/null; printf '%s %s' "${NAME:-unknown}" "${VERSION_ID:-}")"
printf '  Kernel:     %s\n' "$(uname -sr)"
printf '  Machine:    %s\n' "$(uname -m)"

section "Processor and memory"
cores=$(getconf _NPROCESSORS_ONLN 2>/dev/null || nproc 2>/dev/null || printf 0)
cpu_model=$(awk -F: '/model name/ {sub(/^[[:space:]]+/, "", $2); print $2; exit}' /proc/cpuinfo 2>/dev/null || true)
mem_kib=$(awk '/MemTotal:/ {print $2}' /proc/meminfo 2>/dev/null || printf 0)
mem_gib=$(awk -v k="$mem_kib" 'BEGIN { if (k > 0) printf "%.1f GiB", k/1048576; else print "unknown" }')
status "CPU model" "${cpu_model:-unknown}"
status "Logical CPU cores" "$cores"
status "Installed RAM" "$mem_gib"
if [[ "$cores" =~ ^[0-9]+$ ]] && (( cores < 2 )); then
  status "Build profile" "VERY LIMITED CPU; build only when idle"
elif [[ "$mem_kib" =~ ^[0-9]+$ ]] && (( mem_kib < 3*1024*1024 )); then
  status "Build profile" "LOW MEMORY; keep image small and close other apps"
else
  status "Build profile" "Suitable for a modest live-build test; monitor memory"
fi

section "Graphics"
if command -v lspci >/dev/null 2>&1; then
  gpu_line=$(lspci -nn 2>/dev/null | grep -Ei 'VGA|3D|Display' | head -n 1 || true)
  status "GPU" "${gpu_line:-not detected}"
  driver_line=$(lspci -nnk 2>/dev/null | awk '/VGA|3D|Display/ {found=1} found && /Kernel driver in use:/ {sub(/^.*Kernel driver in use: /, ""); print; exit}' || true)
  status "Kernel graphics driver" "${driver_line:-not detected}"
else
  status "GPU" "lspci unavailable (install pciutils to inspect)"
fi

section "Available disk space"
df -hP . 2>/dev/null | awk 'NR==1 {print "  " $0} NR==2 {print "  " $0}' || true

section "Live-build host tools"
required=(lb debootstrap xorriso mksquashfs unsquashfs grub-mkrescue)
missing=0
for cmd in "${required[@]}"; do
  if command -v "$cmd" >/dev/null 2>&1; then
    status "$cmd" "FOUND: $(command -v "$cmd")"
  else
    status "$cmd" "MISSING"
    missing=$((missing + 1))
  fi
done

section "Build safety"
status "Running as root" "$([[ $EUID -eq 0 ]] && printf yes || printf no)"
if command -v swapon >/dev/null 2>&1; then
  swap_info=$(swapon --show --noheadings --bytes 2>/dev/null | awk '{sum += $3} END {if (sum > 0) printf "%.1f GiB", sum/1073741824; else print "none active"}')
  status "Active swap" "$swap_info"
else
  status "Active swap" "swapon unavailable"
fi

section "Summary"
if [[ "$(uname -m)" != "x86_64" ]]; then
  printf '  WARNING: this project targets amd64; this host reports %s.\n' "$(uname -m)"
fi
if (( missing > 0 )); then
  printf '  %s required command(s) are missing. Check package availability before installing.\n' "$missing"
else
  printf '  Required live-build commands are present. Tool versions still need validation.\n'
fi
printf '\n  This is a read-only preliminary check, not a complete live-build validation.\n'
printf '  No packages, files outside the project, partitions, boot settings, or system settings were changed.\n'
