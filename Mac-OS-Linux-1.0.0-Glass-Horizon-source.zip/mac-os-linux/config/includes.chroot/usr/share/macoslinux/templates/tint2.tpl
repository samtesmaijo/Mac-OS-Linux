# Mac OS Linux — barra superior (Tint2 17). Tema: @THEME_NAME@. Transparência: @ALPHA@%.
# GERADO a partir de templates/tint2.tpl por macoslinux-ctl. Não edite o resultado.
#
# NOTA TÉCNICA (verificada no tint2 17.0.1 do Trixie): itens de texto e de ícone
# são EXECUTORES (execp = new). O bloco "button = new" com button_text NÃO é
# renderizado por esta versão, por isso a barra inteira usa execp.

# ---- Fundo 1: painel (vidro translúcido + fio de realce inferior)
rounded = 0
border_width = 1
border_sides = B
background_color = @THEME_BAR_BG@ @ALPHA@
border_color = @THEME_BAR_HI@ 18

# ---- Fundo 2: tooltip
rounded = 7
border_width = 1
background_color = @THEME_TOOLTIP_BG@ 97
border_color = @THEME_MENU_BORDER@ 100

# ---- Fundo 3: itens clicáveis (hover/pressionado discretos)
rounded = 6
border_width = 0
background_color = @THEME_BAR_HOVER@ 0
border_color = @THEME_BAR_HOVER@ 0
background_color_hover = @THEME_BAR_HOVER@ 18
border_color_hover = @THEME_BAR_HOVER@ 0
background_color_pressed = @THEME_BAR_HOVER@ 30
border_color_pressed = @THEME_BAR_HOVER@ 0

# ---- Fundo 4: texto estático (sem hover)
rounded = 0
border_width = 0
background_color = #000000 0
border_color = #000000 0

# ---- Painel
# E logo | E app ativo | E Arquivo | E Janela | E Ajuda | T (espaçador) | E volume | E rede | S bandeja | C relógio | E controle
panel_items = EEEEETEESCE
panel_monitor = all
panel_position = top center horizontal
panel_size = 100% 28
panel_margin = 0 0
panel_padding = 6 0 6
panel_dock = 0
panel_layer = top
panel_background_id = 1
panel_window_name = macoslinux-topbar
disable_transparency = 0
mouse_left = none
mouse_middle = none
mouse_right = none
mouse_scroll_up = none
mouse_scroll_down = none

# ---- 1) Logotipo (ícone) -> menu do sistema
execp = new
execp_command = /usr/bin/macoslinux-status logo @THEME_NAME@
execp_interval = 0
execp_has_icon = 1
execp_icon_w = 18
execp_icon_h = 18
execp_cache_icon = 1
execp_padding = 9 3
execp_background_id = 3
execp_centered = 1
execp_tooltip = Mac OS Linux
execp_lclick_command = macoslinux-ctl menu settings
execp_rclick_command = macoslinux-ctl menu apps

# ---- 2) Aplicativo ativo (texto, orientado a evento)
execp = new
execp_command = macoslinux-active-app
execp_continuous = 1
execp_interval = 0
execp_font = Inter Bold 10
execp_font_color = @THEME_TEXT@ 100
execp_padding = 8 3
execp_background_id = 4
execp_centered = 0

# ---- 3) Arquivo
execp = new
execp_command = printf 'Arquivo'
execp_font = Inter 10
execp_font_color = @THEME_TEXT@ 100
execp_padding = 8 3
execp_background_id = 3
execp_centered = 1
execp_lclick_command = macoslinux-ctl menu file

# ---- 4) Janela
execp = new
execp_command = printf 'Janela'
execp_font = Inter 10
execp_font_color = @THEME_TEXT@ 100
execp_padding = 8 3
execp_background_id = 3
execp_centered = 1
execp_lclick_command = macoslinux-ctl menu window

# ---- 5) Ajuda
execp = new
execp_command = printf 'Ajuda'
execp_font = Inter 10
execp_font_color = @THEME_TEXT@ 100
execp_padding = 8 3
execp_background_id = 3
execp_centered = 1
execp_lclick_command = macoslinux-ctl menu help

# ---- 6) Volume (ícone + %), rolar a roda ajusta, clique abre o Centro de Controle
execp = new
execp_command = macoslinux-ctl status volume
execp_interval = 4
execp_has_icon = 1
execp_icon_w = 18
execp_icon_h = 18
execp_cache_icon = 1
execp_font = Inter 10
execp_font_color = @THEME_TEXT@ 100
execp_padding = 7 3
execp_background_id = 3
execp_centered = 1
execp_tooltip = Volume (rolar para ajustar, clicar para o Centro de Controle)
execp_lclick_command = macoslinux-control-center
execp_mclick_command = macoslinux-ctl volume mute
execp_uwheel_command = macoslinux-ctl volume up
execp_dwheel_command = macoslinux-ctl volume down

# ---- 7) Rede (somente ícone)
execp = new
execp_command = macoslinux-ctl status network
execp_interval = 8
execp_has_icon = 1
execp_icon_w = 18
execp_icon_h = 18
execp_cache_icon = 1
execp_padding = 7 3
execp_background_id = 3
execp_centered = 1
execp_tooltip = Rede (clicar para o Centro de Controle)
execp_lclick_command = macoslinux-control-center

# ---- 8) Bandeja do sistema
systray_padding = 6 0 4
systray_background_id = 0
systray_sort = ascending
systray_icon_size = 18
systray_icon_asb = 100 0 0

# ---- 9) Relógio (clique mostra o calendário)
time1_format = %a %d %b  %H:%M
time1_font = Inter 10
clock_font_color = @THEME_TEXT@ 100
clock_padding = 8 3
clock_background_id = 3
clock_tooltip = %A, %d de %B de %Y
clock_lclick_command = macoslinux-calendar

# ---- 10) Centro de Controle (ícone)
execp = new
execp_command = /usr/bin/macoslinux-status control @THEME_NAME@
execp_interval = 0
execp_has_icon = 1
execp_icon_w = 18
execp_icon_h = 18
execp_cache_icon = 1
execp_padding = 9 3
execp_background_id = 3
execp_centered = 1
execp_tooltip = Centro de Controle
execp_lclick_command = macoslinux-control-center

# ---- Espaçador: a "barra de tarefas" não mostra nenhuma tarefa (o Dock cuida disso);
# ela só se expande para empurrar os itens da direita até a borda.
taskbar_mode = multi_desktop
taskbar_padding = 0 0 0
taskbar_background_id = 0
taskbar_active_background_id = 0
taskbar_name = 0
task_text = 0
task_icon = 0
task_maximum_size = 1 1
task_padding = 0 0 0
task_background_id = 0
task_active_background_id = 0
task_urgent_background_id = 0
task_iconified_background_id = 0

# ---- Tooltips
tooltip_show_timeout = 0.6
tooltip_hide_timeout = 0.1
tooltip_padding = 8 5
tooltip_background_id = 2
tooltip_font = Inter 9
tooltip_font_color = @THEME_TEXT@ 100
