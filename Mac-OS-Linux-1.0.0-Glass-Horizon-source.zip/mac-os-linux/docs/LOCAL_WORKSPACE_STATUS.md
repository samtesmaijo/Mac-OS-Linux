# Estado do pacote fonte Mac OS Linux 1.0.0

Esta árvore é uma atualização do fonte UI R1 para a versão 1.0.0 / Glass Horizon. Ela mantém Debian 13 Trixie amd64, Live-Build, Xorg, Openbox, Tint2, Plank, Picom/XRender e dunst.

## Estado confirmado pelo usuário

- A ISO 0.1.0 anterior foi gerada com Live-Build e reconhecida como ISO híbrida.
- O relatório `xorriso` confirmou entrada El Torito BIOS/ISOLINUX e UEFI/GRUB, além da estrutura MBR híbrida.
- O usuário confirmou que a imagem iniciou no Core 2 Duo E7500 / Intel G41 e que a sessão gráfica apareceu.
- O usuário avaliou a interface R1 como insuficientemente semelhante ao estilo visual desejado e apontou falta de um app Configurações e um Centro de Controle visualmente melhor.

## Alterações fonte 1.0.0 nesta árvore

- `apps/macoslinux-ui.c`: aplicação GTK3 em C com modos `--control`, `--settings` e `--launcher`.
- Wrappers `macoslinux-control-center`, `macoslinux-settings` e `macoslinux-launcher` chamam o executável nativo único `macoslinux-ui-native`.
- `config/includes.chroot/usr/share/themes/MacOSLinux/`: tema GTK3 original claro/escuro.
- Arquivos `.desktop`, launcher Plank e atalhos Openbox atualizados.
- `macoslinux-ctl` continua responsável pelas ações reais no sistema, agora com Bluetooth via `rfkill`.
- Launcher de aplicativos com busca, baseado em GIO e arquivos `.desktop`.
- Live-Build modernizado para opções usadas com Debian Trixie.
- `NO_X=1 sh scripts/test-interface.sh`: 72 aprovações, zero falhas e cinco verificações ignoradas por dependências opcionais/ausência de X.


## Limitações honestas

- O ZIP original não continha a ISO compilada nem o `chroot` local.
- A aplicação C/GTK3 ainda precisa ser compilada no host Zorin com `build-essential`, `pkg-config` e `libgtk-3-dev`.
- O ambiente de preparação não tinha os headers GTK3; portanto, não foi possível compilar/executar o binário aqui.
- A nova ISO 1.0.0 ainda não foi construída nem testada em hardware real.
- Não foram criados novos ícones/logos de apps nesta revisão; essa é a fase visual seguinte.
