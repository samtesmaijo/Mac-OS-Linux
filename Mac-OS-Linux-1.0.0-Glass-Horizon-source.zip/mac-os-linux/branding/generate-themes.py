#!/usr/bin/env python3
"""Gera os temas do Mac OS Linux a partir de UMA tabela de cores (tokens).

Saídas (todas estáticas, versionadas em config/includes.chroot):
  usr/share/themes/MacOSLinux-{Dark,Light}/openbox-3/themerc
  usr/share/macoslinux/themes/{dark,light}.conf   (shell-sourceable; lido em runtime)

Ferramenta de BUILD apenas. Para mudar cores: edite TOKENS e rode
    python3 branding/generate-themes.py
Não há dependência além da biblioteca padrão do Python.
"""
import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
INC = os.path.join(ROOT, "config", "includes.chroot")

TOKENS = {
    "dark": {
        "NAME": "dark", "LABEL": "Escuro", "OB_THEME": "MacOSLinux-Dark", "PLANK_THEME": "MacOSLinux",
        "WALLPAPER": "/usr/share/macoslinux/wallpapers/aurora-dark.jpg",
        "LOGO": "/usr/share/macoslinux/logo/macoslinux-bar-dark-22.png",
        "GTK_DARK": "1",
        # superfícies "vidro"
        "BAR_BG": "#14161d", "BAR_HI": "#ffffff", "BAR_HOVER": "#ffffff",
        "TEXT": "#f3f5f9", "TEXT_DIM": "#a9afbd", "ACCENT": "#5aa9ff", "ACCENT_TEXT": "#ffffff",
        "DOCK_TOP": "#2c303c", "DOCK_BOT": "#171a22",
        "TOOLTIP_BG": "#1b1e26", "NOTIF_BG": "#1b1e26", "NOTIF_FRAME": "#3b4050", "NOTIF_LOW": "#6e7587",
        # menus
        "MENU_BG": "#1b1e26", "MENU_BORDER": "#3b4050", "MENU_SEP": "#343948", "MENU_TEXT": "#eef0f5",
        "MENU_TEXT_DIS": "#6e7587", "MENU_TITLE_BG": "#171a21", "MENU_TITLE_TEXT": "#8f96a8",
        # janelas
        "WIN_TITLE_TOP": "#3b3f4d", "WIN_TITLE_BOT": "#2f323e",
        "WIN_TITLE_IN_TOP": "#2b2e38", "WIN_TITLE_IN_BOT": "#262932",
        "WIN_TEXT": "#f2f4f8", "WIN_TEXT_IN": "#8a90a0",
        "WIN_BORDER": "#0c0d11", "WIN_BORDER_IN": "#15171c", "WIN_SEP": "#171920",
        "WIN_CLIENT": "#2f323e", "WIN_CLIENT_IN": "#262932",
        "DOT_OFF": "#4b505e",
    },
    "light": {
        "NAME": "light", "LABEL": "Claro", "OB_THEME": "MacOSLinux-Light", "PLANK_THEME": "MacOSLinux",
        "WALLPAPER": "/usr/share/macoslinux/wallpapers/aurora-light.jpg",
        "LOGO": "/usr/share/macoslinux/logo/macoslinux-bar-light-22.png",
        "GTK_DARK": "0",
        "BAR_BG": "#f4f5f8", "BAR_HI": "#ffffff", "BAR_HOVER": "#000000",
        "TEXT": "#15171c", "TEXT_DIM": "#596072", "ACCENT": "#0a6cff", "ACCENT_TEXT": "#ffffff",
        "DOCK_TOP": "#ffffff", "DOCK_BOT": "#dfe2ea",
        "TOOLTIP_BG": "#fbfbfd", "NOTIF_BG": "#fbfbfd", "NOTIF_FRAME": "#c9ccd6", "NOTIF_LOW": "#9aa0ae",
        "MENU_BG": "#fbfbfd", "MENU_BORDER": "#c9ccd6", "MENU_SEP": "#e1e3ea", "MENU_TEXT": "#1a1c22",
        "MENU_TEXT_DIS": "#9aa0ae", "MENU_TITLE_BG": "#eef0f5", "MENU_TITLE_TEXT": "#6a7283",
        "WIN_TITLE_TOP": "#f6f7fa", "WIN_TITLE_BOT": "#e6e8ee",
        "WIN_TITLE_IN_TOP": "#eceef3", "WIN_TITLE_IN_BOT": "#e3e5eb",
        "WIN_TEXT": "#1c1e24", "WIN_TEXT_IN": "#9096a4",
        "WIN_BORDER": "#b8bcc8", "WIN_BORDER_IN": "#cdd0d9", "WIN_SEP": "#cfd2db",
        "WIN_CLIENT": "#e6e8ee", "WIN_CLIENT_IN": "#e3e5eb",
        "DOT_OFF": "#c4c7d0",
    },
}

# Cores do "semáforo" de janela (iguais nos dois temas)
DOT = {"close": "#ff5f57", "close_p": "#c24a44", "iconify": "#febc2e", "iconify_p": "#c19324",
       "max": "#28c840", "max_p": "#1f9a32"}

# Transparência (0-100 = % de opacidade das superfícies de vidro)
ALPHA = {"glass": 72, "reduced": 88, "solid": 100}

THEMERC = """\
! Mac OS Linux — tema Openbox "{OB_THEME}"
! GERADO por branding/generate-themes.py — edite os tokens lá, não este arquivo.
! Botões: discos 14x14 (máscaras .xbm) coloridos por estado, estilo semáforo.
! Cantos arredondados reais vêm do Picom (corner-radius), quando ativo.

! ---- geometria
border.width: 1
padding.width: 9
padding.height: 6
window.handle.width: 0
window.client.padding.width: 0
window.label.text.justify: Center
menu.overlap.x: -2
menu.overlap.y: -4
menu.separator.width: 1
menu.separator.padding.width: 10
menu.separator.padding.height: 4
menu.border.width: 1
osd.border.width: 1

! ---- cores de borda/cliente
window.active.border.color: {WIN_BORDER}
window.inactive.border.color: {WIN_BORDER_IN}
window.active.client.color: {WIN_CLIENT}
window.inactive.client.color: {WIN_CLIENT_IN}
window.active.title.separator.color: {WIN_SEP}
window.inactive.title.separator.color: {WIN_SEP}

! ---- barra de título
window.active.title.bg: Flat Gradient Vertical
window.active.title.bg.color: {WIN_TITLE_TOP}
window.active.title.bg.colorTo: {WIN_TITLE_BOT}
window.inactive.title.bg: Flat Gradient Vertical
window.inactive.title.bg.color: {WIN_TITLE_IN_TOP}
window.inactive.title.bg.colorTo: {WIN_TITLE_IN_BOT}
window.active.label.bg: Parentrelative
window.inactive.label.bg: Parentrelative
window.active.label.text.color: {WIN_TEXT}
window.inactive.label.text.color: {WIN_TEXT_IN}
window.active.label.text.font: shadow=n
window.inactive.label.text.font: shadow=n

! ---- alças/cantos (sem alça visível: o rodapé fica limpo)
window.active.handle.bg: Flat Solid
window.active.handle.bg.color: {WIN_TITLE_BOT}
window.inactive.handle.bg: Flat Solid
window.inactive.handle.bg.color: {WIN_TITLE_IN_BOT}
window.active.grip.bg: Flat Solid
window.active.grip.bg.color: {WIN_TITLE_BOT}
window.inactive.grip.bg: Flat Solid
window.inactive.grip.bg.color: {WIN_TITLE_IN_BOT}

! ---- botões: fundo transparente; o "disco" vem da máscara colorida
window.active.button.unpressed.bg: Parentrelative
window.active.button.pressed.bg: Parentrelative
window.active.button.hover.bg: Parentrelative
window.active.button.disabled.bg: Parentrelative
window.active.button.toggled.unpressed.bg: Parentrelative
window.active.button.toggled.pressed.bg: Parentrelative
window.active.button.toggled.hover.bg: Parentrelative
window.inactive.button.unpressed.bg: Parentrelative
window.inactive.button.pressed.bg: Parentrelative
window.inactive.button.hover.bg: Parentrelative
window.inactive.button.disabled.bg: Parentrelative
window.inactive.button.toggled.unpressed.bg: Parentrelative
window.inactive.button.toggled.pressed.bg: Parentrelative
window.inactive.button.toggled.hover.bg: Parentrelative

window.active.button.disabled.image.color: {DOT_OFF}
window.inactive.button.disabled.image.color: {DOT_OFF}

window.active.button.close.unpressed.image.color: {DOT_close}
window.active.button.close.hover.image.color: {DOT_close}
window.active.button.close.pressed.image.color: {DOT_close_p}
window.active.button.iconify.unpressed.image.color: {DOT_iconify}
window.active.button.iconify.hover.image.color: {DOT_iconify}
window.active.button.iconify.pressed.image.color: {DOT_iconify_p}
window.active.button.max.unpressed.image.color: {DOT_max}
window.active.button.max.hover.image.color: {DOT_max}
window.active.button.max.pressed.image.color: {DOT_max_p}
window.active.button.max.toggled.unpressed.image.color: {DOT_max}
window.active.button.max.toggled.hover.image.color: {DOT_max}
window.active.button.max.toggled.pressed.image.color: {DOT_max_p}

! janela inativa: discos cinza (como em desktops modernos); colorem ao passar o mouse
window.inactive.button.close.unpressed.image.color: {DOT_OFF}
window.inactive.button.close.hover.image.color: {DOT_close}
window.inactive.button.close.pressed.image.color: {DOT_close_p}
window.inactive.button.iconify.unpressed.image.color: {DOT_OFF}
window.inactive.button.iconify.hover.image.color: {DOT_iconify}
window.inactive.button.iconify.pressed.image.color: {DOT_iconify_p}
window.inactive.button.max.unpressed.image.color: {DOT_OFF}
window.inactive.button.max.hover.image.color: {DOT_max}
window.inactive.button.max.pressed.image.color: {DOT_max_p}
window.inactive.button.max.toggled.unpressed.image.color: {DOT_OFF}
window.inactive.button.max.toggled.hover.image.color: {DOT_max}
window.inactive.button.max.toggled.pressed.image.color: {DOT_max_p}

! ---- menus
menu.border.color: {MENU_BORDER}
menu.separator.color: {MENU_SEP}
menu.title.bg: Flat Solid
menu.title.bg.color: {MENU_TITLE_BG}
menu.title.text.color: {MENU_TITLE_TEXT}
menu.title.text.justify: Left
menu.items.bg: Flat Solid
menu.items.bg.color: {MENU_BG}
menu.items.text.color: {MENU_TEXT}
menu.items.disabled.text.color: {MENU_TEXT_DIS}
menu.items.active.bg: Flat Solid
menu.items.active.bg.color: {ACCENT}
menu.items.active.text.color: {ACCENT_TEXT}
menu.items.active.disabled.text.color: {MENU_TEXT_DIS}
menu.bullet.image.color: {MENU_TEXT}
menu.bullet.selected.image.color: {ACCENT_TEXT}

! ---- OSD (Alt+Tab, troca de área de trabalho)
osd.border.color: {MENU_BORDER}
osd.bg: Flat Solid
osd.bg.color: {MENU_BG}
osd.label.bg: Flat Solid
osd.label.bg.color: {MENU_BG}
osd.label.text.color: {MENU_TEXT}
osd.hilight.bg: Flat Solid
osd.hilight.bg.color: {ACCENT}
osd.unhilight.bg: Flat Solid
osd.unhilight.bg.color: {MENU_SEP}
"""


def rgb_triplet(hexcolor):
    h = hexcolor.lstrip("#")
    return ";;".join(str(int(h[i:i + 2], 16)) for i in (0, 2, 4))


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def main():
    for key, t in TOKENS.items():
        fmt = dict(t)
        for k, v in DOT.items():
            fmt["DOT_" + k] = v
        write(os.path.join(INC, "usr/share/themes", t["OB_THEME"], "openbox-3", "themerc"), THEMERC.format(**fmt))

        lines = ["# Tokens do tema '%s' — GERADO por branding/generate-themes.py (shell POSIX, apenas KEY=\"valor\")." % key]
        for k, v in t.items():
            lines.append('THEME_%s="%s"' % (k, v))
        for k in ("DOCK_TOP", "DOCK_BOT"):
            lines.append('THEME_%s_RGB="%s"' % (k, rgb_triplet(t[k])))
        for k, v in ALPHA.items():
            lines.append('ALPHA_%s="%d"' % (k.upper(), v))
        write(os.path.join(INC, "usr/share/macoslinux/themes", key + ".conf"), "\n".join(lines) + "\n")
        print("tema:", key)


if __name__ == "__main__":
    main()
