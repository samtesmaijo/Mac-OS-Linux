#!/bin/sh
# Centro de Controle — pipemenu do Openbox (gera XML a cada abertura).
# Mostra o ESTADO ATUAL e cada item executa uma ação real via macoslinux-ctl.
# Itens sem suporte no hardware (ex.: brilho em desktop) são omitidos.
# shellcheck source=/usr/lib/macoslinux/common.sh
. "${MACOSLINUX_LIB:-/usr/lib/macoslinux}/common.sh" || exit 1

CTL=macoslinux-ctl
ck() { if [ "$1" = 1 ]; then printf '✓  '; else printf '     '; fi; }
item() { printf '  <item label="%s"><action name="Execute"><command>%s</command></action></item>\n' "$(ml_xml "$1")" "$(ml_xml "$2")"; }
sep() { if [ -n "$1" ]; then printf '  <separator label="%s"/>\n' "$(ml_xml "$1")"; else echo '  <separator/>'; fi; }
open_menu() { printf '  <menu id="%s" label="%s">\n' "$1" "$(ml_xml "$2")"; }
close_menu() { echo '  </menu>'; }

section_network() {
    sep "Rede"
    if ! have nmcli; then sep "NetworkManager indisponível"; return; fi
    devs=$(LC_ALL=C timeout 3 nmcli -t -f TYPE,STATE,CONNECTION device 2>/dev/null)
    eth=$(printf '%s\n' "$devs" | sed -n 's/^ethernet:connected:\(.*\)$/\1/p' | head -n 1)
    if printf '%s\n' "$devs" | grep -q '^ethernet:'; then
        if [ -n "$eth" ]; then sep "Ethernet: conectado"; else sep "Ethernet: sem cabo"; fi
    fi
    if printf '%s\n' "$devs" | grep -q '^wifi:'; then
        if [ "$(LC_ALL=C nmcli radio wifi 2>/dev/null)" = enabled ]; then
            item "Wi-Fi: ligado (clique para desligar)" "$CTL wifi off"
            wcon=$(printf '%s\n' "$devs" | sed -n 's/^wifi:connected:\(.*\)$/\1/p' | head -n 1)
            [ -n "$wcon" ] && sep "Conectado a $wcon"
            printf '  <menu id="mlcc-wifi" label="Redes Wi-Fi" execute="macoslinux-control-center wifi"/>\n'
        else
            item "Wi-Fi: desligado (clique para ligar)" "$CTL wifi on"
        fi
    else
        sep "Wi-Fi: nenhum adaptador"
    fi
    if have nm-connection-editor; then item "Configurações de rede…" "nm-connection-editor"; fi
}

section_sound() {
    sep "Som"
    if st=$(ml_vol_get); then
        v=${st% *}; m=${st#* }
        if [ "$m" = muted ]; then lbl="Volume: mudo"; else lbl="Volume: $v%"; fi
        open_menu mlcc-vol "$lbl"
        if [ "$m" = muted ]; then item "Ativar o som" "$CTL volume mute"; else item "Silenciar" "$CTL volume mute"; fi
        item "Aumentar (+5%)" "$CTL volume up"
        item "Diminuir (−5%)" "$CTL volume down"
        sep ""
        for p in 0 25 50 75 100; do item "Definir em $p%" "$CTL volume set $p"; done
        close_menu
        have pactl && printf '  <menu id="mlcc-out" label="Saída de áudio" execute="macoslinux-control-center output"/>\n'
        have pavucontrol && item "Controle de áudio…" "pavucontrol"
    else
        sep "Áudio indisponível (servidor não iniciado)"
    fi
}

section_brightness() {
    have brightnessctl || return 0
    for d in /sys/class/backlight/*; do
        if [ -e "$d/brightness" ]; then
            b=$(brightnessctl -m 2>/dev/null | cut -d, -f4)
            sep "Tela"
            open_menu mlcc-bright "Brilho: ${b:-?}"
            item "Aumentar (+10%)" "$CTL brightness up"
            item "Diminuir (−10%)" "$CTL brightness down"
            close_menu
            return 0
        fi
    done
}

section_appearance() {
    sep "Aparência"
    th=$(ml_theme); tr=$(ml_transparency); mo=$(ml_motion)
    open_menu mlcc-look "Tema e efeitos"
    item "$(ck "$([ "$th" = dark ] && echo 1 || echo 0)")Modo escuro" "$CTL theme dark"
    item "$(ck "$([ "$th" = light ] && echo 1 || echo 0)")Modo claro" "$CTL theme light"
    sep ""
    item "$(ck "$([ "$tr" = glass ] && echo 1 || echo 0)")Transparência: vidro" "$CTL transparency glass"
    item "$(ck "$([ "$tr" = reduced ] && echo 1 || echo 0)")Transparência: reduzida" "$CTL transparency reduced"
    item "$(ck "$([ "$tr" = solid ] && echo 1 || echo 0)")Transparência: desligada" "$CTL transparency solid"
    sep ""
    item "$(ck "$([ "$mo" = reduced ] && echo 1 || echo 0)")Reduzir movimento e efeitos" "$CTL motion toggle"
    item "$(ck "$(ml_bool BLUR 0)")Desfoque do vidro (experimental, pesado)" "$CTL blur toggle"
    close_menu
    open_menu mlcc-dock "Dock"
    item "$(ck "$(ml_bool DOCK_AUTOHIDE 0)")Ocultar automaticamente" "$CTL dock autohide toggle"
    item "$(ck "$(ml_bool DOCK_ZOOM 1)")Ampliar ao passar o mouse" "$CTL dock zoom toggle"
    sep "Tamanho dos ícones"
    sz=$(ml_get DOCK_SIZE 46)
    item "$(ck "$([ "$sz" = 36 ] && echo 1 || echo 0)")Pequeno" "$CTL dock size 36"
    item "$(ck "$([ "$sz" = 46 ] && echo 1 || echo 0)")Médio" "$CTL dock size 46"
    item "$(ck "$([ "$sz" = 56 ] && echo 1 || echo 0)")Grande" "$CTL dock size 56"
    close_menu
}

section_notifications() {
    have dunstctl || return 0
    sep "Notificações"
    if [ "$(dunstctl is-paused 2>/dev/null)" = true ]; then
        item "Não perturbe: ligado (clique para desligar)" "$CTL dnd off"
    else
        item "Não perturbe: desligado (clique para ligar)" "$CTL dnd on"
    fi
    item "Mostrar a última notificação" "dunstctl history-pop"
    item "Fechar todas" "dunstctl close-all"
}

main() {
    echo '<openbox_pipe_menu>'
    section_network
    section_sound
    section_brightness
    section_appearance
    section_notifications
    sep ""
    item "Recarregar a interface" "$CTL restart-ui"
    echo '</openbox_pipe_menu>'
}

wifi_list() {
    echo '<openbox_pipe_menu>'
    LC_ALL=C timeout 6 nmcli -t -f IN-USE,SSID,SIGNAL,SECURITY device wifi list 2>/dev/null |
        sed 's/\\:/\x01/g' |
        awk -F: '$2 != "" && !seen[$2]++ { print $3 "\t" $1 "\t" $2 "\t" $4 }' |
        sort -t "$(printf '\t')" -k1,1nr | head -n 12 |
        while IFS="$(printf '\t')" read -r sig use ssid sec; do
            ssid=$(printf '%s' "$ssid" | tr '\001' ':')
            lock=""; [ -n "$sec" ] && [ "$sec" != "--" ] && lock="  · protegida"
            mark="     "; [ "$use" = '*' ] && mark="✓  "
            item "$mark$ssid — $sig%$lock" "$CTL wifi-connect $(ml_sq "$ssid")"
        done
    echo '</openbox_pipe_menu>'
}

output_list() {
    echo '<openbox_pipe_menu>'
    def=$(LC_ALL=C pactl get-default-sink 2>/dev/null)
    LC_ALL=C pactl list sinks 2>/dev/null |
        awk '$1=="Name:" {n=$2} /^[ \t]*Description:/ { sub(/^[ \t]*Description: /, ""); print n "\t" $0 }' |
        while IFS="$(printf '\t')" read -r name desc; do
            mark="     "; [ "$name" = "$def" ] && mark="✓  "
            item "$mark$desc" "$CTL output $(ml_sq "$name")"
        done
    echo '</openbox_pipe_menu>'
}

case "$1" in
    wifi) wifi_list ;;
    output) output_list ;;
    *) main ;;
esac
