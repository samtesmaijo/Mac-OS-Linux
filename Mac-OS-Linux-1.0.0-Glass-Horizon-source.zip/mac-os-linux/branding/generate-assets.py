#!/usr/bin/env python3
"""Gera os assets visuais ORIGINAIS do Mac OS Linux (logo, ícones e wallpapers).

Ferramenta de BUILD apenas (Pillow + NumPy). Nada aqui roda no sistema final:
o resultado são PNG/JPG/SVG estáticos copiados para config/includes.chroot.

Uso:  python3 branding/generate-assets.py
Não usa nenhum recurso da Apple. Todo desenho é geométrico e próprio.
"""
import math
import os
import sys

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
INC = os.path.join(ROOT, "config", "includes.chroot")
ICON_DIR = os.path.join(INC, "usr/share/icons/hicolor")
SHARE = os.path.join(INC, "usr/share/macoslinux")
SIZES = (256, 128, 64, 48, 32, 22)
S = 1024  # tela de desenho (supersampling)


def hexrgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def squircle_mask(size, n=5.0, inset=0.04):
    """Superelipse (|x|^n + |y|^n = 1) -> silhueta 'squircle' suave."""
    ys, xs = np.mgrid[0:size, 0:size].astype(np.float32)
    c = (size - 1) / 2.0
    r = c * (1 - inset)
    d = (np.abs(xs - c) / r) ** n + (np.abs(ys - c) / r) ** n
    # borda anti-aliased: 1 dentro, 0 fora, transição curta
    a = np.clip((1.0 - d) * r / 2.2, 0.0, 1.0)
    return Image.fromarray((a * 255).astype(np.uint8), "L")


def vgrad(size, top, bottom):
    t = np.linspace(0, 1, size, dtype=np.float32)[:, None, None]
    a = np.array(hexrgb(top), np.float32)[None, None, :]
    b = np.array(hexrgb(bottom), np.float32)[None, None, :]
    img = a + (b - a) * t
    img = np.repeat(img, size, axis=1)
    return Image.fromarray(img.astype(np.uint8), "RGB")


def base_tile(top, bottom):
    """Fundo do ícone: gradiente + brilho de vidro no topo + traço interno fino."""
    tile = vgrad(S, top, bottom).convert("RGBA")
    # brilho (reflexo) suave na metade de cima
    gloss = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    gd = ImageDraw.Draw(gloss)
    gd.ellipse((-S * 0.25, -S * 0.95, S * 1.25, S * 0.52), fill=(255, 255, 255, 46))
    gloss = gloss.filter(ImageFilter.GaussianBlur(S * 0.012))
    tile = Image.alpha_composite(tile, gloss)
    mask = squircle_mask(S)
    # traço interno claro (1px em 1024 -> sutil)
    edge = ImageChops.subtract(mask, mask.filter(ImageFilter.MinFilter(9)))
    rim = Image.new("RGBA", (S, S), (255, 255, 255, 0))
    rim.putalpha(edge.point(lambda v: int(v * 0.35)))
    tile = Image.alpha_composite(tile, rim)
    out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    out.paste(tile, (0, 0), mask)
    return out


def with_shadow(glyph_layer, blur=0.02, alpha=70, dy=0.012):
    sh = Image.new("RGBA", glyph_layer.size, (0, 0, 0, 0))
    a = glyph_layer.split()[3].point(lambda v: int(v * alpha / 255))
    sh.putalpha(a)
    sh = sh.filter(ImageFilter.GaussianBlur(S * blur))
    sh = ImageChops.offset(sh, 0, int(S * dy))
    return Image.alpha_composite(sh, glyph_layer)


WHITE = (255, 255, 255, 255)


def rrect(d, box, r, fill):
    d.rounded_rectangle(box, radius=r, fill=fill)


# ---------- glifos (desenhados sobre camada transparente S x S) ----------
def glyph_folder():
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    rrect(d, (0.20 * S, 0.30 * S, 0.50 * S, 0.40 * S), 40, (255, 255, 255, 235))   # aba
    rrect(d, (0.18 * S, 0.34 * S, 0.82 * S, 0.74 * S), 56, WHITE)                  # corpo
    rrect(d, (0.18 * S, 0.40 * S, 0.82 * S, 0.74 * S), 56, (255, 255, 255, 255))
    return g


def glyph_terminal():
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    w = int(0.075 * S)
    # ">"
    pts = [(0.28 * S, 0.34 * S), (0.46 * S, 0.50 * S), (0.28 * S, 0.66 * S)]
    d.line(pts, fill=(120, 230, 160, 255), width=w, joint="curve")
    for p in (pts[0], pts[2]):
        d.ellipse((p[0] - w / 2, p[1] - w / 2, p[0] + w / 2, p[1] + w / 2), fill=(120, 230, 160, 255))
    # "_"
    rrect(d, (0.52 * S, 0.62 * S, 0.74 * S, 0.62 * S + w), w // 2, (235, 238, 245, 255))
    return g


def glyph_apps():
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    cell, gap = 0.15 * S, 0.055 * S
    start = (S - (3 * cell + 2 * gap)) / 2
    for i in range(3):
        for j in range(3):
            x0 = start + i * (cell + gap)
            y0 = start + j * (cell + gap)
            rrect(d, (x0, y0, x0 + cell, y0 + cell), 34, WHITE)
    return g


def glyph_sliders():
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    h = int(0.05 * S)
    rows = [(0.34, 0.38), (0.50, 0.64), (0.66, 0.46)]
    for y, kx in rows:
        yy = y * S
        rrect(d, (0.24 * S, yy - h / 2, 0.76 * S, yy + h / 2), h // 2, (255, 255, 255, 120))
        rrect(d, (0.24 * S, yy - h / 2, kx * S + 0.0, yy + h / 2), h // 2, WHITE)
        r = 0.065 * S
        d.ellipse((kx * S - r, yy - r, kx * S + r, yy + r), fill=WHITE)
    return g


def glyph_settings():
    """A simple original six-spoke control glyph; not a copied system logo."""
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    cx = cy = S / 2
    r0, r1 = 0.22 * S, 0.39 * S
    width = int(0.105 * S)
    for angle in range(0, 360, 60):
        a = math.radians(angle)
        x0, y0 = cx + math.cos(a) * r0, cy + math.sin(a) * r0
        x1, y1 = cx + math.cos(a) * r1, cy + math.sin(a) * r1
        d.line((x0, y0, x1, y1), fill=WHITE, width=width)
        rr = width * 0.68
        d.ellipse((x1-rr, y1-rr, x1+rr, y1+rr), fill=WHITE)
    rr = 0.27 * S
    d.ellipse((cx-rr, cy-rr, cx+rr, cy+rr), outline=WHITE, width=int(0.09*S))
    rr2 = 0.09 * S
    d.ellipse((cx-rr2, cy-rr2, cx+rr2, cy+rr2), fill=WHITE)
    return g


def glyph_speaker():
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    # corpo do alto-falante
    d.polygon([(0.26 * S, 0.43 * S), (0.38 * S, 0.43 * S), (0.54 * S, 0.29 * S),
               (0.54 * S, 0.71 * S), (0.38 * S, 0.57 * S), (0.26 * S, 0.57 * S)], fill=WHITE)
    w = int(0.05 * S)
    for k, rad in enumerate((0.13, 0.22)):
        bb = (0.54 * S - rad * S * 0.2, 0.5 * S - rad * S, 0.54 * S + rad * S * 1.6, 0.5 * S + rad * S)
        d.arc(bb, -48, 48, fill=(255, 255, 255, 255 - k * 35), width=w)
    return g


def glyph_network():
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    cx, cy = 0.5 * S, 0.68 * S
    w = int(0.06 * S)
    for rad in (0.17, 0.29, 0.41):
        bb = (cx - rad * S, cy - rad * S, cx + rad * S, cy + rad * S)
        d.arc(bb, 225, 315, fill=WHITE, width=w)
    r = 0.045 * S
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=WHITE)
    return g


def glyph_gate(color=WHITE):
    """Logo: dois arcos de 'portal' (gate) encaixados sobre um horizonte."""
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    w = int(0.075 * S)
    for rad, alpha in ((0.30, 255), (0.18, 255)):
        cx, cy = 0.5 * S, 0.66 * S
        bb = (cx - rad * S, cy - rad * S, cx + rad * S, cy + rad * S)
        col = color[:3] + (alpha,)
        d.arc(bb, 180, 360, fill=col, width=w)
        d.line([(cx - rad * S + w / 2, cy), (cx - rad * S + w / 2, 0.76 * S)], fill=col, width=w)
        d.line([(cx + rad * S - w / 2, cy), (cx + rad * S - w / 2, 0.76 * S)], fill=col, width=w)
    rrect(d, (0.18 * S, 0.74 * S, 0.82 * S, 0.74 * S + w), w // 2, color[:3] + (255,))
    return g


ICONS = {
    # nome: (cor topo, cor base, glifo)
    "macoslinux-files":          ("#58b4ff", "#1d63d8", glyph_folder),
    "macoslinux-terminal":       ("#3a3f4d", "#14161c", glyph_terminal),
    "macoslinux-apps":           ("#b07cff", "#5a3bd6", glyph_apps),
    "macoslinux-control-center": ("#9aa3b5", "#4a5163", glyph_sliders),
    "macoslinux-settings":       ("#76b8ff", "#285ac7", glyph_settings),
    "macoslinux-audio":          ("#ff9b5e", "#e0432f", glyph_speaker),
    "macoslinux-network":        ("#46d6c0", "#12847c", glyph_network),
    "macoslinux":                ("#ffc44d", "#ee5a52", glyph_gate),
}


def make_icon(name, top, bottom, glyph):
    tile = base_tile(top, bottom)
    g = with_shadow(glyph())
    return Image.alpha_composite(tile, g)


def save_icons():
    for name, (top, bottom, glyph) in ICONS.items():
        big = make_icon(name, top, bottom, glyph)
        for sz in SIZES:
            d = os.path.join(ICON_DIR, f"{sz}x{sz}", "apps")
            os.makedirs(d, exist_ok=True)
            big.resize((sz, sz), Image.LANCZOS).save(os.path.join(d, f"{name}.png"), optimize=True)
    print("ícones:", ", ".join(ICONS))


def save_logo_mono():
    """Glifo monocromático para a barra superior (transparente), em 2 cores."""
    d = os.path.join(SHARE, "logo")
    os.makedirs(d, exist_ok=True)
    for tag, col in (("dark", (245, 247, 250, 255)), ("light", (28, 30, 36, 255))):
        g = glyph_gate(col)
        bbox = g.getbbox()
        g = g.crop(bbox)
        side = max(g.size)
        sq = Image.new("RGBA", (side, side), (0, 0, 0, 0))
        sq.paste(g, ((side - g.width) // 2, (side - g.height) // 2))
        for sz in (16, 22, 32):
            sq.resize((sz, sz), Image.LANCZOS).save(os.path.join(d, f"macoslinux-bar-{tag}-{sz}.png"), optimize=True)
    print("logo monocromático (barra): dark/light x 16,22,32")


def save_svg():
    svg = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#ffc44d"/><stop offset="1" stop-color="#ee5a52"/>
    </linearGradient>
  </defs>
  <rect x="5" y="5" width="118" height="118" rx="28" fill="url(#g)"/>
  <g fill="none" stroke="#fff" stroke-width="9.6" stroke-linecap="round">
    <path d="M25.6 94.7V84.5a38.4 38.4 0 0 1 76.8 0v10.2"/>
    <path d="M48.6 94.7V84.5a15.4 15.4 0 0 1 30.8 0v10.2" stroke-width="9.6"/>
    <path d="M23 94.7h82"/>
  </g>
</svg>
"""
    d = os.path.join(ICON_DIR, "scalable", "apps")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "macoslinux.svg"), "w", encoding="utf-8") as f:
        f.write(svg)
    print("svg do logo")


# ---------------------------- wallpapers -------------------------------
def blob(w, h, cx, cy, rx, ry, rot=0.0):
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    x, y = (xs - cx * w), (ys - cy * h)
    c, s = math.cos(rot), math.sin(rot)
    xr, yr = x * c + y * s, -x * s + y * c
    return np.exp(-((xr / (rx * w)) ** 2 + (yr / (ry * h)) ** 2))


def ribbon(w, h, y0, amp, freq, phase, thick):
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    curve = (y0 + amp * np.sin(xs / w * freq * math.pi * 2 + phase)) * h
    return np.exp(-(((ys - curve) / (thick * h)) ** 2))


def wallpaper(w, h, kind):
    rng = np.random.default_rng(27)
    ys = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
    if kind == "dark":
        a, b = np.array(hexrgb("#080c1c"), np.float32), np.array(hexrgb("#1b1546"), np.float32)
        img = a + (b - a) * ys
        img = np.repeat(img, w, axis=1)
        layers = [
            (blob(w, h, 0.18, 0.88, 0.42, 0.40, 0.3), "#16c7b8", 0.55),
            (blob(w, h, 0.82, 0.12, 0.40, 0.36, -0.4), "#7a5cff", 0.55),
            (blob(w, h, 0.62, 0.78, 0.30, 0.22, 0.2), "#ff7a59", 0.30),
            (blob(w, h, 0.95, 0.95, 0.22, 0.28, 0.0), "#ffb347", 0.38),
            (ribbon(w, h, 0.55, 0.10, 1.2, 0.8, 0.10), "#5a8cff", 0.16),
            (ribbon(w, h, 0.66, 0.08, 1.6, 2.4, 0.07), "#16c7b8", 0.14),
        ]
    else:
        a, b = np.array(hexrgb("#f4f6fd"), np.float32), np.array(hexrgb("#dfe6f8"), np.float32)
        img = a + (b - a) * ys
        img = np.repeat(img, w, axis=1)
        layers = [
            (blob(w, h, 0.15, 0.85, 0.42, 0.40, 0.3), "#8fd0ff", 0.60),
            (blob(w, h, 0.85, 0.15, 0.40, 0.36, -0.4), "#c3b2ff", 0.60),
            (blob(w, h, 0.60, 0.80, 0.30, 0.22, 0.2), "#ffc6a3", 0.55),
            (blob(w, h, 0.97, 0.97, 0.22, 0.28, 0.0), "#ffd98a", 0.55),
            (ribbon(w, h, 0.55, 0.10, 1.2, 0.8, 0.10), "#ffffff", 0.40),
        ]
    for m, col, k in layers:
        c = np.array(hexrgb(col), np.float32)
        img = img * (1 - (m * k)[:, :, None]) + c * (m * k)[:, :, None]
    # vinheta bem leve para dar profundidade (e segurar o contraste da barra superior)
    ys2, xs2 = np.mgrid[0:h, 0:w].astype(np.float32)
    v = ((xs2 / w - 0.5) ** 2 + (ys2 / h - 0.5) ** 2) * (0.35 if kind == "dark" else 0.10)
    img = img * (1 - v[:, :, None])
    img += rng.normal(0, 1.1, img.shape)  # ruído fino evita faixas (banding) no JPEG
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGB")


def save_wallpapers():
    d = os.path.join(SHARE, "wallpapers")
    os.makedirs(d, exist_ok=True)
    for kind in ("dark", "light"):
        im = wallpaper(1920, 1080, kind)
        p = os.path.join(d, f"aurora-{kind}.jpg")
        im.save(p, quality=90, subsampling=0, optimize=True, progressive=False)
        print(f"wallpaper {kind}: {os.path.getsize(p) // 1024} KB")


# ------------------- máscaras XBM dos botões de janela -----------------
# O Openbox só aceita máscaras 1-bit (XBM) para botões. Desenhamos um disco
# e, nas variantes hover, "recortamos" o símbolo (x, -, +) para o titlebar
# aparecer através do furo, como numa barra de título moderna.
def xbm_text(name, img):
    w, h = img.size
    px = img.load()
    out = [f"#define {name}_width {w}", f"#define {name}_height {h}", f"static unsigned char {name}_bits[] = {{"]
    row_bytes = (w + 7) // 8
    vals = []
    for y in range(h):
        for bx in range(row_bytes):
            v = 0
            for b in range(8):
                x = bx * 8 + b
                if x < w and px[x, y]:
                    v |= 1 << b
            vals.append(v)
    lines = []
    for i in range(0, len(vals), 12):
        lines.append("  " + ", ".join(f"0x{v:02x}" for v in vals[i:i + 12]))
    out.append(",\n".join(lines) + " };")
    return "\n".join(out) + "\n"


def disc_mask(size, diameter, glyph=None):
    k = 8
    big = Image.new("L", (size * k, size * k), 0)
    d = ImageDraw.Draw(big)
    c = size * k / 2
    r = diameter * k / 2
    d.ellipse((c - r, c - r, c + r, c + r), fill=255)
    if glyph:
        g = size * k / 2
        lw = max(int(k * 1.1), 1)
        s = diameter * k * 0.21
        if glyph == "x":
            d.line([(g - s, g - s), (g + s, g + s)], fill=0, width=lw)
            d.line([(g - s, g + s), (g + s, g - s)], fill=0, width=lw)
        elif glyph == "minus":
            d.line([(g - s * 1.2, g), (g + s * 1.2, g)], fill=0, width=lw)
        elif glyph == "plus":
            d.line([(g - s * 1.1, g), (g + s * 1.1, g)], fill=0, width=lw)
            d.line([(g, g - s * 1.1), (g, g + s * 1.1)], fill=0, width=lw)
    small = big.resize((size, size), Image.BOX)
    return small.point(lambda v: 255 if v >= 128 else 0).convert("1")


def save_xbm_masks():
    size, dia = 14, 12
    specs = {
        "close":   {"": None, "_hover": "x", "_pressed": None},
        "iconify": {"": None, "_hover": "minus", "_pressed": None},
        "max":     {"": None, "_hover": "plus", "_pressed": None,
                    "_toggled": None, "_toggled_hover": "plus", "_toggled_pressed": None},
    }
    for theme in ("MacOSLinux-Dark", "MacOSLinux-Light"):
        d = os.path.join(INC, "usr/share/themes", theme, "openbox-3")
        os.makedirs(d, exist_ok=True)
        for base, variants in specs.items():
            for suffix, glyph in variants.items():
                dm = dia - 2 if suffix.endswith("pressed") else dia
                img = disc_mask(size, dm, glyph)
                fname = f"{base}{suffix}.xbm"
                with open(os.path.join(d, fname), "w", encoding="ascii") as f:
                    f.write(xbm_text(fname[:-4], img))
    print("máscaras XBM: close/iconify/max (+hover/pressed/toggled) x 2 temas")


# ------------------- ícones de status da barra superior ----------------
def status_glyph(kind, col):
    """Glifos monocromáticos 'line icons' em tela 256x256 (depois reduzidos p/ 18 px)."""
    T = 256
    g = Image.new("RGBA", (T, T), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    c = col
    w = 22
    if kind.startswith("vol"):
        d.polygon([(40, 104), (84, 104), (128, 64), (128, 192), (84, 152), (40, 152)], fill=c)
        if kind == "vol-mute":
            d.line([(158, 100), (214, 156)], fill=c, width=w)
            d.line([(214, 100), (158, 156)], fill=c, width=w)
        else:
            n = 1 if kind == "vol-low" else 2
            for i in range(n):
                r = 46 + i * 38
                d.arc((128 - r + 22, 128 - r, 128 + r + 22, 128 + r), -50, 50, fill=c, width=w)
    elif kind in ("net-wifi", "net-off"):
        cx, cy = 128, 196
        for r in (56, 108, 160):
            d.arc((cx - r, cy - r, cx + r, cy + r), 227, 313, fill=c, width=w)
        d.ellipse((cx - 17, cy - 17, cx + 17, cy + 17), fill=c)
        if kind == "net-off":
            d.line([(48, 48), (208, 208)], fill=c, width=w + 6)
    elif kind == "net-wired":
        d.rounded_rectangle((44, 52, 212, 148), radius=18, outline=c, width=w)
        for x in (88, 128, 168):
            d.line([(x, 148), (x, 188)], fill=c, width=w - 4)
        d.line([(88, 188), (168, 188)], fill=c, width=w - 4)
        d.line([(128, 188), (128, 224)], fill=c, width=w - 4)
    elif kind == "control":
        for y, kx in ((84, 96), (172, 160)):
            d.rounded_rectangle((36, y - 12, 220, y + 12), radius=12, fill=c[:3] + (120,))
        d.ellipse((96 - 34, 84 - 34, 96 + 34, 84 + 34), fill=c)
        d.ellipse((160 - 34, 172 - 34, 160 + 34, 172 + 34), fill=c)
    elif kind == "dnd":
        d.ellipse((44, 44, 212, 212), outline=c, width=w)
        d.line([(92, 128), (164, 128)], fill=c, width=w + 2)
    return g


def save_status_icons():
    for tag, col in (("dark", (245, 247, 250, 255)), ("light", (28, 30, 36, 255))):
        d = os.path.join(SHARE, "status", tag)
        os.makedirs(d, exist_ok=True)
        for kind in ("vol-mute", "vol-low", "vol-high", "net-wifi", "net-wired", "net-off", "control", "dnd"):
            img = status_glyph(kind, col)
            img.resize((18, 18), Image.LANCZOS).save(os.path.join(d, kind + ".png"), optimize=True)
    print("ícones de status: 8 x 2 temas (18 px)")


if __name__ == "__main__":
    save_icons()
    save_svg()
    save_logo_mono()
    save_wallpapers()
    save_xbm_masks()
    save_status_icons()
    print("ok")
