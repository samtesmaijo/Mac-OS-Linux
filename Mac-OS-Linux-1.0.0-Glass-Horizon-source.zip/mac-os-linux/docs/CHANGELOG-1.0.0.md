# Mac OS Linux 1.0.0 — Glass Horizon

## Interface adicionada nesta revisão

- Aplicativo próprio C/GTK3 para Centro de Controle, Configurações do Sistema e Launcher pesquisável.
- Centro de Controle flutuante com cartões de Wi-Fi, Bluetooth, Foco, Aparência e Sistema, controle de volume, mudo e abertura dos dispositivos de áudio.
- Configurações com sidebar e páginas Geral, Aparência, Dock, Rede, Som, Tela, Notificações e Sobre.
- Tema GTK3 próprio com variantes claras e escuras, cartões translúcidos, contornos, gradientes discretos e modos glass/reduced/solid.
- Launcher de aplicativos baseado em GIO, lendo arquivos `.desktop` instalados.
- Wi-Fi e Bluetooth integrados aos comandos de controle existentes, com Bluetooth via `rfkill`.
- Atalhos `Super+C`, `Super+I` e `Super+Espaço`.
- Makefile compila e instala a aplicação C antes de `make configure`; `make prepare-iso` prepara binário, testes e configuração.
- Live-Build configurado com opções compatíveis com a sintaxe atual do Debian Trixie e bootstrap `minbase`.
- Documentação de pesquisa macOS 27 e temas Linux adicionada; as fontes foram referências de estudo e não foram incorporados seus assets.

## Ainda pendente

- Compilar e executar a aplicação GTK3 no Zorin OS com `libgtk-3-dev`.
- Revisão visual em Xorg no hardware real.
- Gerar uma nova ISO 1.0.0 e fazer boot de teste.
- Testar todos os controles com os respectivos dispositivos/serviços presentes.
- Medir uso de RAM/CPU e ajustar detalhes para Core 2 Duo + Intel G41.
- Criar logos e ícones finais originais para todos os aplicativos.
