# Mac OS Linux

**Version:** 0.1.0-alpha (build revision R3)  
**Architecture:** amd64 (x86_64)  
**Base:** Debian 13 (Trixie), assembled with `live-build`

Mac OS Linux is an independent desktop-distribution project. It uses the Linux kernel and Debian's package archive as a reliable foundation, while developing its own branding, desktop shell, defaults, applications, image configuration, and release process.

This is a distribution project, not a new kernel written from scratch. The first milestone is a small bootable live ISO that can be tested without installing to a disk.

## Current hardware target

The first development machine is recorded in [`hardware/profile-g41-e7500.conf`](hardware/profile-g41-e7500.conf):

- Intel Core 2 Duo E7500, 2.93 GHz, 2 cores
- 1.9 GiB installed RAM
- Intel 4 Series / G41 integrated graphics, PCI ID `8086:2e32`
- Linux kernel driver `i915` already active on the host
- 64-bit x86 (`x86_64`)

The target machine has limited memory. The first image therefore uses a small Xorg + Openbox session, avoids heavy desktop environments and uses the lightweight Picom compositor with the XRender backend, and leaves SquashFS compression at the installed live-build tool default for compatibility with the Ubuntu 24.04-derived host toolchain. The initramfs uses gzip. Build one image at a time and keep other applications closed.

## Technical direction

- **Base:** Debian 13 Trixie, using the Debian archive and `live-build`.
- **Kernel:** Debian's supported amd64 kernel package for the first alpha.
- **Init:** systemd.
- **Display:** Xorg for the first hardware milestone.
- **Window manager:** Openbox as a lightweight foundation.
- **Panels:** Tint2 for the initial top bar and Plank for the initial dock; these are temporary foundations while the project develops its own shell components.
- **Graphics:** kernel `i915` plus Mesa; use Xorg's `modesetting` driver unless testing proves another driver is necessary.
- **Package handling:** Debian packages for the first alpha; a project repository and update policy will be designed later.

The first release is a live image only. A graphical installer, updater, custom package manager, and project-owned compositor are later milestones—not features already implemented.

## Quick start

From a terminal in this directory:

```bash
make check-host
```

This is a read-only inspection. It does not install packages, change settings, modify disks, or configure the image.

After the required host tools are available, configure the live image with. The configuration targets the installed Ubuntu/Zorin `live-build` 3.0~a57 interface: it uses `--debian-installer false` and does not pass the newer SquashFS compression-type switch that this host version does not support.

```bash
./auto/config
```

That command writes live-build configuration into this project directory. It does not start the image build or modify partitions.

## Safety

- Do not partition or format the host computer for routine development.
- Build and test the first ISO in a virtual machine or from a USB drive without installing it.
- Do not run `lb clean`, `lb build`, or installation commands with elevated privileges unless their effect is understood.
- The build needs root privileges for some live-build stages. The project does not automatically invoke `sudo`.
- Keep a backup of project source files before changing the build configuration.

## Official references

- Debian Live Manual: https://live-team.pages.debian.net/live-manual/html/live-manual/index.en.html
- Debian Trixie installation guide: https://www.debian.org/releases/trixie/installmanual
- Linux kernel i915 driver configuration: https://cateee.net/lkddb/web-lkddb/DRM_I915.html


## Build compatibility note (R3)

The R2 configuration used two options not accepted by Ubuntu's `live-build` 3.0~a57-1ubuntu49.1: `--chroot-squashfs-compression-type` and the value `none` for `--debian-installer`. R3 removes the unsupported compression switch, explicitly selects SquashFS, uses gzip for the initramfs, and disables the Debian installer with the supported value `false`. It also selects the minimal bootstrap flavour to reduce the initial system size.


## Experimental visual refresh (2026-11-08)

The current visual experiment keeps the lightweight Xorg + Openbox + Tint2 + Plank stack. It adds Picom (XRender backend) for window shadows and fade transitions, Plank launcher entries for Files and Terminal, and a translucent Tint2 top bar. Plank icon zoom is configured through GSettings when the installed schema supports the requested keys. Validate the available schema before relying on those settings.

This is an experimental interface foundation, not a completed macOS-like shell. Standard Picom fading is not the same as native minimize/restore motion. Validate every Picom option and every Tint2 setting against the versions installed in the target image before release.
