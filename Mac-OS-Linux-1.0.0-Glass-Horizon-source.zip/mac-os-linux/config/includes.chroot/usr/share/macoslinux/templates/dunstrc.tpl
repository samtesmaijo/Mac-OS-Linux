# Mac OS Linux — notificações (dunst). Tema: @THEME_NAME@. Transparência: @ALPHA@%.
# GERADO a partir de dunstrc.tpl por macoslinux-ctl.
[global]
    monitor = 0
    follow = mouse
    width = 340
    origin = top-right
    offset = 14x40
    notification_limit = 4
    indicate_hidden = yes
    transparency = @NOTIF_TRANSPARENCY@
    separator_height = 1
    padding = 12
    horizontal_padding = 14
    text_icon_padding = 12
    frame_width = 1
    frame_color = "@THEME_NOTIF_FRAME@"
    separator_color = frame
    corner_radius = 12
    sort = yes
    idle_threshold = 120
    font = Inter 10
    line_height = 0
    markup = full
    format = "<b>%s</b>\n%b"
    alignment = left
    vertical_alignment = center
    show_age_threshold = 60
    word_wrap = yes
    ellipsize = middle
    ignore_newline = no
    stack_duplicates = true
    hide_duplicate_count = false
    show_indicators = no
    icon_position = left
    min_icon_size = 32
    max_icon_size = 40
    sticky_history = yes
    history_length = 20
    dmenu = /bin/true
    browser = /usr/bin/xdg-open
    always_run_script = true
    title = Dunst
    class = Dunst
    progress_bar = true
    progress_bar_height = 8
    progress_bar_frame_width = 0
    progress_bar_min_width = 150
    progress_bar_max_width = 300
    mouse_left_click = close_current
    mouse_middle_click = do_action, close_current
    mouse_right_click = close_all

[urgency_low]
    background = "@THEME_NOTIF_BG@"
    foreground = "@THEME_TEXT_DIM@"
    highlight = "@THEME_ACCENT@"
    timeout = 5

[urgency_normal]
    background = "@THEME_NOTIF_BG@"
    foreground = "@THEME_TEXT@"
    highlight = "@THEME_ACCENT@"
    timeout = 7

[urgency_critical]
    background = "@THEME_NOTIF_BG@"
    foreground = "@THEME_TEXT@"
    frame_color = "#ff5f57"
    highlight = "#ff5f57"
    timeout = 0

# Indicador rápido de volume/brilho (OSD): curto, não vai para o histórico
[osd]
    appname = "macoslinux-osd"
    timeout = 2
    history_ignore = yes
    format = "<b>%s</b>"
    set_transient = yes

# Calendário (clique no relógio)
[calendar]
    appname = "macoslinux-calendar"
    timeout = 12
    history_ignore = yes
    format = "<b>%s</b>\n%b"
