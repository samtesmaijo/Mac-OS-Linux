# Development roadmap

## Phase 0 — Project foundation (completed)

- [x] Define name, version, initial architecture, and project principles.
- [x] Add a read-only host inspection script.
- [x] Inspect the first target machine.
- [x] Record the Core 2 Duo E7500 / Intel G41 hardware profile.
- [x] Select a low-memory Debian live-build path instead of a full LFS source build.

**Exit condition:** first target hardware is understood and the build approach matches its limits.

## Phase 1 — Minimal live image (current)

- [x] Add Debian Trixie live-build configuration.
- [x] Define a small Xorg/Openbox package set.
- [x] Add initial top-bar, dock, and session defaults.
- [ ] Check that the build host provides compatible `live-build` and `debootstrap` tools.
- [ ] Configure the image on the user's machine.
- [ ] Build the first ISO and boot it in a VM.

**Exit condition:** repeatable boot to the Mac OS Linux graphical session in a VM.

## Phase 2 — Hardware validation

- [ ] Verify Intel G41 display mode and Mesa renderer.
- [ ] Test keyboard, USB mouse, audio, Ethernet, and Wi-Fi.
- [ ] Measure idle RAM and boot time on the Core 2 Duo target.
- [ ] Adjust services and package selection for 2 GiB RAM.

**Exit condition:** stable graphical session and documented hardware limitations.

## Phase 3 — Mac OS Linux desktop

- [ ] Define project design tokens, icons, typography, and wallpapers.
- [ ] Develop a project-owned top bar and dock.
- [ ] Develop launcher and Control Center.
- [ ] Develop first-party settings and file-manager integration.
- [ ] Add keyboard shortcuts, workspaces, accessibility, and localization.

**Exit condition:** a recognizably Mac OS Linux desktop that does not depend on Tint2/Plank for its primary shell.

## Phase 4 — Distribution engineering

- [ ] Define package repositories, update signing, rollback, and recovery.
- [ ] Add a safe graphical installer.
- [ ] Add live-session and installed-system setup flows.

**Exit condition:** install, update, and recover the system in a test VM.

## Phase 5 — Alpha release

- [ ] Run boot, install, update, hardware, and recovery tests.
- [ ] Publish checksums, release notes, and known issues.
- [ ] Produce the first installable ISO.
