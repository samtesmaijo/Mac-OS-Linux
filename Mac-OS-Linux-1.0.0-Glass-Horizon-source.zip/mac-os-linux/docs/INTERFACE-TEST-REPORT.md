# Relatório de validação — Mac OS Linux 1.0.0 / Glass Horizon

## Escopo

Este relatório trata da nova camada de interface C/GTK3 do Mac OS Linux 1.0.0. O desktop base continua sendo Xorg + Openbox, com Tint2, Plank, Picom/XRender e dunst. Os resultados antigos da UI R1 foram preservados em [`INTERFACE-TEST-REPORT-R1.md`](INTERFACE-TEST-REPORT-R1.md) e não certificam a implementação atual.

## Resultado estático nesta preparação

Comando executado:

```sh
NO_X=1 sh scripts/test-interface.sh
```

| Resultado | Quantidade | Interpretação |
|---|---:|---|
| Aprovados | 72 | Verificações estáticas e de integração de arquivos passaram nesta revisão. |
| Falhas | 0 | Nenhuma falha detectada pela bateria estática. |
| Ignorados | 5 | Dependências opcionais ausentes ou testes de servidor X desativados. |

Os testes cobrem sintaxe dos scripts shell, wrappers executáveis, referências de menus, arquivos `.desktop`, itens do Dock, renderização de templates claro/escuro e três níveis de transparência, presença da fonte GTK3, destino de instalação no Makefile, integração dos comandos de Wi-Fi/Bluetooth, ausência de runtime Python adicional e rejeição de argumentos inválidos no `macoslinux-ctl`.

**Atenção:** a contagem acima deve ser atualizada após qualquer alteração na bateria. O teste estático não compila nem executa a aplicação GTK3 quando os headers GTK3 não estão instalados no host.

## Bloqueios e testes pendentes

- Compilação real do aplicativo C/GTK3 (`make ui-build`); este ambiente de preparação não possui `libgtk-3-dev`.
- Validação visual do Centro de Controle, Configurações e Launcher em uma sessão Xorg real.
- Build da nova ISO 1.0.0 com `sudo lb build`.
- Boot da nova ISO em BIOS/Legacy e UEFI.
- Teste no Core 2 Duo E7500 + Intel G41/i915, incluindo teclado, mouse USB, rede, áudio e resolução.
- Medição de consumo de RAM/CPU da nova aplicação em repouso e sob uso.

A ISO 0.1.0 anterior foi iniciada no hardware do usuário. Isso demonstra a inicialização da base anterior, não valida a nova interface 1.0.0.

## Como reproduzir

```sh
make ui-test
NO_X=1 make ui-test
make ui-build
make prepare-iso
```

Para validar o visual e o runtime, execute os aplicativos dentro da sessão Xorg do sistema compilado. Não declarar a UI concluída antes do build e do teste no hardware real.
