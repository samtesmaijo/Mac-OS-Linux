# shellcheck shell=sh
# Mac OS Linux — funções compartilhadas pelos scripts da interface (POSIX sh).
# Princípios: nunca derrubar a sessão; qualquer falha vira log e segue adiante.

ML_SHARE="${ML_SHARE:-/usr/share/macoslinux}"
ML_CONF_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/macoslinux"
ML_CACHE_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/macoslinux"
ML_STATE="$ML_CONF_DIR/ui.conf"
ML_LOG="$ML_CACHE_DIR/ui.log"

have() { command -v "$1" >/dev/null 2>&1; }

ml_log() {
    mkdir -p "$ML_CACHE_DIR" 2>/dev/null || return 0
    # mantém o log pequeno (últimas ~200 linhas)
    if [ -f "$ML_LOG" ] && [ "$(wc -l <"$ML_LOG" 2>/dev/null || echo 0)" -gt 400 ]; then
        tail -n 200 "$ML_LOG" >"$ML_LOG.tmp" 2>/dev/null && mv "$ML_LOG.tmp" "$ML_LOG"
    fi
    printf '%s %s\n' "$(date '+%H:%M:%S')" "$*" >>"$ML_LOG" 2>/dev/null
    return 0
}

# ---- estado do usuário (~/.config/macoslinux/ui.conf), apenas KEY=valor ----
ml_get() { # chave padrão
    v=$(sed -n "s/^$1=//p" "$ML_STATE" 2>/dev/null | tail -n 1)
    if [ -n "$v" ]; then printf '%s' "$v"; else printf '%s' "$2"; fi
}

ml_set() { # chave valor
    mkdir -p "$ML_CONF_DIR" 2>/dev/null || return 1
    tmp="$ML_STATE.$$"
    { grep -v "^$1=" "$ML_STATE" 2>/dev/null; printf '%s=%s\n' "$1" "$2"; } >"$tmp" 2>/dev/null &&
        mv "$tmp" "$ML_STATE"
}

ml_theme()        { case "$(ml_get THEME dark)" in light) echo light ;; *) echo dark ;; esac; }
ml_transparency() { case "$(ml_get TRANSPARENCY glass)" in reduced) echo reduced ;; solid) echo solid ;; *) echo glass ;; esac; }
ml_motion()       { case "$(ml_get MOTION full)" in reduced) echo reduced ;; *) echo full ;; esac; }
ml_bool()         { case "$(ml_get "$1" "$2")" in 1 | on | true) echo 1 ;; *) echo 0 ;; esac; }

# ---- processos (apenas do próprio usuário) ----
ml_running() { pgrep -u "$(id -u)" -x "$1" >/dev/null 2>&1; }

ml_stop() { # nome — encerra e espera até 2 s
    ml_running "$1" || return 0
    pkill -u "$(id -u)" -x "$1" >/dev/null 2>&1
    n=0
    while ml_running "$1" && [ "$n" -lt 20 ]; do
        sleep 0.1
        n=$((n + 1))
    done
    return 0
}

ml_bg() { # inicia comando em segundo plano, sem herdar stdin/stdout
    nohup "$@" >/dev/null 2>&1 </dev/null &
}

# ---- XML / shell quoting (usado pelos pipemenus do Openbox) ----
ml_xml() { # escapa texto para XML (argumentos ou stdin)
    if [ "$#" -gt 0 ]; then printf '%s' "$*"; else cat; fi |
        sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g' -e 's/"/\&quot;/g' -e "s/'/\&apos;/g"
}

ml_sq() { # aspas simples seguras para shell
    printf "'%s'" "$(printf '%s' "$1" | tr -d '\000-\037' | sed "s/'/'\\\\''/g")"
}

# ---- renderização de modelos (@TOKEN@) com os tokens do tema ----
# uso: ml_render modelo saída
ml_render() {
    tpl="$1"; out="$2"
    theme=$(ml_theme)
    conf="$ML_SHARE/themes/$theme.conf"
    [ -r "$tpl" ] && [ -r "$conf" ] || return 1
    case "$(ml_transparency)" in
        reduced) alpha=88 ;;
        solid) alpha=100 ;;
        *) alpha=72 ;;
    esac
    alpha255=$((alpha * 255 / 100))
    notif_t=$(((100 - alpha) / 2))
    motion_ms=250
    [ "$(ml_motion)" = reduced ] && motion_ms=1
    script=$(sed -n 's/^\([A-Z_0-9]*\)="\(.*\)"$/s|@\1@|\2|g/p' "$conf")
    mkdir -p "$(dirname "$out")" 2>/dev/null || return 1
    tmp="$out.$$"
    if sed -e "$script" \
        -e "s|@ALPHA@|$alpha|g" \
        -e "s|@ALPHA255@|$alpha255|g" \
        -e "s|@NOTIF_TRANSPARENCY@|$notif_t|g" \
        -e "s|@MOTION_MS@|$motion_ms|g" "$tpl" >"$tmp" 2>/dev/null && [ -s "$tmp" ]; then
        # nenhum @TOKEN@ pode sobrar: modelo e tokens fora de sincronia = erro
        if grep -q '@[A-Z_0-9]*@' "$tmp"; then
            ml_log "render: tokens não resolvidos em $tpl: $(grep -o '@[A-Z_0-9]*@' "$tmp" | sort -u | tr '\n' ' ')"
            rm -f "$tmp"
            return 1
        fi
        mv "$tmp" "$out"
        return 0
    fi
    rm -f "$tmp"
    return 1
}

# ---- GSettings do Plank sem D-Bus/dconf: backend "keyfile" ----
ml_gs() { GSETTINGS_BACKEND=keyfile gsettings "$@"; }
ML_PLANK_SCHEMA="net.launchpad.plank.dock.settings"
ML_PLANK_PATH="/net/launchpad/plank/docks/dock1/"
ml_plank_set() { # chave valor(GVariant)
    have gsettings || return 1
    ml_gs set "$ML_PLANK_SCHEMA:$ML_PLANK_PATH" "$1" "$2" 2>/dev/null
}

# ---- áudio (WirePlumber/PipeWire; fallback PulseAudio-compat) ----
ml_vol_get() { # imprime "N muted|unmuted"; falha se não houver áudio
    if have wpctl; then
        out=$(LC_ALL=C timeout 2 wpctl get-volume @DEFAULT_AUDIO_SINK@ 2>/dev/null) || out=""
        if [ -n "$out" ]; then
            printf '%s\n' "$out" | awk '{ v=int($2*100+0.5); m=($0 ~ /MUTED/) ? "muted" : "unmuted"; print v, m }'
            return 0
        fi
    fi
    if have pactl; then
        v=$(LC_ALL=C timeout 2 pactl get-sink-volume @DEFAULT_SINK@ 2>/dev/null | sed -n 's/.* \([0-9]*\)%.*/\1/p' | head -n 1)
        m=$(LC_ALL=C timeout 2 pactl get-sink-mute @DEFAULT_SINK@ 2>/dev/null | sed -n 's/^Mute: *//p')
        if [ -n "$v" ]; then
            [ "$m" = yes ] && m=muted || m=unmuted
            echo "$v $m"
            return 0
        fi
    fi
    return 1
}
