# PROMPT PARA CLAUDE — INTERFACE DO MAC OS LINUX INSPIRADA NO macOS 27 GOLDEN GATE

Você é um engenheiro sênior de Linux Desktop, Debian Live-Build, X11, Openbox, GTK e design de interfaces de sistemas operacionais. Sua tarefa é desenvolver a interface gráfica do projeto **Mac OS Linux 0.1.0 Alpha (R3)**, inspirada na linguagem visual do **macOS 27 Golden Gate**, mas mantendo identidade própria do projeto.

## 1. Objetivo

Transformar a sessão gráfica inicial do Mac OS Linux em um desktop coeso, polido, moderno e utilizável: barra superior, menu de aplicativos, Dock inferior, janelas, menus de contexto, notificações, seletor de aplicativos, painel de controles rápidos, papel de parede, ícones, animações e configurações visuais.

O resultado deve parecer um sistema operacional cuidadosamente projetado, não apenas um tema aplicado sobre o Openbox. Todas as funções exibidas precisam funcionar de verdade. Não crie botões decorativos sem ação.

Use o macOS 27 como referência visual: Liquid Glass mais legível, refração uniforme, contraste reforçado, barras de ferramentas consistentes, sidebars de ponta a ponta, cantos de janela mais coerentes, ícones de barra de menu refinados e controle do nível de transparência. Traduza esses princípios para tecnologias Linux/X11 sem copiar recursos proprietários, nomes de apps, logotipos ou assets da Apple.

## 2. Estado técnico real do projeto

O projeto é uma distribuição live baseada em **Debian 13 Trixie amd64**, construída com `live-build` no Zorin OS 18 / Ubuntu 24.04-derived host.

Arquitetura atual que deve ser preservada:
- Kernel: `linux-image-amd64` (kernel Debian).
- Init: systemd.
- Display server: Xorg.
- Display manager: LightDM + lightdm-gtk-greeter.
- Window manager: Openbox.
- Top panel: Tint2.
- Dock: Plank.
- File manager: PCManFM (`pcmanfm`).
- Terminal: LXTerminal (`lxterminal`).
- Network: NetworkManager + `network-manager-gnome` / `nm-applet` quando disponível.
- Audio: PipeWire + WirePlumber + PulseAudio compatibility tools, `pavucontrol`, ALSA.
- Graphics: Mesa + Intel `i915` / Xorg modesetting.
- Compositor: Picom 12.5, configurado para backend `xrender`.

Arquivos importantes atuais:
- `config/package-lists/macoslinux-core.list.chroot`
- `config/includes.chroot/etc/skel/.config/openbox/autostart`
- `config/includes.chroot/etc/xdg/tint2/macoslinux.tint2rc`
- `config/includes.chroot/etc/xdg/picom/macoslinux.conf`
- `config/includes.chroot/etc/skel/.config/plank/dock1/launchers/`
- `config/includes.chroot/usr/share/applications/`
- `config/includes.chroot/usr/share/xsessions/macoslinux.desktop`
- `config/distro.conf`
- `auto/config`
- `config/bootloaders/isolinux/` no ambiente local do desenvolvedor, quando fornecido.

O desktop inicia e já foi possível abrir o terminal com clique direito. O Plank já apareceu, mas antes estava vazio. Foram adicionados atalhos para Arquivos e Terminal. Picom 12.5 e `libglib2.0-bin` foram instalados no chroot. As configurações do Picom, Tint2 e Openbox foram copiadas pelo Live-Build.

A máquina de teste é limitada:
- Intel Core 2 Duo E7500, 2 núcleos, 2,93 GHz.
- Aproximadamente 1,9 GiB de RAM.
- GPU Intel 4 Series / G41, ID PCI `8086:2e32`, driver `i915`.
- Resolução habitual 1366x768; considere também 1024x768.
- QEMU usa TCG e 768 MB de memória para testes básicos.

**Restrição central:** desempenho e estabilidade importam mais do que efeitos chamativos. A interface deve permanecer utilizável nessa máquina.

## 3. Regras obrigatórias antes de editar

1. Faça uma inspeção completa da árvore do projeto e leia `README.md`, `docs/ARCHITECTURE.md`, `docs/ROADMAP.md`, `config/distro.conf`, `auto/config`, a lista de pacotes e todos os arquivos da sessão gráfica.
2. Diferencie arquivos realmente presentes no ZIP dos arquivos que só existem no diretório local do desenvolvedor. Não invente arquivos nem afirme que analisou algo que não recebeu.
3. Produza primeiro um diagnóstico curto da arquitetura atual e um plano de implementação por etapas.
4. Faça backup de cada arquivo que for alterar. Preserve os nomes e a organização existentes sempre que possível.
5. Não substitua o kernel, systemd, Xorg, LightDM, Openbox ou o processo de boot. Não converta o projeto para Wayland, GNOME, KDE, XFCE completo ou outro desktop pesado.
6. Não execute `lb clean`, não formate discos, não particione o host e não altere o sistema Zorin do desenvolvedor.
7. Não faça montagem recursiva de `/dev`, `/sys` ou `/proc` no host. Não use `umount -R -l` em caminhos do sistema hospedeiro. Deixe o Live-Build cuidar das montagens do chroot.
8. Não remova arquivos de bootloader, módulos ISOLINUX `.c32`, kernel, initrd, ISO anterior ou pastas de recuperação.
9. Não substitua ou sobrescreva `binary.hybrid.iso` sem criar uma cópia versionada primeiro. Se a ISO não estiver no arquivo enviado, não finja que foi testada.
10. Nunca invente suporte ou resultados. Diferencie “implementado”, “configurado”, “compilado” e “testado em QEMU”.

## 4. Direção visual

Crie uma identidade própria chamada **Mac OS Linux**. O sistema não é macOS e não deve usar o logotipo da Apple nem recursos proprietários extraídos do macOS. Use referências gerais de composição, translucidez, hierarquia, espaçamento, animações e consistência.

### 4.1 Linguagem visual
- Base escura elegante como padrão, com suporte a tema claro se isso puder ser implementado de forma leve.
- Superfícies de vidro fosco discretas, translucidez moderada e contraste suficiente para texto e ícones.
- Cantos arredondados coerentes, bordas finas e sombras suaves.
- Tipografia legível e hierarquia clara; prefira fontes já instaladas ou fontes livres distribuídas legalmente.
- Ícones consistentes, preferencialmente do tema livre instalado; não misture emojis com ícones do sistema.
- Espaçamento generoso, sem desperdiçar a área de uma tela 1366x768.
- Todos os elementos devem ficar legíveis sobre wallpapers claros e escuros.

### 4.2 Barra superior
Projetar uma barra de menu superior fina e translúcida com:
- Identidade/menu “Mac OS Linux” à esquerda.
- Menus funcionais: Sistema, Arquivo, Editar, Janela e Ajuda, ou estrutura equivalente coerente com a aplicação ativa.
- Indicador de aplicativo/janela ativa quando tecnicamente viável.
- Área de status à direita: rede, som, bateria apenas quando houver hardware, notificações e relógio/calendário.
- Menu de controles rápidos acionável, com controles reais de volume, rede e brilho apenas quando suportados.
- Não mostrar status falso: se não houver bateria ou Bluetooth, não invente o ícone/estado.

Tint2 pode continuar como base, mas avalie honestamente suas limitações. Se for necessário um componente leve adicional para menus ou indicadores, justifique a dependência, o impacto de RAM e o comportamento em X11. Não instale um desktop completo para resolver um painel.

### 4.3 Dock inferior
- Dock centralizado, com superfície translúcida e sombra discreta.
- Atalhos somente para aplicações realmente instaladas.
- No mínimo: Arquivos e Terminal; inclua navegador, configurações e controle de áudio/rede somente se estiverem disponíveis na imagem.
- Ampliação dos ícones no hover, com limites suaves e sem saltos excessivos.
- Indicador discreto de aplicativos abertos.
- Tooltips corretos e nomes acessíveis.
- Clique direito deve apresentar ações úteis se suportadas.
- Configuração de ocultação automática deve ser consistente e não cobrir janelas ou notificações.
- Teste se os arquivos `.dockitem`, ícones e schema GSettings correspondem à versão real do Plank instalada. Não presuma nomes de schema/chaves: consulte `gsettings list-schemas`, `gsettings list-recursively` e documentação local.

### 4.4 Janelas e compositor
- Criar uma decoração Openbox própria, com controles coerentes inspirados no tráfego de janelas de desktops modernos, sem copiar os recursos gráficos da Apple.
- Estados ativo/inativo bem distintos, títulos legíveis, bordas discretas e áreas de arraste adequadas.
- Picom 12.5 usa XRender por compatibilidade com Intel G41. Priorize sombras, transparência controlada e fade leve.
- Verifique as opções realmente suportadas pela versão instalada com `picom --help`, `man picom` e teste de configuração. Não adicione opções de forks ou versões recentes sem comprovação.
- Não afirme que fade simples equivale a animação de minimizar/maximizar. Use apenas transições comprovadamente suportadas.
- Não force blur pesado, filtros ou sombras excessivas que prejudiquem o Intel G41.
- Se arredondamento real não for suportado pela versão instalada, não finja: proponha uma alternativa visual por tema de janela ou explique a limitação.

### 4.5 Centro de Controle / Quick Settings
Criar um painel compacto com visual moderno e cartões organizados para:
- Rede Wi-Fi/Ethernet (integrar ao NetworkManager; não simular botão de Wi-Fi se não houver dispositivo).
- Volume e saída de áudio (PipeWire/PulseAudio; abrir Pavucontrol quando apropriado).
- Brilho (somente quando houver interface de backlight suportada; caso contrário, ocultar/desabilitar com explicação).
- Tema claro/escuro, transparência e comportamento do Dock, se implementados de forma funcional.
- Data, hora e notificações.

Qualquer controle deve consultar o estado atual, executar uma ação real e refletir sucesso/erro. Evite scripts que só mudem a aparência sem alterar o estado do sistema.

### 4.6 Menus, janelas auxiliares e desktop
- Menu de aplicativos pesquisável ou organizado por categorias.
- Menu de contexto do desktop funcional.
- Atalhos de teclado documentados.
- Gerenciador de arquivos com tema e ícones integrados.
- Tela de login do LightDM coerente com o desktop, preservando acesso de teclado e contraste.
- Wallpaper original do Mac OS Linux, leve, em resolução compatível; não use wallpaper proprietário da Apple.

## 5. Animações: escopo realista

Priorizar:
- Zoom dos ícones do Dock no hover.
- Fade-in/fade-out suave de painéis e menus, se suportado.
- Transições curtas de abertura/fechamento de popovers.
- Hover e pressed states discretos.
- Reduzir ou desativar efeitos quando a máquina estiver sob carga ou quando o usuário habilitar “Reduzir movimento”.

Limites:
- Não utilizar blur em tela inteira.
- Não usar partículas, parallax pesado ou animações contínuas.
- Não colocar animações em cada atualização da área de trabalho.
- Respeitar acessibilidade e preferência de reduzir movimento/transparência.
- Se a tecnologia escolhida não suportar um efeito, explique e não o simule com um hack frágil.

## 6. Tecnologias e dependências

- Reutilize primeiro o que já existe: Openbox, Tint2, Plank, Picom, PCManFM, LXTerminal, NetworkManager, PipeWire e ferramentas X11.
- Não usar Electron, Chromium embutido, navegador fullscreen como desktop, Node.js como runtime central ou Python como runtime obrigatório da interface.
- Prefira configuração nativa e ferramentas C/GTK leves quando um componente novo for realmente necessário.
- Antes de adicionar pacote, confirme que existe no Debian 13 Trixie amd64, confira dependências e estime o impacto no tamanho da ISO e no consumo de RAM.
- Mantenha o conjunto enxuto. Não instalar GNOME Shell, KDE Plasma, Cinnamon, Budgie ou outro desktop completo.
- Não adicionar pacotes duplicados ou conflitantes. A lista atual usa `polkitd`, não o pacote antigo `policykit-1`.

## 7. Qualidade, testes e aceitação

A implementação só deve ser considerada concluída quando houver evidência dos testes aplicáveis:

1. `sh -n` em scripts de inicialização.
2. Validação do arquivo Picom usando o próprio Picom instalado.
3. Validação de sintaxe/parse de Tint2 e Openbox, quando houver ferramentas disponíveis.
4. Verificação de cada `.desktop` com `desktop-file-validate` se instalado.
5. Verificação de que os aplicativos referenciados pelos launchers existem no sistema.
6. Verificação de schemas e chaves GSettings antes de configurar o Plank.
7. Inicialização de sessão Openbox em Xorg sem processos duplicados de Picom/Tint2/Plank.
8. Teste em 1366x768 e 1024x768.
9. Teste de consumo de RAM em repouso e com uma janela aberta; registrar números reais.
10. Teste em QEMU antes de declarar que a interface foi validada.

Critérios visuais:
- Barra superior não encobre janelas nem fica com texto cortado.
- Dock aparece centralizado, possui atalhos válidos e não fica vazio.
- Os ícones mantêm proporção e não tremem durante o zoom.
- Sombras não criam retângulos pretos nem artefatos de composição.
- Transparência não reduz a legibilidade.
- Menus e controles podem ser usados por mouse e teclado.
- O desktop inicia mesmo se o Picom ou Plank falhar; o usuário ainda consegue abrir o terminal.

## 8. Entregáveis esperados

1. Interface implementada nos arquivos corretos do projeto, sem modificar a base de boot desnecessariamente.
2. Todos os scripts, temas, configurações e assets necessários incluídos dentro de `config/includes.chroot` ou nos caminhos coerentes de live-build.
3. Lista de pacotes atualizada e validada contra Debian Trixie.
4. Backup dos arquivos originais alterados.
5. `docs/INTERFACE-DESIGN.md` explicando os componentes, arquitetura e como mudar tema, transparência e animação.
6. `docs/INTERFACE-TEST-REPORT.md` com comandos executados, resultados observados, itens não testados e limitações reais.
7. Um ZIP de código-fonte atualizado, sem pastas temporárias gigantes (`chroot`, `.build`, `binary`) a menos que o usuário peça explicitamente a ISO dentro do ZIP.
8. Instruções de compilação/teste específicas para esta configuração R3 de live-build.

## 9. Como trabalhar

- Não responda apenas com um plano ou mockup. Faça as alterações reais nos arquivos do projeto que foram fornecidos.
- Trabalhe em etapas pequenas e reversíveis: auditoria; design system; sessão/painéis; dock; janelas/compositor; controles rápidos; testes; documentação; ZIP.
- Após cada etapa, mostre os arquivos criados/modificados e os testes realizados.
- Se houver algo que dependa de uma decisão minha, adote a alternativa mais segura e de baixo consumo, registre a suposição e continue. Só pare quando uma informação essencial realmente não puder ser inferida.
- Não diga que compilou ou testou a ISO se você não executou esses passos.
- Ao final, entregue o ZIP atualizado e um resumo curto das funcionalidades realmente prontas, das que ainda são protótipos e das que não puderam ser testadas.

**Prioridade final:** entregar uma interface própria, elegante e reconhecível como Mac OS Linux, com inspiração na evolução visual do macOS 27 Golden Gate, mas rápida, legível, funcional e estável no hardware Intel G41 de baixo desempenho.

Referências públicas de design (use apenas como referência visual/conceitual):
- https://www.apple.com/br/os/macos/
- https://support.apple.com/en-us/127257
- https://developer.apple.com/videos/wwdc2026/102/
