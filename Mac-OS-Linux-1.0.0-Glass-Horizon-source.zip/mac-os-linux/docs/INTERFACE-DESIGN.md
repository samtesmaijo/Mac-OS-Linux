# Interface do Mac OS Linux 1.0.0 — Glass Horizon

## Direção de design

**Glass Horizon** é a linguagem visual original do Mac OS Linux 1.0.0. Ela combina superfícies em camadas, transparência moderada, reflexos e gradientes discretos, bordas finas, sombras contidas, cantos arredondados e contraste forte para texto e controles.

A pesquisa de macOS 27 Golden Gate foi usada como referência de direção — especialmente legibilidade sobre materiais, sidebars integradas e hierarquia de toolbar — e os projetos WhiteSur GTK, Mojave GTK e WhiteSur Icon Theme foram estudados como referências de arquitetura de temas Linux. Nenhum código, ícone, wallpaper, fonte, logo ou outro asset desses projetos ou da Apple foi copiado para esta implementação. As fontes de pesquisa e links estão em [`MACOS27-RESEARCH.md`](MACOS27-RESEARCH.md).

Não é uma implementação da tecnologia Liquid Glass da Apple nem uma reprodução de seu material físico. GTK3/CSS oferece composição visual e alfa; o desfoque de fundo é um recurso opcional do Picom e fica desligado por padrão para preservar o Intel G41 e CPUs antigas.

## Princípios

1. **Legibilidade primeiro:** texto e controles não dependem de transparência forte; os modos reduzido e sólido continuam disponíveis.
2. **Uma hierarquia consistente:** título, subtítulo, cartão, controle e estado têm estilos e espaçamentos previsíveis.
3. **Feedback de estado:** controles indicam disponibilidade do hardware e estado conhecido quando a janela é aberta.
4. **Desempenho adaptável:** sem blur por padrão, sem animações pesadas e sem um ambiente GNOME/KDE completo.
5. **Identidade própria:** nome, logos e ícones definitivos dos aplicativos serão desenhados como assets originais em uma etapa separada.

## Stack

| Camada | Implementação | Responsabilidade |
|---|---|---|
| Barra superior | Tint2 | Menu do sistema, aplicativo ativo, relógio e atalhos de estado |
| Dock | Plank | Aplicativos fixos, tooltips, ampliação e indicadores |
| Janelas | Openbox + Picom/XRender | Foco, posicionamento, sombras e composição leve |
| Centro de Controle | C + GTK3 | Ações rápidas, volume, rádios e acesso a Configurações |
| Configurações | C + GTK3 | Preferências e painéis agrupados em sidebar |
| Launcher | C + GTK3 + GIO | Pesquisa e abertura de aplicativos `.desktop` instalados |
| Backend | POSIX shell (`macoslinux-ctl`) | Aplicação de preferências e integração com serviços do sistema |
| Tema | GTK3 CSS próprio | Tema claro/escuro, controles, estados e menus GTK |

A interface principal é compilada de `apps/macoslinux-ui.c`. O binário de nome único `macoslinux-ui-native` é instalado no overlay por `make ui-build`; os wrappers `macoslinux-control-center`, `macoslinux-settings` e `macoslinux-launcher` iniciam o modo correspondente. Não existe um dispatcher Python concorrente.

## Superfícies e atalhos

- `Super + C`: Centro de Controle.
- `Super + I`: Configurações do Sistema.
- `Super + Espaço`: Launcher de aplicativos.
- `Super + Alt + A`: Launcher como atalho alternativo.

## Centro de Controle

Painel flutuante e compacto, alinhado próximo ao canto superior direito. Inclui cartões de Wi-Fi, Bluetooth, Foco/Não Perturbe, Aparência e acesso às Configurações; controle deslizante de volume; botão de mudo; atalho para dispositivos de áudio; e controle de brilho somente quando o host expõe `/sys/class/backlight` e `brightnessctl`.

O estado é consultado ao abrir o painel. A atualização contínua dos cartões depois de um clique ainda é uma melhoria futura; feche e reabra o painel para consultar novamente o estado atual.

## Configurações do Sistema

Janela principal com headerbar, sidebar e área de conteúdo com rolagem e transição curta entre páginas.

| Página | Controles e informações | Backend |
|---|---|---|
| Geral | Versão, sistema, CPU e memória detectados; atalhos Rede e Som | `/proc`, `uname`, aplicações locais |
| Aparência | Claro/escuro, vidro/reduzido/sólido, movimento reduzido e blur experimental | `macoslinux-ctl` |
| Dock | Auto-ocultar, ampliação e tamanhos 36/46/56 | `macoslinux-ctl dock` e GSettings do Plank |
| Rede | Estado de dispositivos, Wi-Fi, Bluetooth e editor de conexões | NetworkManager (`nmcli`), `rfkill`, `nm-connection-editor` |
| Som | Volume, mudo, estado do áudio e dispositivos | `macoslinux-ctl`, PipeWire/PulseAudio, `pavucontrol` |
| Tela | Ferramenta de monitores, modos XRandR e brilho quando suportado | `arandr`, `xrandr`, `brightnessctl` |
| Notificações | Não Perturbe e histórico | `dunstctl` |
| Sobre | Versão, base, kernel, CPU, RAM e sessão gráfica | Sistema local |

## Launcher de aplicativos

O Launcher usa GIO para consultar as entradas `.desktop` instaladas, remove IDs duplicados, ordena os nomes e oferece busca por nome. Os ícones são carregados do tema de ícones instalado no sistema; a família visual definitiva de ícones de aplicativos será substituída por desenhos originais na próxima etapa de identidade.

## Materiais, temas e acessibilidade

- Tema claro e escuro próprios em `config/includes.chroot/usr/share/themes/MacOSLinux/gtk-3.0/`.
- O app GTK aplica uma paleta Glass Horizon compatível com as preferências `THEME` e `TRANSPARENCY` do usuário.
- `glass`, `reduced` e `solid` representam níveis de transparência do projeto, não modos oficiais da Apple.
- `MOTION=reduced` reduz animações do desktop.
- `BLUR=0` é o padrão recomendado no computador Intel G41; o usuário pode ativar blur experimental por sua conta.

## Build

No Zorin OS/Ubuntu, instalar ferramentas de compilação:

```bash
sudo apt update
sudo apt install -y build-essential pkg-config libgtk-3-dev
```

Depois, na raiz do projeto:

```bash
make ui-build
make ui-test
make configure
```

`make prepare-iso` executa essas etapas em sequência e prepara a configuração Live-Build. Para gerar a ISO:

```bash
sudo lb clean
sudo lb build 2>&1 | tee build.log
```

## Estado

A fonte e a integração estática estão preparadas. A compilação C/GTK3, o teste visual em execução, a nova ISO 1.0.0 e o boot da nova versão no Core 2 Duo E7500/G41 ainda precisam ser validados. A ISO 0.1.0 que o usuário já iniciou é a versão anterior e não comprova o runtime da nova interface.
