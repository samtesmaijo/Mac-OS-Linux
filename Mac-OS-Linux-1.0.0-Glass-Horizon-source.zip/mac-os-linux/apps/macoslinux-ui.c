/*
 * Mac OS Linux 1.0.0 — first-party GTK3 interface
 *
 * Lightweight control center and settings application for the Xorg/Openbox
 * session.  The implementation uses GTK3 and the existing macoslinux-ctl
 * backend; it does not start a heavyweight desktop environment.
 *
 * Copyright (c) Mac OS Linux Project
 * SPDX-License-Identifier: MIT
 */

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <glib.h>
#include <gio/gio.h>
#include <stdlib.h>
#include <string.h>

#define APP_VERSION "1.0.0"
#define APP_ID "org.macoslinux.Settings"

static GtkWidget *main_window;
static GtkWidget *settings_stack;
static GtkWidget *settings_heading;
static GtkWidget *settings_subheading;
static GtkWidget *volume_value_label;
static guint volume_timeout_id;
static gboolean updating_widgets;
static gboolean control_mode;
static gboolean launcher_mode;
static gchar *active_page;

static gchar *
command_output(const gchar *command)
{
    gchar *out = NULL;
    gint status = 0;
    GError *error = NULL;

    if (!g_spawn_command_line_sync(command, &out, NULL, &status, &error)) {
        g_clear_error(&error);
        return g_strdup("");
    }
    if (!g_spawn_check_wait_status(status, NULL)) {
        g_free(out);
        return g_strdup("");
    }
    g_strstrip(out);
    return out;
}

static gboolean
run_command(const gchar *command)
{
    GError *error = NULL;
    gboolean ok = g_spawn_command_line_async(command, &error);
    if (!ok) {
        GtkWidget *dialog = gtk_message_dialog_new(
            main_window ? GTK_WINDOW(main_window) : NULL,
            GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR, GTK_BUTTONS_CLOSE,
            "Não foi possível executar a ação.");
        gtk_message_dialog_format_secondary_text(GTK_MESSAGE_DIALOG(dialog),
                                                  "%s", error->message);
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        g_clear_error(&error);
    }
    return ok;
}

static gchar *
read_setting(const gchar *key, const gchar *fallback)
{
    const gchar *home = g_get_home_dir();
    gchar *path = g_build_filename(home, ".config", "macoslinux", "ui.conf", NULL);
    gchar *contents = NULL;
    gchar **lines;
    gchar *result = g_strdup(fallback);
    guint i;

    if (!g_file_get_contents(path, &contents, NULL, NULL)) {
        g_free(path);
        return result;
    }
    lines = g_strsplit(contents, "\n", -1);
    for (i = 0; lines[i] != NULL; i++) {
        gchar *prefix = g_strdup_printf("%s=", key);
        if (g_str_has_prefix(lines[i], prefix)) {
            g_free(result);
            result = g_strdup(lines[i] + strlen(prefix));
            g_free(prefix);
            break;
        }
        g_free(prefix);
    }
    g_strfreev(lines);
    g_free(contents);
    g_free(path);
    return result;
}


static gchar *
read_cpu_model(void)
{
    gchar *contents = NULL;
    gchar **lines;
    gchar *result = NULL;

    if (!g_file_get_contents("/proc/cpuinfo", &contents, NULL, NULL))
        return g_strdup("não identificado");
    lines = g_strsplit(contents, "\n", -1);
    for (guint i = 0; lines[i] != NULL; i++) {
        if (g_str_has_prefix(lines[i], "model name")) {
            gchar *colon = strchr(lines[i], ':');
            if (colon) {
                result = g_strdup(colon + 1);
                g_strstrip(result);
            }
            break;
        }
    }
    g_strfreev(lines);
    g_free(contents);
    return result ? result : g_strdup("não identificado");
}

static gchar *
read_memory_total(void)
{
    gchar *contents = NULL;
    gchar **lines;
    gchar *result = NULL;

    if (!g_file_get_contents("/proc/meminfo", &contents, NULL, NULL))
        return g_strdup("não identificada");
    lines = g_strsplit(contents, "\n", -1);
    for (guint i = 0; lines[i] != NULL; i++) {
        if (g_str_has_prefix(lines[i], "MemTotal:")) {
            gchar **parts = g_strsplit_set(lines[i], " \t", -1);
            for (guint j = 0; parts[j] != NULL; j++) {
                if (*parts[j]) {
                    gchar *end = NULL;
                    guint64 kib = g_ascii_strtoull(parts[j], &end, 10);
                    if (end && *end == '\0' && kib > 0)
                        result = g_strdup_printf("%.1f GiB", (gdouble)kib / 1048576.0);
                    break;
                }
            }
            g_strfreev(parts);
            break;
        }
    }
    g_strfreev(lines);
    g_free(contents);
    return result ? result : g_strdup("não identificada");
}

static gboolean
command_available(const gchar *command)
{
    gchar *path = g_find_program_in_path(command);
    gboolean found = path != NULL;
    g_free(path);
    return found;
}

static gboolean
wifi_device_present(void)
{
    gchar *out = command_output("nmcli -t -f TYPE device");
    gboolean found = g_strstr_len(out, -1, "wifi") != NULL;
    g_free(out);
    return found;
}

static gboolean
bluetooth_device_present(void)
{
    gchar *out = command_output("rfkill list bluetooth");
    gboolean found = *out != '\0';
    g_free(out);
    return found;
}

static gboolean
bluetooth_is_enabled(void)
{
    gchar *out = command_output("rfkill list bluetooth");
    gboolean enabled = *out != '\0'
        && g_strstr_len(out, -1, "Soft blocked: yes") == NULL
        && g_strstr_len(out, -1, "Hard blocked: yes") == NULL;
    g_free(out);
    return enabled;
}

static gboolean
audio_available(void)
{
    gchar *out = command_output("macoslinux-ctl volume get");
    gboolean found = *out != '\0';
    g_free(out);
    return found;
}

static gboolean
brightness_available(void)
{
    GDir *dir = g_dir_open("/sys/class/backlight", 0, NULL);
    const gchar *name;
    gboolean found = FALSE;
    if (!dir)
        return FALSE;
    while ((name = g_dir_read_name(dir)) != NULL) {
        gchar *path = g_build_filename("/sys/class/backlight", name, "brightness", NULL);
        if (g_file_test(path, G_FILE_TEST_EXISTS))
            found = TRUE;
        g_free(path);
        if (found)
            break;
    }
    g_dir_close(dir);
    return found && command_available("brightnessctl");
}

static gboolean
wifi_is_enabled(void)
{
    gchar *out = command_output("nmcli radio wifi");
    gboolean enabled = g_strcmp0(out, "enabled") == 0;
    g_free(out);
    return enabled;
}

static gboolean
dnd_is_enabled(void)
{
    gchar *out = command_output("dunstctl is-paused");
    gboolean paused = g_strcmp0(out, "true") == 0;
    g_free(out);
    return paused;
}

static gboolean
setting_is(const gchar *key, const gchar *expected, const gchar *fallback)
{
    gchar *value = read_setting(key, fallback);
    gboolean result = g_strcmp0(value, expected) == 0;
    g_free(value);
    return result;
}

static void
apply_css(GtkWidget *window)
{
    gboolean dark = setting_is("THEME", "dark", "dark");
    gchar *transparency = read_setting("TRANSPARENCY", "glass");
    const gchar *background;
    const gchar *panel;
    const gchar *border;
    const gchar *text;
    const gchar *muted;
    const gchar *accent;
    gchar *css;
    GtkCssProvider *provider;
    GdkScreen *screen;

    if (dark) {
        background = "rgba(17, 22, 34, 0.88)";
        panel = "rgba(255, 255, 255, 0.085)";
        border = "rgba(255, 255, 255, 0.16)";
        text = "#f5f7fb";
        muted = "#b5bfce";
        accent = "#78aefc";
    } else {
        background = "rgba(246, 248, 252, 0.88)";
        panel = "rgba(255, 255, 255, 0.66)";
        border = "rgba(33, 48, 70, 0.14)";
        text = "#182235";
        muted = "#657286";
        accent = "#286ee6";
    }

    if (g_strcmp0(transparency, "solid") == 0) {
        background = dark ? "rgba(24, 29, 42, 0.98)" : "rgba(246, 248, 252, 0.98)";
        panel = dark ? "rgba(255, 255, 255, 0.11)" : "rgba(255, 255, 255, 0.94)";
    } else if (g_strcmp0(transparency, "reduced") == 0) {
        background = dark ? "rgba(20, 25, 38, 0.95)" : "rgba(246, 248, 252, 0.95)";
        panel = dark ? "rgba(255, 255, 255, 0.10)" : "rgba(255, 255, 255, 0.82)";
    }

    css = g_strdup_printf(
        "window#ml-window { background-color: %s; color: %s; border: 1px solid %s; border-radius: 24px; }"
        "#ml-shell { background-color: %s; color: %s; border: 1px solid %s; border-radius: 24px; }"
        ".ml-heading { color: %s; font-size: 19px; font-weight: 700; }"
        ".ml-title { color: %s; font-size: 14px; font-weight: 700; }"
        ".ml-subtitle { color: %s; font-size: 11px; }"
        ".ml-card { background-image: linear-gradient(145deg, rgba(255,255,255,0.055), rgba(255,255,255,0.00) 58%); background-color: %s; border: 1px solid %s; border-radius: 17px; padding: 13px; }"
        ".ml-tile { background-image: linear-gradient(145deg, rgba(255,255,255,0.075), rgba(255,255,255,0.00) 62%); background-color: %s; border: 1px solid %s; border-radius: 15px; padding: 12px; }"
        ".ml-tile-active { background-image: linear-gradient(145deg, rgba(255,255,255,0.15), rgba(255,255,255,0.015) 64%); background-color: %s; border: 1px solid %s; border-radius: 15px; padding: 12px; }"
        ".ml-pill { background-color: %s; border: 1px solid %s; border-radius: 12px; padding: 8px 12px; }"
        "button { color: %s; background-image: none; background-color: %s; border: 1px solid %s; border-radius: 11px; padding: 7px 11px; }"
        "button:hover { background-color: %s; border-color: %s; }"
        "button:active { background-color: %s; }"
        "button.flat { background-color: transparent; border-color: transparent; }"
        "button.flat:hover { background-color: %s; }"
        "scale trough { min-height: 7px; border-radius: 5px; background-color: %s; }"
        "scale highlight { border-radius: 5px; background-color: %s; }"
        "scale slider { min-width: 17px; min-height: 17px; border-radius: 10px; background-image: none; background-color: #ffffff; border: 1px solid rgba(0,0,0,0.14); }"
        "switch { background-color: %s; border: 1px solid %s; border-radius: 15px; }"
        "switch:checked { background-color: %s; }"
        "entry { color: %s; background-color: %s; border: 1px solid %s; border-radius: 9px; padding: 8px; }"
        "list row { border-radius: 10px; padding: 5px; }"
        "list row:selected { background-color: %s; }"
        "headerbar { min-height: 38px; padding: 4px 12px; background-image: linear-gradient(to bottom, rgba(255,255,255,0.10), rgba(255,255,255,0.025)); border-bottom: 1px solid %s; box-shadow: none; }"
        "button.ml-nav { text-align: left; background: transparent; border-color: transparent; border-radius: 10px; padding: 8px 10px; }"
        "button.ml-nav:hover { background-color: %s; }"
        "button.ml-nav-active { background-color: %s; border-color: %s; }"
        "button.ml-app-tile { min-height: 94px; padding: 13px 8px; background-image: linear-gradient(145deg, rgba(255,255,255,0.09), rgba(255,255,255,0.015)); background-color: %s; border: 1px solid %s; border-radius: 15px; }"
        "button.ml-app-tile:hover { background-color: %s; border-color: %s; }"
        "separator { background-color: %s; }",
        background, text, border,
        background, text, border,
        text, text, muted,
        panel, border,
        panel, border,
        dark ? "rgba(65, 126, 215, 0.36)" : "rgba(40, 110, 230, 0.15)", border,
        panel, border,
        text, panel, border,
        dark ? "rgba(255,255,255,0.16)" : "rgba(0,0,0,0.08)", accent,
        dark ? "rgba(255,255,255,0.22)" : "rgba(0,0,0,0.10)",
        panel,
        dark ? "rgba(255,255,255,0.12)" : "rgba(24,34,53,0.10)",
        accent,
        dark ? "rgba(255,255,255,0.20)" : "rgba(24,34,53,0.16)", border,
        accent,
        text, panel, border,
        dark ? "rgba(120,174,252,0.24)" : "rgba(40,110,230,0.13)",
        border,
        border,
        dark ? "rgba(255,255,255,0.055)" : "rgba(20,34,54,0.045)",
        dark ? "rgba(65,126,215,0.24)" : "rgba(40,110,230,0.13)",
        accent,
        panel, border,
        dark ? "rgba(255,255,255,0.12)" : "rgba(40,110,230,0.10)",
        accent,
        border);

    provider = gtk_css_provider_new();
    gtk_css_provider_load_from_data(provider, css, -1, NULL);
    screen = gtk_widget_get_screen(window);
    gtk_style_context_add_provider_for_screen(screen,
        GTK_STYLE_PROVIDER(provider), GTK_STYLE_PROVIDER_PRIORITY_APPLICATION + 10);
    g_object_unref(provider);
    g_free(css);
    g_free(transparency);
}

static GtkWidget *
label_new(const gchar *text, const gchar *css_class)
{
    GtkWidget *label = gtk_label_new(text);
    gtk_widget_set_halign(label, GTK_ALIGN_START);
    if (css_class)
        gtk_style_context_add_class(gtk_widget_get_style_context(label), css_class);
    return label;
}

static GtkWidget *
make_card(const gchar *title, const gchar *subtitle)
{
    GtkWidget *box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
    gtk_style_context_add_class(gtk_widget_get_style_context(box), "ml-card");
    if (title)
        gtk_box_pack_start(GTK_BOX(box), label_new(title, "ml-title"), FALSE, FALSE, 0);
    if (subtitle)
        gtk_box_pack_start(GTK_BOX(box), label_new(subtitle, "ml-subtitle"), FALSE, FALSE, 0);
    return box;
}

static GtkWidget *
icon_button(const gchar *icon, const gchar *label)
{
    GtkWidget *button = gtk_button_new();
    GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 9);
    GtkWidget *image = gtk_image_new_from_icon_name(icon, GTK_ICON_SIZE_BUTTON);
    GtkWidget *text = gtk_label_new(label);
    gtk_widget_set_halign(text, GTK_ALIGN_START);
    gtk_box_pack_start(GTK_BOX(row), image, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), text, TRUE, TRUE, 0);
    gtk_container_add(GTK_CONTAINER(button), row);
    return button;
}

static void
on_command_clicked(GtkButton *button, gpointer data)
{
    const gchar *command = (const gchar *)data;
    if (!command)
        command = g_object_get_data(G_OBJECT(button), "ml-command");
    if (command)
        run_command(command);
}

static void
on_open_settings(GtkButton *button, gpointer data)
{
    const gchar *command = data ? (const gchar *)data : "macoslinux-settings";
    (void)button;
    run_command(command);
    if (control_mode && main_window)
        gtk_widget_destroy(main_window);
}

typedef struct {
    const gchar *on_command;
    const gchar *off_command;
} SwitchCommands;

static void
on_switch_changed(GObject *object, GParamSpec *pspec, gpointer data)
{
    SwitchCommands *commands = data;
    gboolean active;
    (void)pspec;
    if (updating_widgets)
        return;
    active = gtk_switch_get_active(GTK_SWITCH(object));
    run_command(active ? commands->on_command : commands->off_command);
}

static SwitchCommands wifi_commands = { "macoslinux-ctl wifi on", "macoslinux-ctl wifi off" };
static SwitchCommands bluetooth_commands = { "macoslinux-ctl bluetooth on", "macoslinux-ctl bluetooth off" };
static SwitchCommands dnd_commands = { "macoslinux-ctl dnd on", "macoslinux-ctl dnd off" };
static SwitchCommands motion_commands = { "macoslinux-ctl motion reduced", "macoslinux-ctl motion full" };
static SwitchCommands blur_commands = { "macoslinux-ctl blur on", "macoslinux-ctl blur off" };
static SwitchCommands autohide_commands = { "macoslinux-ctl dock autohide on", "macoslinux-ctl dock autohide off" };
static SwitchCommands zoom_commands = { "macoslinux-ctl dock zoom on", "macoslinux-ctl dock zoom off" };

static gboolean
write_volume_value(gpointer data)
{
    gint value = GPOINTER_TO_INT(data);
    gchar *command;
    volume_timeout_id = 0;
    command = g_strdup_printf("macoslinux-ctl volume set %d", value);
    run_command(command);
    g_free(command);
    return G_SOURCE_REMOVE;
}

static void
on_volume_changed(GtkRange *range, gpointer data)
{
    gint value = (gint)gtk_range_get_value(range);
    gchar *label;
    (void)data;
    if (updating_widgets)
        return;
    if (volume_value_label) {
        label = g_strdup_printf("%d%%", value);
        gtk_label_set_text(GTK_LABEL(volume_value_label), label);
        g_free(label);
    }
    if (volume_timeout_id)
        g_source_remove(volume_timeout_id);
    volume_timeout_id = g_timeout_add(220, write_volume_value, GINT_TO_POINTER(value));
}

static GtkWidget *
volume_slider(gboolean compact)
{
    gchar *current = command_output("macoslinux-ctl volume get");
    gint value = 0;
    GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    GtkWidget *icon = gtk_image_new_from_icon_name("audio-volume-high-symbolic", GTK_ICON_SIZE_BUTTON);
    GtkWidget *scale = gtk_scale_new_with_range(GTK_ORIENTATION_HORIZONTAL, 0, 100, 1);
    gchar **parts = g_strsplit(current, " ", 2);
    if (parts[0] && *parts[0])
        value = CLAMP(atoi(parts[0]), 0, 100);
    gtk_scale_set_draw_value(GTK_SCALE(scale), FALSE);
    gtk_widget_set_hexpand(scale, TRUE);
    gtk_range_set_value(GTK_RANGE(scale), value);
    gtk_box_pack_start(GTK_BOX(row), icon, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), scale, TRUE, TRUE, 0);
    if (!compact) {
        volume_value_label = label_new("", "ml-subtitle");
        gchar *label = g_strdup_printf("%d%%", value);
        gtk_label_set_text(GTK_LABEL(volume_value_label), label);
        g_free(label);
        gtk_box_pack_start(GTK_BOX(row), volume_value_label, FALSE, FALSE, 0);
    }
    if (!audio_available())
        gtk_widget_set_sensitive(scale, FALSE);
    g_signal_connect(scale, "value-changed", G_CALLBACK(on_volume_changed), NULL);
    g_strfreev(parts);
    g_free(current);
    return row;
}

static GtkWidget *
make_switch_row(const gchar *title, const gchar *subtitle, GtkWidget **switch_out,
               SwitchCommands *commands, gboolean active, gboolean sensitive)
{
    GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 12);
    GtkWidget *texts = gtk_box_new(GTK_ORIENTATION_VERTICAL, 3);
    GtkWidget *sw = gtk_switch_new();
    gtk_widget_set_hexpand(texts, TRUE);
    gtk_box_pack_start(GTK_BOX(texts), label_new(title, "ml-title"), FALSE, FALSE, 0);
    if (subtitle)
        gtk_box_pack_start(GTK_BOX(texts), label_new(subtitle, "ml-subtitle"), FALSE, FALSE, 0);
    gtk_switch_set_active(GTK_SWITCH(sw), active);
    gtk_widget_set_valign(sw, GTK_ALIGN_CENTER);
    gtk_widget_set_sensitive(sw, sensitive);
    gtk_box_pack_start(GTK_BOX(row), texts, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(row), sw, FALSE, FALSE, 0);
    if (commands)
        g_signal_connect(sw, "notify::active", G_CALLBACK(on_switch_changed), commands);
    if (switch_out)
        *switch_out = sw;
    return row;
}

static GtkWidget *
control_tile(const gchar *icon, const gchar *title, const gchar *subtitle,
             const gchar *command, gboolean active)
{
    GtkWidget *button = gtk_button_new();
    GtkWidget *box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 7);
    GtkWidget *top = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    GtkWidget *image = gtk_image_new_from_icon_name(icon, GTK_ICON_SIZE_DND);
    GtkWidget *texts = gtk_box_new(GTK_ORIENTATION_VERTICAL, 2);
    GtkWidget *name = label_new(title, "ml-title");
    gtk_label_set_ellipsize(GTK_LABEL(name), PANGO_ELLIPSIZE_END);
    gtk_box_pack_start(GTK_BOX(texts), name, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(texts), label_new(subtitle, "ml-subtitle"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(top), image, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(top), texts, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(box), top, FALSE, FALSE, 0);
    gtk_container_add(GTK_CONTAINER(button), box);
    gtk_style_context_add_class(gtk_widget_get_style_context(button), active ? "ml-tile-active" : "ml-tile");
    if (command)
        g_signal_connect(button, "clicked", G_CALLBACK(on_command_clicked), (gpointer)command);
    return button;
}

static void
build_control_window(GtkApplication *app)
{
    GtkWidget *outer, *header, *date_label, *tiles, *card, *row, *settings_button;
    GtkWidget *volume_row, *dnd_button, *theme_button, *network_button;
    GtkWidget *bluetooth_button;
    gchar *date;
    gchar *wifi_state;
    gboolean wifi_active = wifi_is_enabled();
    gboolean dnd_active = dnd_is_enabled();
    gboolean dark = setting_is("THEME", "dark", "dark");

    main_window = gtk_application_window_new(app);
    gtk_widget_set_name(main_window, "ml-window");
    gtk_widget_set_app_paintable(main_window, TRUE);
    gtk_window_set_decorated(GTK_WINDOW(main_window), FALSE);
    gtk_window_set_skip_taskbar_hint(GTK_WINDOW(main_window), TRUE);
    gtk_window_set_skip_pager_hint(GTK_WINDOW(main_window), TRUE);
    gtk_window_set_keep_above(GTK_WINDOW(main_window), TRUE);
    gtk_window_set_type_hint(GTK_WINDOW(main_window), GDK_WINDOW_TYPE_HINT_UTILITY);
    gtk_window_set_default_size(GTK_WINDOW(main_window), 410, 610);
    gtk_window_set_resizable(GTK_WINDOW(main_window), FALSE);
    gtk_window_set_title(GTK_WINDOW(main_window), "Centro de Controle");

    GdkScreen *screen = gtk_widget_get_screen(main_window);
    GdkVisual *visual = gdk_screen_get_rgba_visual(screen);
    if (visual)
        gtk_widget_set_visual(main_window, visual);
    apply_css(main_window);

    outer = gtk_box_new(GTK_ORIENTATION_VERTICAL, 14);
    gtk_widget_set_name(outer, "ml-shell");
    gtk_widget_set_margin_start(outer, 18);
    gtk_widget_set_margin_end(outer, 18);
    gtk_widget_set_margin_top(outer, 17);
    gtk_widget_set_margin_bottom(outer, 16);
    gtk_container_add(GTK_CONTAINER(main_window), outer);

    header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    GtkWidget *headings = gtk_box_new(GTK_ORIENTATION_VERTICAL, 3);
    gtk_box_pack_start(GTK_BOX(headings), label_new("Centro de Controle", "ml-heading"), FALSE, FALSE, 0);
    GDateTime *now = g_date_time_new_now_local();
    date = g_date_time_format(now, "%A, %d de %B");
    g_date_time_unref(now);
    date_label = label_new(date ? date : "Mac OS Linux", "ml-subtitle");
    gtk_box_pack_start(GTK_BOX(headings), date_label, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(header), headings, TRUE, TRUE, 0);
    GtkWidget *close_button = gtk_button_new_from_icon_name("window-close-symbolic", GTK_ICON_SIZE_BUTTON);
    gtk_style_context_add_class(gtk_widget_get_style_context(close_button), "flat");
    g_signal_connect_swapped(close_button, "clicked", G_CALLBACK(gtk_widget_destroy), main_window);
    gtk_box_pack_start(GTK_BOX(header), close_button, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(outer), header, FALSE, FALSE, 0);
    g_free(date);

    tiles = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(tiles), 9);
    gtk_grid_set_column_spacing(GTK_GRID(tiles), 9);
    wifi_state = wifi_active ? "Ativado" : "Desativado";
    network_button = control_tile("network-wireless-symbolic", "Wi-Fi", wifi_state,
                                  "macoslinux-ctl wifi toggle", wifi_active);
    gtk_widget_set_sensitive(network_button, wifi_device_present());
    dnd_button = control_tile("notifications-disabled-symbolic", "Foco", dnd_active ? "Não perturbe" : "Notificações ativas",
                              "macoslinux-ctl dnd toggle", dnd_active);
    theme_button = control_tile("preferences-desktop-theme-symbolic", "Aparência", dark ? "Modo escuro" : "Modo claro",
                                NULL, dark);
    g_signal_connect(theme_button, "clicked", G_CALLBACK(on_open_settings), (gpointer)"macoslinux-settings --page appearance");
    bluetooth_button = control_tile("bluetooth-active-symbolic", "Bluetooth",
                                    bluetooth_is_enabled() ? "Ativado" : "Desativado",
                                    "macoslinux-ctl bluetooth toggle", bluetooth_is_enabled());
    gtk_widget_set_sensitive(bluetooth_button, bluetooth_device_present());
    gtk_grid_attach(GTK_GRID(tiles), network_button, 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(tiles), bluetooth_button, 1, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(tiles), dnd_button, 0, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(tiles), theme_button, 1, 1, 1, 1);
    GtkWidget *settings_tile = control_tile("preferences-system-symbolic", "Sistema", "Configurações", NULL, FALSE);
    g_signal_connect(settings_tile, "clicked", G_CALLBACK(on_open_settings), NULL);
    gtk_grid_attach(GTK_GRID(tiles), settings_tile, 0, 2, 2, 1);
    gtk_box_pack_start(GTK_BOX(outer), tiles, FALSE, FALSE, 0);

    card = make_card("Som", "Volume do sistema");
    volume_row = volume_slider(TRUE);
    gtk_box_pack_start(GTK_BOX(card), volume_row, FALSE, FALSE, 0);
    row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    GtkWidget *mute = icon_button("audio-volume-muted-symbolic", "Silenciar");
    g_signal_connect(mute, "clicked", G_CALLBACK(on_command_clicked), "macoslinux-ctl volume mute");
    gtk_box_pack_start(GTK_BOX(row), mute, TRUE, TRUE, 0);
    GtkWidget *audio_settings = icon_button("audio-card-symbolic", "Dispositivos");
    g_signal_connect(audio_settings, "clicked", G_CALLBACK(on_command_clicked), "pavucontrol");
    gtk_box_pack_start(GTK_BOX(row), audio_settings, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(card), row, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(outer), card, FALSE, FALSE, 0);

    if (brightness_available()) {
        card = make_card("Brilho", "Controle da tela");
        row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
        GtkWidget *down = gtk_button_new_from_icon_name("display-brightness-symbolic", GTK_ICON_SIZE_BUTTON);
        g_signal_connect(down, "clicked", G_CALLBACK(on_command_clicked), "macoslinux-ctl brightness down");
        GtkWidget *up = gtk_button_new_from_icon_name("weather-clear-symbolic", GTK_ICON_SIZE_BUTTON);
        g_signal_connect(up, "clicked", G_CALLBACK(on_command_clicked), "macoslinux-ctl brightness up");
        gtk_box_pack_start(GTK_BOX(row), down, FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(row), label_new("Use os botões para ajustar", "ml-subtitle"), TRUE, TRUE, 0);
        gtk_box_pack_start(GTK_BOX(row), up, FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(card), row, FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(outer), card, FALSE, FALSE, 0);
    }

    settings_button = gtk_button_new_with_label("Abrir Configurações do Sistema");
    gtk_widget_set_hexpand(settings_button, TRUE);
    g_signal_connect(settings_button, "clicked", G_CALLBACK(on_open_settings), NULL);
    gtk_box_pack_end(GTK_BOX(outer), settings_button, FALSE, FALSE, 0);

    gtk_widget_show_all(main_window);
    gint sw = gdk_screen_get_width(screen);
    gint sh = gdk_screen_get_height(screen);
    gtk_window_move(GTK_WINDOW(main_window), MAX(8, sw - 430), 35);
    if (sh < 680)
        gtk_window_resize(GTK_WINDOW(main_window), 410, sh - 50);
}

static GtkWidget *
settings_button(const gchar *title, const gchar *subtitle, const gchar *icon,
                const gchar *command)
{
    GtkWidget *button = icon_button(icon, title);
    g_signal_connect(button, "clicked", G_CALLBACK(on_command_clicked), (gpointer)command);
    (void)subtitle;
    return button;
}

static void
append_page(GtkWidget *stack, const gchar *name, GtkWidget *page)
{
    gtk_stack_add_named(GTK_STACK(stack), page, name);
}

static GtkWidget *
create_overview_page(void)
{
    GtkWidget *page = gtk_box_new(GTK_ORIENTATION_VERTICAL, 14);
    GtkWidget *hero = make_card("Bem-vindo ao Mac OS Linux", "Uma experiência de desktop leve, personalizável e construída para o seu computador.");
    GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    GtkWidget *system = make_card("Sistema", "Debian 13 • Xorg • Openbox");
    gchar *cpu = read_cpu_model();
    gchar *memory = read_memory_total();
    gchar *hardware_text = g_strdup_printf("%s\nMemória: %s", *cpu ? g_strstrip(cpu) : "Processador não identificado", *memory ? memory : "indisponível");
    GtkWidget *hardware = make_card("Hardware detectado", hardware_text);
    gtk_box_pack_start(GTK_BOX(hero), label_new("Mac OS Linux 1.0.0", "ml-heading"), FALSE, FALSE, 4);
    gtk_box_pack_start(GTK_BOX(hero), label_new("Personalize a aparência, a conectividade, o áudio, a tela e o Dock.", "ml-subtitle"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), system, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(row), hardware, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(page), hero, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), row, FALSE, FALSE, 0);
    GtkWidget *quick = make_card("Acesso rápido", "Ferramentas do sistema");
    GtkWidget *buttons = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    gtk_box_pack_start(GTK_BOX(buttons), settings_button("Rede", NULL, "network-workgroup-symbolic", "nm-connection-editor"), TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(buttons), settings_button("Som", NULL, "audio-card-symbolic", "pavucontrol"), TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(quick), buttons, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), quick, FALSE, FALSE, 0);
    g_free(cpu);
    g_free(memory);
    g_free(hardware_text);
    return page;
}

static GtkWidget *
create_appearance_page(void)
{
    GtkWidget *page = gtk_box_new(GTK_ORIENTATION_VERTICAL, 13);
    GtkWidget *card, *row, *sw;
    GtkWidget *theme_card;
    card = make_card("Modo de aparência", "Escolha a aparência principal do sistema.");
    row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    GtkWidget *dark = gtk_button_new_with_label("Escuro");
    GtkWidget *light = gtk_button_new_with_label("Claro");
    g_signal_connect(dark, "clicked", G_CALLBACK(on_command_clicked), "macoslinux-ctl theme dark");
    g_signal_connect(light, "clicked", G_CALLBACK(on_command_clicked), "macoslinux-ctl theme light");
    gtk_box_pack_start(GTK_BOX(row), dark, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(row), light, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(card), row, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), card, FALSE, FALSE, 0);

    theme_card = make_card("Material e transparência", "O efeito de vidro usa transparência e composição do Picom. O desfoque é opcional e pode pesar no Intel G41.");
    row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    GtkWidget *glass = gtk_button_new_with_label("Vidro");
    GtkWidget *reduced = gtk_button_new_with_label("Reduzida");
    GtkWidget *solid = gtk_button_new_with_label("Sólida");
    g_signal_connect(glass, "clicked", G_CALLBACK(on_command_clicked), "macoslinux-ctl transparency glass");
    g_signal_connect(reduced, "clicked", G_CALLBACK(on_command_clicked), "macoslinux-ctl transparency reduced");
    g_signal_connect(solid, "clicked", G_CALLBACK(on_command_clicked), "macoslinux-ctl transparency solid");
    gtk_box_pack_start(GTK_BOX(row), glass, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(row), reduced, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(row), solid, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(theme_card), row, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), theme_card, FALSE, FALSE, 0);

    card = make_card("Acessibilidade e efeitos", "Reduza animações ou ative o desfoque experimental.");
    GtkWidget *motion_row = make_switch_row("Reduzir movimento", "Diminui animações e zoom do Dock.", &sw,
        &motion_commands, setting_is("MOTION", "reduced", "full"), TRUE);
    gtk_box_pack_start(GTK_BOX(card), motion_row, FALSE, FALSE, 0);
    GtkWidget *blur_row = make_switch_row("Desfoque de fundo", "Experimental; pode reduzir o desempenho em computadores antigos.", &sw,
        &blur_commands, setting_is("BLUR", "1", "0"), TRUE);
    gtk_box_pack_start(GTK_BOX(card), blur_row, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), card, FALSE, FALSE, 0);
    return page;
}

static GtkWidget *
create_dock_page(void)
{
    GtkWidget *page = gtk_box_new(GTK_ORIENTATION_VERTICAL, 13);
    GtkWidget *card = make_card("Comportamento do Dock", "Personalize a barra de aplicativos na parte inferior da tela.");
    GtkWidget *sw;
    GtkWidget *row = make_switch_row("Ocultar automaticamente", "Mostra o Dock quando o ponteiro chega à borda inferior.", &sw,
        &autohide_commands, setting_is("DOCK_AUTOHIDE", "1", "0"), TRUE);
    gtk_box_pack_start(GTK_BOX(card), row, FALSE, FALSE, 0);
    row = make_switch_row("Ampliação dos ícones", "Aumenta o ícone quando o ponteiro passa sobre ele.", &sw,
        &zoom_commands, setting_is("DOCK_ZOOM", "1", "1"), TRUE);
    gtk_box_pack_start(GTK_BOX(card), row, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), card, FALSE, FALSE, 0);

    card = make_card("Tamanho dos ícones", "Escolha um dos três tamanhos disponíveis.");
    row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    const gchar *sizes[] = { "36", "46", "56" };
    for (guint i = 0; i < G_N_ELEMENTS(sizes); i++) {
        gchar *cmd = g_strdup_printf("macoslinux-ctl dock size %s", sizes[i]);
        GtkWidget *button = gtk_button_new_with_label(sizes[i]);
        g_signal_connect(button, "clicked", G_CALLBACK(on_command_clicked), cmd);
        g_object_set_data_full(G_OBJECT(button), "ml-command", cmd, g_free);
        gtk_box_pack_start(GTK_BOX(row), button, TRUE, TRUE, 0);
    }
    gtk_box_pack_start(GTK_BOX(card), row, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), card, FALSE, FALSE, 0);
    return page;
}

static GtkWidget *
create_network_page(void)
{
    GtkWidget *page = gtk_box_new(GTK_ORIENTATION_VERTICAL, 13);
    GtkWidget *card = make_card("Wi-Fi", "Ative ou desative o rádio sem fio. Para conectar, abra o gerenciador de conexões.");
    GtkWidget *sw = NULL;
    gboolean present = wifi_device_present();
    gchar *status = command_output("nmcli -t -f TYPE,STATE device");
    GtkWidget *status_label = label_new(*status ? status : "NetworkManager indisponível ou sem dispositivos.", "ml-subtitle");
    GtkWidget *row = make_switch_row("Wi-Fi ligado", present ? "Estado do adaptador Wi-Fi." : "Nenhum adaptador Wi-Fi detectado.", &sw,
        &wifi_commands, wifi_is_enabled(), present);
    gtk_box_pack_start(GTK_BOX(card), row, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(card), status_label, FALSE, FALSE, 0);
    GtkWidget *button = settings_button("Abrir conexões de rede", NULL, "network-workgroup-symbolic", "nm-connection-editor");
    gtk_box_pack_start(GTK_BOX(card), button, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), card, FALSE, FALSE, 0);

    card = make_card("Bluetooth", "Gerencie o rádio Bluetooth quando houver um adaptador compatível.");
    GtkWidget *bt_row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    GtkWidget *bt_text = gtk_box_new(GTK_ORIENTATION_VERTICAL, 3);
    gtk_box_pack_start(GTK_BOX(bt_text), label_new("Bluetooth", "ml-title"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(bt_text), label_new(bluetooth_device_present() ? "Estado do rádio Bluetooth." : "Nenhum adaptador Bluetooth detectado.", "ml-subtitle"), FALSE, FALSE, 0);
    GtkWidget *bt_switch = gtk_switch_new();
    gtk_switch_set_active(GTK_SWITCH(bt_switch), bluetooth_is_enabled());
    gtk_widget_set_sensitive(bt_switch, bluetooth_device_present());
    g_signal_connect(bt_switch, "notify::active", G_CALLBACK(on_switch_changed), &bluetooth_commands);
    gtk_box_pack_start(GTK_BOX(bt_row), bt_text, TRUE, TRUE, 0);
    gtk_box_pack_end(GTK_BOX(bt_row), bt_switch, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(card), bt_row, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), card, FALSE, FALSE, 0);
    g_free(status);
    return page;
}

static GtkWidget *
create_sound_page(void)
{
    GtkWidget *page = gtk_box_new(GTK_ORIENTATION_VERTICAL, 13);
    GtkWidget *card = make_card("Volume de saída", "Ajuste o volume principal do sistema.");
    volume_value_label = NULL;
    GtkWidget *slider = volume_slider(FALSE);
    gtk_box_pack_start(GTK_BOX(card), slider, FALSE, FALSE, 0);
    GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    GtkWidget *mute = settings_button("Silenciar / ativar", NULL, "audio-volume-muted-symbolic", "macoslinux-ctl volume mute");
    GtkWidget *devices = settings_button("Dispositivos de áudio", NULL, "audio-card-symbolic", "pavucontrol");
    gtk_box_pack_start(GTK_BOX(row), mute, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(row), devices, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(card), row, FALSE, FALSE, 0);
    if (!audio_available())
        gtk_box_pack_start(GTK_BOX(card), label_new("Nenhum servidor de áudio foi encontrado. Os controles ficarão disponíveis quando o PipeWire iniciar.", "ml-subtitle"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), card, FALSE, FALSE, 0);
    return page;
}

static GtkWidget *
create_display_page(void)
{
    GtkWidget *page = gtk_box_new(GTK_ORIENTATION_VERTICAL, 13);
    GtkWidget *card = make_card("Tela e resolução", "Consulte os modos detectados pelo Xorg.");
    GtkWidget *button = settings_button("Abrir ajustes de monitores", NULL, "video-display-symbolic",
                                        command_available("arandr") ? "arandr" :
                                        "macoslinux-terminal -e sh -c 'xrandr --query; printf \"\\nPressione Enter para fechar. \"; read resposta'");
    gtk_box_pack_start(GTK_BOX(card), button, FALSE, FALSE, 0);
    if (brightness_available()) {
        gtk_box_pack_start(GTK_BOX(card), label_new("O dispositivo de backlight foi detectado. Use os atalhos de brilho do teclado para ajustar.", "ml-subtitle"), FALSE, FALSE, 0);
        GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
        GtkWidget *down = gtk_button_new_with_label("Diminuir brilho");
        GtkWidget *up = gtk_button_new_with_label("Aumentar brilho");
        g_signal_connect(down, "clicked", G_CALLBACK(on_command_clicked), "macoslinux-ctl brightness down");
        g_signal_connect(up, "clicked", G_CALLBACK(on_command_clicked), "macoslinux-ctl brightness up");
        gtk_box_pack_start(GTK_BOX(row), down, TRUE, TRUE, 0);
        gtk_box_pack_start(GTK_BOX(row), up, TRUE, TRUE, 0);
        gtk_box_pack_start(GTK_BOX(card), row, FALSE, FALSE, 0);
    } else {
        gtk_box_pack_start(GTK_BOX(card), label_new("Controle de brilho não disponível: este desktop não expõe um dispositivo de backlight.", "ml-subtitle"), FALSE, FALSE, 0);
    }
    gtk_box_pack_start(GTK_BOX(page), card, FALSE, FALSE, 0);
    return page;
}

static GtkWidget *
create_notifications_page(void)
{
    GtkWidget *page = gtk_box_new(GTK_ORIENTATION_VERTICAL, 13);
    GtkWidget *card = make_card("Foco e notificações", "Pause temporariamente os avisos do sistema.");
    GtkWidget *sw = NULL;
    GtkWidget *row = make_switch_row("Não Perturbe", "Silencia as notificações até ser desativado.", &sw,
        &dnd_commands, dnd_is_enabled(), command_available("dunstctl"));
    gtk_box_pack_start(GTK_BOX(card), row, FALSE, FALSE, 0);
    GtkWidget *history = settings_button("Abrir histórico de notificações", NULL, "preferences-system-notifications-symbolic", "dunstctl history");
    gtk_box_pack_start(GTK_BOX(card), history, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), card, FALSE, FALSE, 0);
    return page;
}

static GtkWidget *
create_about_page(void)
{
    GtkWidget *page = gtk_box_new(GTK_ORIENTATION_VERTICAL, 13);
    GtkWidget *card = make_card("Mac OS Linux", "Sistema independente baseado em Debian GNU/Linux.");
    gchar *kernel = command_output("uname -r");
    gchar *cpu = read_cpu_model();
    gchar *memory = read_memory_total();
    gchar *details = g_strdup_printf("Versão 1.0.0\nBase: Debian 13 (Trixie)\nKernel: %s\nProcessador:%s\nMemória: %s\nSessão: Xorg + Openbox",
                                     *kernel ? kernel : "não identificado",
                                     *cpu ? cpu : " não identificado",
                                     *memory ? memory : "não identificada");
    GtkWidget *text = label_new(details, "ml-subtitle");
    gtk_label_set_selectable(GTK_LABEL(text), TRUE);
    gtk_box_pack_start(GTK_BOX(card), text, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(page), card, FALSE, FALSE, 0);
    g_free(kernel);
    g_free(cpu);
    g_free(memory);
    g_free(details);
    return page;
}

static void
on_nav_clicked(GtkButton *button, gpointer data)
{
    const gchar *page = (const gchar *)data;
    const gchar *title = "Geral";
    const gchar *subtitle = "Visão geral e atalhos do sistema.";
    GtkWidget *parent = gtk_widget_get_parent(GTK_WIDGET(button));
    GList *children = parent ? gtk_container_get_children(GTK_CONTAINER(parent)) : NULL;
    if (g_strcmp0(page, "appearance") == 0) { title = "Aparência"; subtitle = "Cores, materiais, transparência e movimento."; }
    else if (g_strcmp0(page, "dock") == 0) { title = "Dock"; subtitle = "Personalize o comportamento e o tamanho dos ícones."; }
    else if (g_strcmp0(page, "network") == 0) { title = "Rede"; subtitle = "Wi-Fi, Bluetooth e conexões de rede."; }
    else if (g_strcmp0(page, "sound") == 0) { title = "Som"; subtitle = "Volume, dispositivos e saída de áudio."; }
    else if (g_strcmp0(page, "display") == 0) { title = "Tela"; subtitle = "Resolução, monitores e brilho."; }
    else if (g_strcmp0(page, "notifications") == 0) { title = "Notificações"; subtitle = "Foco e avisos do sistema."; }
    else if (g_strcmp0(page, "about") == 0) { title = "Sobre"; subtitle = "Versão e informações deste computador."; }
    if (settings_stack)
        gtk_stack_set_visible_child_name(GTK_STACK(settings_stack), page);
    if (settings_heading)
        gtk_label_set_text(GTK_LABEL(settings_heading), title);
    if (settings_subheading)
        gtk_label_set_text(GTK_LABEL(settings_subheading), subtitle);
    for (GList *item = children; item; item = item->next) {
        GtkWidget *nav = GTK_WIDGET(item->data);
        GtkStyleContext *context = gtk_widget_get_style_context(nav);
        if (nav == GTK_WIDGET(button))
            gtk_style_context_add_class(context, "ml-nav-active");
        else
            gtk_style_context_remove_class(context, "ml-nav-active");
    }
    g_list_free(children);
}

static GtkWidget *
nav_button(const gchar *icon, const gchar *label, const gchar *page)
{
    GtkWidget *button = gtk_button_new();
    GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    GtkWidget *image = gtk_image_new_from_icon_name(icon, GTK_ICON_SIZE_BUTTON);
    GtkWidget *text = gtk_label_new(label);
    gtk_widget_set_halign(text, GTK_ALIGN_START);
    gtk_box_pack_start(GTK_BOX(row), image, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), text, TRUE, TRUE, 0);
    gtk_container_add(GTK_CONTAINER(button), row);
    gtk_widget_set_halign(button, GTK_ALIGN_FILL);
    gtk_style_context_add_class(gtk_widget_get_style_context(button), "ml-nav");
    g_object_set_data(G_OBJECT(button), "ml-page", (gpointer)page);
    if ((!active_page && g_strcmp0(page, "overview") == 0) ||
        (active_page && g_strcmp0(page, active_page) == 0))
        gtk_style_context_add_class(gtk_widget_get_style_context(button), "ml-nav-active");
    g_signal_connect(button, "clicked", G_CALLBACK(on_nav_clicked), (gpointer)page);
    return button;
}

static void
build_settings_window(GtkApplication *app)
{
    GtkWidget *outer, *header, *body, *sidebar, *content, *scroll, *heading;
    GtkWidget *nav_title, *nav_box;
    const gchar *pages[][3] = {
        { "go-home-symbolic", "Geral", "overview" },
        { "preferences-desktop-theme-symbolic", "Aparência", "appearance" },
        { "dock-symbolic", "Dock", "dock" },
        { "network-wireless-symbolic", "Rede", "network" },
        { "audio-volume-high-symbolic", "Som", "sound" },
        { "video-display-symbolic", "Tela", "display" },
        { "preferences-system-notifications-symbolic", "Notificações", "notifications" },
        { "help-about-symbolic", "Sobre", "about" }
    };

    main_window = gtk_application_window_new(app);
    gtk_widget_set_name(main_window, "ml-window");
    gtk_widget_set_app_paintable(main_window, TRUE);
    gtk_window_set_title(GTK_WINDOW(main_window), "Configurações do Sistema");
    gtk_window_set_default_size(GTK_WINDOW(main_window), 1020, 700);
    gtk_window_set_position(GTK_WINDOW(main_window), GTK_WIN_POS_CENTER);
    GdkScreen *screen = gtk_widget_get_screen(main_window);
    GdkVisual *visual = gdk_screen_get_rgba_visual(screen);
    if (visual)
        gtk_widget_set_visual(main_window, visual);
    apply_css(main_window);

    header = gtk_header_bar_new();
    gtk_header_bar_set_title(GTK_HEADER_BAR(header), "Configurações");
    gtk_header_bar_set_subtitle(GTK_HEADER_BAR(header), "Mac OS Linux 1.0.0");
    gtk_header_bar_set_show_close_button(GTK_HEADER_BAR(header), TRUE);
    gtk_window_set_titlebar(GTK_WINDOW(main_window), header);

    outer = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_widget_set_name(outer, "ml-shell");
    gtk_container_add(GTK_CONTAINER(main_window), outer);

    body = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(outer), body, TRUE, TRUE, 0);
    sidebar = gtk_box_new(GTK_ORIENTATION_VERTICAL, 9);
    gtk_widget_set_size_request(sidebar, 220, -1);
    gtk_widget_set_margin_start(sidebar, 15);
    gtk_widget_set_margin_end(sidebar, 12);
    gtk_widget_set_margin_top(sidebar, 17);
    gtk_widget_set_margin_bottom(sidebar, 16);
    nav_title = label_new("Preferências", "ml-title");
    gtk_box_pack_start(GTK_BOX(sidebar), nav_title, FALSE, FALSE, 8);
    nav_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 4);
    for (guint i = 0; i < G_N_ELEMENTS(pages); i++)
        gtk_box_pack_start(GTK_BOX(nav_box), nav_button(pages[i][0], pages[i][1], pages[i][2]), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(sidebar), nav_box, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(body), sidebar, FALSE, FALSE, 0);

    GtkWidget *separator = gtk_separator_new(GTK_ORIENTATION_VERTICAL);
    gtk_box_pack_start(GTK_BOX(body), separator, FALSE, FALSE, 0);
    content = gtk_box_new(GTK_ORIENTATION_VERTICAL, 12);
    gtk_widget_set_margin_start(content, 24);
    gtk_widget_set_margin_end(content, 24);
    gtk_widget_set_margin_top(content, 23);
    gtk_widget_set_margin_bottom(content, 18);
    gtk_box_pack_start(GTK_BOX(body), content, TRUE, TRUE, 0);
    heading = label_new("Geral", "ml-heading");
    settings_heading = heading;
    settings_subheading = label_new("Visão geral e atalhos do sistema.", "ml-subtitle");
    gtk_box_pack_start(GTK_BOX(content), heading, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(content), settings_subheading, FALSE, FALSE, 0);
    scroll = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
    gtk_box_pack_start(GTK_BOX(content), scroll, TRUE, TRUE, 0);
    settings_stack = gtk_stack_new();
    gtk_stack_set_transition_type(GTK_STACK(settings_stack), GTK_STACK_TRANSITION_TYPE_CROSSFADE);
    gtk_stack_set_transition_duration(GTK_STACK(settings_stack), 130);
    gtk_container_add(GTK_CONTAINER(scroll), settings_stack);

    append_page(settings_stack, "overview", create_overview_page());
    append_page(settings_stack, "appearance", create_appearance_page());
    append_page(settings_stack, "dock", create_dock_page());
    append_page(settings_stack, "network", create_network_page());
    append_page(settings_stack, "sound", create_sound_page());
    append_page(settings_stack, "display", create_display_page());
    append_page(settings_stack, "notifications", create_notifications_page());
    append_page(settings_stack, "about", create_about_page());
    gtk_stack_set_visible_child_name(GTK_STACK(settings_stack), active_page ? active_page : "overview");
    GList *nav_children = gtk_container_get_children(GTK_CONTAINER(nav_box));
    for (GList *item = nav_children; item; item = item->next) {
        GtkWidget *nav = GTK_WIDGET(item->data);
        const gchar *page = g_object_get_data(G_OBJECT(nav), "ml-page");
        if (g_strcmp0(page, active_page ? active_page : "overview") == 0)
            on_nav_clicked(GTK_BUTTON(nav), (gpointer)page);
    }
    g_list_free(nav_children);
    gtk_widget_show_all(main_window);
}

static gboolean
launcher_filter(GtkFlowBoxChild *child, gpointer user_data)
{
    GtkWidget *button = gtk_bin_get_child(GTK_BIN(child));
    GtkWidget *search = GTK_WIDGET(user_data);
    const gchar *needle = gtk_entry_get_text(GTK_ENTRY(search));
    const gchar *haystack = g_object_get_data(G_OBJECT(button), "ml-search");
    gchar *query = g_utf8_strdown(needle ? needle : "", -1);
    gboolean visible = !*query || (haystack && strstr(haystack, query) != NULL);
    g_free(query);
    return visible;
}

static void
on_launcher_search_changed(GtkSearchEntry *entry, gpointer user_data)
{
    (void)entry;
    gtk_flow_box_invalidate_filter(GTK_FLOW_BOX(user_data));
}

static void
on_launcher_app_clicked(GtkButton *button, gpointer user_data)
{
    GAppInfo *app = G_APP_INFO(g_object_get_data(G_OBJECT(button), "ml-app"));
    GError *error = NULL;
    (void)user_data;
    if (!app)
        return;
    if (g_app_info_launch(app, NULL, NULL, &error)) {
        if (main_window)
            gtk_widget_destroy(main_window);
    } else {
        GtkWidget *dialog = gtk_message_dialog_new(
            main_window ? GTK_WINDOW(main_window) : NULL,
            GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR, GTK_BUTTONS_CLOSE,
            "Não foi possível abrir este aplicativo.");
        gtk_message_dialog_format_secondary_text(GTK_MESSAGE_DIALOG(dialog), "%s",
                                                  error ? error->message : "Erro desconhecido.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        g_clear_error(&error);
    }
}

static gint
compare_app_names(gconstpointer a, gconstpointer b)
{
    const GAppInfo *app_a = G_APP_INFO(a);
    const GAppInfo *app_b = G_APP_INFO(b);
    const gchar *name_a = g_app_info_get_display_name((GAppInfo *)app_a);
    const gchar *name_b = g_app_info_get_display_name((GAppInfo *)app_b);
    return g_utf8_collate(name_a ? name_a : "", name_b ? name_b : "");
}

static void
build_launcher_window(GtkApplication *app)
{
    GtkWidget *outer, *header, *titles, *search, *scroll, *flow;
    GList *apps, *item;
    GHashTable *seen;

    main_window = gtk_application_window_new(app);
    gtk_widget_set_name(main_window, "ml-window");
    gtk_widget_set_app_paintable(main_window, TRUE);
    gtk_window_set_title(GTK_WINDOW(main_window), "Aplicativos");
    gtk_window_set_default_size(GTK_WINDOW(main_window), 820, 610);
    gtk_window_set_position(GTK_WINDOW(main_window), GTK_WIN_POS_CENTER);
    GdkScreen *screen = gtk_widget_get_screen(main_window);
    GdkVisual *visual = gdk_screen_get_rgba_visual(screen);
    if (visual)
        gtk_widget_set_visual(main_window, visual);
    apply_css(main_window);

    outer = gtk_box_new(GTK_ORIENTATION_VERTICAL, 14);
    gtk_widget_set_name(outer, "ml-shell");
    gtk_widget_set_margin_start(outer, 18);
    gtk_widget_set_margin_end(outer, 18);
    gtk_widget_set_margin_top(outer, 16);
    gtk_widget_set_margin_bottom(outer, 17);
    gtk_container_add(GTK_CONTAINER(main_window), outer);

    header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 12);
    titles = gtk_box_new(GTK_ORIENTATION_VERTICAL, 3);
    gtk_box_pack_start(GTK_BOX(titles), label_new("Aplicativos", "ml-heading"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(titles), label_new("Encontre e abra os aplicativos instalados", "ml-subtitle"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(header), titles, TRUE, TRUE, 0);
    search = gtk_search_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(search), "Buscar aplicativos");
    gtk_widget_set_size_request(search, 245, -1);
    gtk_box_pack_end(GTK_BOX(header), search, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(outer), header, FALSE, FALSE, 0);

    scroll = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
    flow = gtk_flow_box_new();
    gtk_flow_box_set_selection_mode(GTK_FLOW_BOX(flow), GTK_SELECTION_NONE);
    gtk_flow_box_set_homogeneous(GTK_FLOW_BOX(flow), TRUE);
    gtk_flow_box_set_min_children_per_line(GTK_FLOW_BOX(flow), 4);
    gtk_flow_box_set_max_children_per_line(GTK_FLOW_BOX(flow), 5);
    gtk_flow_box_set_row_spacing(GTK_FLOW_BOX(flow), 10);
    gtk_flow_box_set_column_spacing(GTK_FLOW_BOX(flow), 10);
    gtk_flow_box_set_filter_func(GTK_FLOW_BOX(flow), launcher_filter, search, NULL);
    gtk_container_add(GTK_CONTAINER(scroll), flow);
    gtk_box_pack_start(GTK_BOX(outer), scroll, TRUE, TRUE, 0);

    seen = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, NULL);
    apps = g_app_info_get_all();
    apps = g_list_sort(apps, compare_app_names);
    for (item = apps; item; item = item->next) {
        GAppInfo *info = G_APP_INFO(item->data);
        const gchar *id = g_app_info_get_id(info);
        const gchar *name = g_app_info_get_display_name(info);
        GIcon *app_icon;
        GtkWidget *button, *box, *image, *text;
        gchar *search_text;
        if (!g_app_info_should_show(info) || !name || !*name)
            continue;
        if (id && g_hash_table_contains(seen, id))
            continue;
        if (id)
            g_hash_table_add(seen, g_strdup(id));

        button = gtk_button_new();
        gtk_style_context_add_class(gtk_widget_get_style_context(button), "ml-app-tile");
        box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 7);
        app_icon = g_app_info_get_icon(info);
        image = app_icon ? gtk_image_new_from_gicon(app_icon, GTK_ICON_SIZE_DIALOG)
                         : gtk_image_new_from_icon_name("application-x-executable", GTK_ICON_SIZE_DIALOG);
        gtk_image_set_pixel_size(GTK_IMAGE(image), 42);
        gtk_box_pack_start(GTK_BOX(box), image, FALSE, FALSE, 2);
        text = gtk_label_new(name);
        gtk_label_set_line_wrap(GTK_LABEL(text), TRUE);
        gtk_label_set_max_width_chars(GTK_LABEL(text), 18);
        gtk_label_set_ellipsize(GTK_LABEL(text), PANGO_ELLIPSIZE_END);
        gtk_box_pack_start(GTK_BOX(box), text, FALSE, FALSE, 0);
        gtk_container_add(GTK_CONTAINER(button), box);
        search_text = g_utf8_strdown(name, -1);
        g_object_set_data_full(G_OBJECT(button), "ml-search", search_text, g_free);
        g_object_set_data_full(G_OBJECT(button), "ml-app", g_object_ref(info), g_object_unref);
        gtk_widget_set_tooltip_text(button, name);
        g_signal_connect(button, "clicked", G_CALLBACK(on_launcher_app_clicked), NULL);
        gtk_flow_box_insert(GTK_FLOW_BOX(flow), button, -1);
    }
    g_list_free_full(apps, g_object_unref);
    g_hash_table_destroy(seen);
    g_signal_connect(search, "search-changed", G_CALLBACK(on_launcher_search_changed), flow);
    gtk_widget_show_all(main_window);
    gtk_widget_grab_focus(search);
}

static void
activate(GtkApplication *app, gpointer user_data)
{
    (void)user_data;
    if (control_mode)
        build_control_window(app);
    else if (launcher_mode)
        build_launcher_window(app);
    else
        build_settings_window(app);
}

int
main(int argc, char **argv)
{
    GtkApplication *app;
    GApplicationFlags flags = G_APPLICATION_NON_UNIQUE;
    int status;

    control_mode = FALSE;
    launcher_mode = FALSE;
    active_page = NULL;
    for (int i = 1; i < argc; i++) {
        if (g_strcmp0(argv[i], "--control") == 0) {
            control_mode = TRUE;
            launcher_mode = FALSE;
        } else if (g_strcmp0(argv[i], "--settings") == 0) {
            control_mode = FALSE;
            launcher_mode = FALSE;
        } else if (g_strcmp0(argv[i], "--launcher") == 0) {
            control_mode = FALSE;
            launcher_mode = TRUE;
        } else if (g_strcmp0(argv[i], "--page") == 0 && i + 1 < argc) {
            active_page = g_strdup(argv[++i]);
        }
    }

    app = gtk_application_new(APP_ID, flags);
    g_signal_connect(app, "activate", G_CALLBACK(activate), NULL);
    status = g_application_run(G_APPLICATION(app), 1, argv);
    g_object_unref(app);
    g_free(active_page);
    return status;
}
