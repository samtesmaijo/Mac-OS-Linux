# Relatório de testes — Interface do Mac OS Linux (UI R1)

Regra do projeto: *"Não declare uma funcionalidade concluída sem testá-la."* Este relatório
separa **o que foi testado e como**, **o que foi medido**, **os defeitos que os próprios testes
encontraram** e **o que NÃO foi testado**. Capturas de tela em `docs/screenshots/`.

## 0. Resumo honesto

* A interface foi testada **em um X virtual (Xvfb)** com um usuário comum criado a partir de
  `/etc/skel`, rodando a sessão real (`openbox-session` → `autostart` → `macoslinux-session-start`).
* **O ISO NÃO foi construído e o boot NÃO foi testado** — o pacote recebido não traz
  bootloader, `chroot` nem ISO.
* **Nada foi testado em hardware real** (Core 2 Duo E7500 / Intel G41 / i915).
* O alvo é **Debian 13 Trixie**; o sandbox é **Ubuntu 24.04**. Versões diferentes (tabela abaixo),
  em especial o **Picom 10.2 testado × 12.5 do Trixie**.
* Resultado da bateria automatizada: **78 de 78** testes passam (3 execuções consecutivas
  sem intermitência na versão anterior de 73 testes; a de 78 foi executada após as últimas
  alterações).

## 1. Ambiente de teste

| | Sandbox (testado) | Alvo (Trixie) |
|---|---|---|
| SO | Ubuntu 24.04.5 | Debian 13 |
| CPU | Xeon 2,1 GHz, 1 vCPU, render em software | Core 2 Duo E7500, G41/i915 |
| Tela | Xvfb 1366×768×24 (barra também em 1024×768) | — |
| Openbox | 3.6.1-12 | (o do Trixie) |
| Tint2 | 17.0.1-1.1 | 17.0.1 |
| **Picom** | **10.2-3** | **12.5** |
| Plank | 0.11.89-4ubuntu5 | 0.11.89 |
| dunst | 1.9.2 | (o do Trixie) |
| PipeWire / WirePlumber | WirePlumber 0.4.17 | (o do Trixie) |
| feh / xdotool / scrot | 3.10.1 / 3.20160805.1 / 1.10 | scrot 1.12.1, xdotool 3.20160805.1 |
| LightDM greeter | lightdm-gtk-greeter 2.0.9 (com `01_ubuntu.conf`) | (o do Trixie) |

## 2. Bateria automatizada — `sh scripts/test-interface.sh`

Reproduzível no computador do desenvolvedor. Não altera o sistema (HOME temporário + X virtual).

| Grupo | O que verifica | Resultado |
|---|---|---|
| Scripts | `sh -n` (ou `bash -n` quando o shebang é bash) e `shellcheck` em todos os scripts | ok |
| Permissões | bit de execução em `usr/bin/macoslinux-*` | ok |
| XML | `rc.xml` e `menu.xml` bem-formados; **todo menu definido antes de ser referenciado** | ok |
| Desktop | `desktop-file-validate` nos `.desktop`; cada `.dockitem` aponta para arquivo existente | ok |
| Modelos | tint2/Plank/dunst renderizam **sem `@TOKEN@` residual** em 2 temas × 3 transparências (18 renderizações) | ok |
| Temas | `themerc` + máscaras `.xbm` presentes nos dois temas Openbox | ok |
| Entradas inválidas | `theme azul`, `transparency x`, `motion x`, `blur x`, `volume set abc`, `dock size 99` → código 2 | ok |
| Com X | Picom inicia com cada um dos **4** perfis; Openbox carrega `rc.xml`+`menu.xml` sem erro; tint2 inicia e cria os 8 executores nos 2 temas | ok |

**78 ok · 0 falhas · 0 puladas.**

> Os XSDs que acompanham o Openbox (`rc.xsd`, `menu.xsd`) **não puderam ser usados**: o de
> menu não declara o elemento raiz e o de `rc` tem uma expressão regular que o libxml2 recusa.
> A validação real foi carregar os arquivos no próprio Openbox e checar o log.

## 3. Testes funcionais (executados manualmente no X virtual)

| # | Funcionalidade | Como foi verificado | Resultado |
|---|---|---|---|
| 1 | Primeiro boot de usuário novo | usuário recriado do `skel`; `ui.log`; processos | os 5 componentes sobem; ~3 s do início da sessão até "interface iniciada" |
| 2 | Barra superior completa | captura 1366×768 e 1024×768 | todos os itens visíveis e sem cortes nas duas resoluções |
| 3 | Reserva de espaço da barra | `_NET_WORKAREA` | começa em y=28 |
| 4 | Nome do app ativo | abrir Arquivos/Terminal/xmessage | "Arquivos", "Terminal", "Mensagem", "Área de Trabalho" |
| 5 | Tema de janelas | captura com 2 janelas | semáforo, título centralizado, ativo/inativo distintos, cantos arredondados, sombra |
| 6 | Dock: ícones próprios e indicadores | captura | 6 itens, pontinho sob apps abertos, sem duplicatas |
| 7 | Dock: ampliação e tooltip | cursor sobre "Arquivos" | ícone amplia, vizinhos se afastam, tooltip aparece |
| 8 | Dock: ocultação automática | `_NET_WORKAREA` | altura útil 678 → 740 → 678 |
| 9 | Dock: tamanho 36/46/56 | `_NET_WORKAREA` | 690 / 678 / 664 |
| 10 | Modo claro | captura + `rc.xml`, `ui.conf`, `settings.ini` | wallpaper, barra, Dock, janelas, notificações e GTK trocaram |
| 11 | Transparência (3 níveis) | alfa em `tint2.rc` e `dock.theme` | 72/88/100 % e 183/224/255 |
| 12 | Reduzir movimento | `cmdline` do picom, zoom, `FadeTime` | perfil `lite`; zoom off; 250 ms → 1 ms; reverte ao voltar |
| 13 | Desfoque opcional | contraste de listras atrás da barra | desligado por padrão; ao ligar 35,5 → 7,5; "reduzir movimento" tem prioridade |
| 14 | Fade de abertura | 9 quadros sucessivos (fade lento só para o teste) | opacidade intermediária em todos: 81→106→131→158→181→220 |
| 15 | Volume (PipeWire real, sinks virtuais) | `volume set/up/down/mute/get` | set 40→45→40→mudo→desmuta; **teto em 100**; 0 %; entrada inválida rc=2 |
| 16 | Status de volume na barra | saída de `status volume` | ícone e texto trocam (mudo / 45 % / 0 %) |
| 17 | Saída de áudio | `output teste_b` ↔ `teste_a`, sink inexistente | troca de fato; inexistente → rc=1 + notificação |
| 18 | OSD de volume | captura | cartão com barra de progresso azul |
| 19 | Não perturbe | `dunstctl is-paused` | alterna `true`/`false` |
| 20 | Calendário | captura | grade do mês, hoje em negrito/sublinhado, data correta |
| 21 | Centro de Controle | captura + XML válido | abre alinhado à direita sob o botão; estado marcado (✓); itens sem suporte omitidos |
| 22 | Menus Arquivo / Janela / sistema / Aplicativos | captura | abrem sob a barra; **Janela › Minimizar** age na janela ativa |
| 23 | Menu do botão direito | captura | Terminal, Arquivos, Aplicativos, Centro de Controle, Janelas, Recarregar, Sessão |
| 24 | Atalhos de janela | `xdotool` + geometria | `Super+←/→` metade da tela; `Super+↑` maximiza/restaura; `Alt+F4` fecha; **nada cobre o Dock** (bordas em y=705/706) |
| 25 | Terminal da interface | `macoslinux-terminal -e …` rodando `doctor` | abre o LXTerminal e executa o diagnóstico |
| 26 | Log limpo e falha legível | `ui.log` após 12 s; `DISPLAY` inválido | 1 linha limpa; falha registrada com o motivo |
| 27 | Tela de login | LightDM em modo de teste + Xephyr | greeter lê **nosso** `lightdm-gtk-greeter.conf`: wallpaper, logotipo, tema escuro |
| 28 | `.desktop` / ícones | `desktop-file-validate`, captura | válidos; ícones próprios legíveis de 256 a 22 px |

## 4. Medições (indicativas — render em software, não é a G41)

| Medida | Valor |
|---|---|
| Memória da interface (PSS) | **~48 MiB** (openbox 9,9 · tint2 8,2 · picom 2,7 · plank 14,0 · dunst 2,7 · bamfdaemon 10,4) |
| Memória (RSS, sem descontar compartilhado) | ~109 MiB |
| CPU em repouso | 0,0 % |
| Processos do usuário | 16 |
| Início da sessão → "interface iniciada" | ~3 s |
| **Desfoque**: CPU do servidor X ao repintar sob a barra/Dock | **~11 % → ~95 % de 1 CPU** (e a sequência de teste ficou 2,4× mais lenta) |
| Tamanho dos assets novos | ~0,87 MiB (ícones 444 KiB + macoslinux 312 KiB + temas 132 KiB) |

O **desfoque foi desligado por padrão por causa dessa medição**. Observação metodológica: o
Picom quase não aparece (5 vs 8 ticks) porque quem executa a convolução é o servidor X —
medir apenas o processo do Picom daria a falsa impressão de custo zero.

## 5. Defeitos encontrados pelos testes (e corrigidos)

**Do R3 (já existiam):**

1. Desktop **preto** (nenhum wallpaper era aplicado).
2. **Relógio invisível**: usava `time1_font_color`, chave que não existe no Tint2 17.
3. Ícones do Dock **genéricos** (`system-file-manager`/`utilities-terminal` não existem no tema).
4. `menu.xml` padrão dependia de `obamenu`, `obconf`, `x-www-browser` e
   `/var/lib/openbox/debian-menu.xml` (ausentes): entradas mortas e erro no log.
5. `W-e` chamava **Konqueror**; `Print` chamava `scrot` sem o pacote.
6. Sem o `nm-applet` e sem nenhum indicador de rede/áudio.
7. Mensagem `openbox-xdg-autostart requires PyXDG` — **não corrigida de propósito**: é
   inofensiva e corrigi-la exigiria Python.

**Meus, descobertos durante a implementação/testes:**

8. Tint2: `button = new` + `button_text` **não renderiza** → todos os itens viraram executores.
9. Sem item de espaço livre no Tint2 → relógio/volume colados à esquerda → barra de tarefas vazia como espaçador.
10. Executores de ícone imprimiam uma 2ª linha → texto "Mac OS Linux" ao lado dos ícones.
11. `ShowMenu` com `x=9999` **não abre o menu** (fora da tela) → `x=-1` (alinha à direita).
12. **Ordem do `menu.xml`**: o Openbox resolve referências na leitura; "Sessão", "Aplicativos" e
    "Centro de Controle" sumiam do menu do botão direito. Menus reordenados + teste automático.
13. Dock com **itens duplicados** e ícones genéricos → sobreposição de `pcmanfm.desktop` e
    `lxterminal.desktop` em `/usr/local/share/applications` e Dock apontando para eles.
14. **Cantos pretos** nos menus com `corner-radius` no xrender (medido: pixel `(0,0,0)`) → menus
    excluídos do arredondamento por `window_type = 'popup_menu'` (a 1ª tentativa,
    `override_redirect`, não casava: menus do Openbox não são override-redirect).
15. `Super+←/→` com `height=100%` **cobria o Dock** → `MaximizeVert` + largura.
16. O log da interface era **inundado por avisos do Imlib2** e crescia sem limite (fica em RAM
    no live) → saída do tint2 descartada; só o erro real é registrado, filtrado.
17. Uma falha do tint2 ficava **invisível** no log → agora registrada com o motivo.
18. `x-terminal-emulator` resolvia para outro terminal quando havia mais de um instalado →
    wrapper `macoslinux-terminal`.
19. A tela de login dependia do tema `Adwaita-dark` (pacote que não está na lista) →
    `/etc/gtk-3.0/settings.ini` com `prefer-dark` (sem pacote extra).
20. Bug de código: o `appmenu` calculava o nome traduzido mas não o usava.
21. `shellcheck`: 3 ocorrências de `A && B || C` e 1 `SC2155` — corrigidas.
22. **Premissa falsa minha**: escrevi que o backend xrender "não tem blur". Medi: tem. Corrigi
    a documentação e o comentário do Picom, e o desfoque virou opção explícita.
23. Uma captura que eu ia anexar (barra 1024×768) estava **vazia** (169 bytes); foi só
    verificar o arquivo para descobrir — o X de teste não tinha gerenciador de janelas.

## 6. Artefatos de teste (NÃO são defeitos do produto)

* O sandbox foi **restaurado de snapshot** algumas vezes e **encerra os processos de cada
  chamada** — daí vieram quedas do X, "barra sumiu" e o Dock sem reserva de espaço em alguns
  testes. Cada ocorrência foi investigada e confirmada como do ambiente antes de ser descartada.
* O `bamfdaemon` guardou em cache a lista de `.desktop` e não via o diretório recém-criado;
  em boot real o diretório já existe antes da sessão.
* O `pkill -f ':97'` casou com a linha de comando do próprio shell de teste e o encerrou.
* Uma única falha do Picom com o perfil `safe` na 1ª execução da bateria, **não reproduzida**
  em 18 execuções seguidas (6 rodadas × 3 perfis) nem nas 3 execuções completas posteriores.
  Foi adicionada uma pausa entre perfis no teste. Registrada como ocorrência isolada.
* Nome "Ubuntu" no seletor do login e `[language_code]` vêm do `01_ubuntu.conf` do sandbox.

## 7. O que NÃO foi testado

* **Construção do ISO (`lb build`) e boot** (BIOS/UEFI, ISOLINUX, live-config, autologin).
* **Hardware real**: Core 2 Duo E7500, Intel G41 (i915/crocus), desempenho, temperatura.
* **Picom 12.5** — só o 10.2 foi exercitado. O fallback automático para `safe`/sem compositor
  cobre a hipótese de recusa de opção, mas isso não foi simulado com o 12.5.
* **Instalação dos pacotes novos no Trixie**: `feh`, `libnotify-bin`, `pulseaudio-utils`,
  `dbus-x11`, `librsvg2-common` não foram confirmados individualmente (`xdotool`, `scrot`,
  `brightnessctl` foram; `dunst`/`fonts-inter` constam no Trixie). Use `scripts/check-ui-packages.sh`.
* **Wi-Fi, lista de redes, `nmtui-connect`, status de rede**: o sandbox não tem NetworkManager
  (só o ramo "indisponível" foi exercitado).
* **Brilho**: sem backlight no sandbox (o item é omitido por design; o ramo ativo não foi exercitado).
* **Desligar/Reiniciar/Encerrar sessão** (`macoslinux-ctl power`): não executados; dependem de
  permissão do usuário live (`sudo`/logind).
* **Captura de tela por `scrot`** (tecla Print) e **teclas de mídia**: o código existe e o
  `scrot` está instalado, mas a captura em si não foi exercitada.
* **Tema claro nos apps já abertos** (limitação do GTK), **PCManFM no tema claro**.
* Autologin do live e a tela de login **na sessão real** (só o greeter em modo de teste).
* Perfil de energia/estabilidade de longa duração (horas de uso).

## 8. Como reproduzir

```sh
sh scripts/test-interface.sh          # bateria automatizada (usa Xvfb se existir)
NO_X=1 sh scripts/test-interface.sh   # só os testes estáticos
sh scripts/check-ui-packages.sh       # num Debian 13, antes do lb build
macoslinux-ctl doctor                 # na sessão: componentes, ferramentas e log
```


---

# Atualização UI R2 / Mac OS Linux 1.0.0

A bateria acima documenta a UI R1. Para a UI R2 foram acrescentadas fontes C/GTK3 e CSS GTK próprios, wrappers, atalhos e um app Configurações. **Essa nova aplicação ainda não está validada em execução.**

| Verificação | Estado | Observação |
|---|---|---|
| Estrutura de fonte C/GTK3 | presente | `apps/macoslinux-ui.c` |
| Wrapper do Centro de Controle | presente | chama `--control` |
| Wrapper de Configurações | presente | chama `--settings` |
| Tema GTK3 | presente | `gtk.css` e `gtk-dark.css` |
| Integração dos comandos | fonte presente | usa `macoslinux-ctl`, `nmcli`, `wpctl/pactl`, `dunstctl`, `pavucontrol` e `xrandr` |
| Compilação C/GTK3 | pendente | ambiente de preparação não tem `libgtk-3-dev` |
| Teste visual em X/Wayland | pendente | precisa rodar após `make ui-build` |
| Nova ISO 1.0.0 | pendente | precisa `sudo lb build` |
| Teste no Core 2 Duo / G41 | pendente | a ISO 0.1.0 anterior foi a que iniciou no hardware |

Não confundir a validação anterior da UI R1 com a nova aplicação GTK3. Os resultados de 78 testes descritos na primeira parte pertencem ao código R1 e não certificam a UI 1.0.0.
