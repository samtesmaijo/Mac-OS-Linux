#!/bin/sh
# Testes da interface do Mac OS Linux 1.0.0 / Glass Horizon. Reproduzível no computador de
# desenvolvimento. NÃO altera o sistema: usa um HOME temporário e um X virtual.
#
#   sh scripts/test-interface.sh            # estáticos + (se houver Xvfb) testes com X
#   NO_X=1 sh scripts/test-interface.sh     # só estáticos
#
# Dependências opcionais: shellcheck, xmllint, desktop-file-validate, Xvfb,
# openbox, picom, tint2, python3 (apenas para um teste de ordem dos menus).
LC_ALL=C.UTF-8; export LC_ALL
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
INC="$ROOT/config/includes.chroot"
PASS=0; FAIL=0; SKIP=0
ok()   { PASS=$((PASS + 1)); printf '  [ok]    %s\n' "$1"; }
bad()  { FAIL=$((FAIL + 1)); printf '  [FALHA] %s\n' "$1"; }
skip() { SKIP=$((SKIP + 1)); printf '  [pulou] %s\n' "$1"; }
have() { command -v "$1" >/dev/null 2>&1; }
section() { printf '\n== %s\n' "$1"; }

section "1. Scripts (sh -n e shellcheck)"
for f in "$INC"/usr/bin/macoslinux-* "$INC"/usr/lib/macoslinux/common.sh \
         "$INC"/etc/skel/.config/openbox/autostart "$ROOT"/scripts/*.sh "$ROOT/auto/config"; do
    [ -f "$f" ] || continue
    n="${f#"$ROOT"/}"
    first=$(head -n 1 "$f")
    if printf '%s' "$first" | grep -q 'python'; then
        pycache=$(mktemp -d)
        if PYTHONPYCACHEPREFIX="$pycache" python3 -m py_compile "$f" 2>/dev/null; then ok "sintaxe (python3) $n"; else bad "sintaxe (python3) $n"; fi
        rm -rf "$pycache"
        continue
    fi
    interp="sh"   # respeita o shebang (ex.: check-host.sh é bash)
    if printf '%s' "$first" | grep -q bash; then interp="bash"; fi
    if "$interp" -n "$f" 2>/dev/null; then ok "sintaxe ($interp) $n"; else bad "sintaxe ($interp) $n"; fi
    if have shellcheck; then
        if shellcheck -s "$interp" -x -e SC1091 "$f" >/dev/null 2>&1; then ok "shellcheck $n"; else bad "shellcheck $n"; fi
    fi
done
have shellcheck || skip "shellcheck não instalado"

section "1b. Aplicativo GTK3 nativo"
if [ -f "$ROOT/apps/macoslinux-ui.c" ] && grep -q 'build_launcher_window' "$ROOT/apps/macoslinux-ui.c"; then
    ok "fonte C inclui Configurações, Central de Controle e launcher"
else
    bad "fonte C/GTK3 incompleta"
fi
if have pkg-config && pkg-config --exists gtk+-3.0; then
    if cc -std=c11 -Wall -Wextra -Wno-deprecated-declarations $(pkg-config --cflags gtk+-3.0) -fsyntax-only "$ROOT/apps/macoslinux-ui.c" >/dev/null 2>&1; then
        ok "sintaxe C/GTK3"
    else
        bad "sintaxe C/GTK3"
    fi
else
    skip "headers GTK3 ausentes no host; compilação real será feita por make ui-build"
fi

section "2. Permissões de execução"
for f in "$INC"/usr/bin/macoslinux-*; do
    if [ -x "$f" ]; then ok "executável ${f#"$ROOT"/}"; else bad "sem bit de execução ${f#"$ROOT"/}"; fi
done

section "3. XML do Openbox"
if have xmllint; then
    for f in rc.xml menu.xml; do
        if xmllint --noout "$INC/etc/skel/.config/openbox/$f" 2>/dev/null; then ok "$f bem-formado"; else bad "$f malformado"; fi
    done
else skip "xmllint ausente"; fi
# O Openbox resolve referências de menu na leitura: definir ANTES de referenciar.
if have python3; then
    if python3 - "$INC/etc/skel/.config/openbox/menu.xml" <<'PY'
import re, sys
s = re.sub(r'<!--.*?-->', '', open(sys.argv[1], encoding='utf-8').read(), flags=re.S)
builtin = {'client-list-combined-menu', 'client-send-to-menu', 'client-menu', 'client-list-menu', 'root-menu'}
defined, bad = set(), []
for m in re.finditer(r'<menu id="([^"]+)"([^>]*?)(/?)>', s):
    mid, attrs, sc = m.groups()
    if sc and 'label=' not in attrs and 'execute=' not in attrs:
        if mid not in defined and mid not in builtin:
            bad.append(mid)
    else:
        defined.add(mid)
sys.exit(1 if bad else 0)
PY
    then ok "menus definidos antes de referenciados"; else bad "menu referenciado antes de ser definido (a entrada some em silêncio)"; fi
else skip "python3 ausente (teste de ordem dos menus)"; fi

section "4. Arquivos .desktop"
if have desktop-file-validate; then
    for f in "$INC"/usr/share/applications/macoslinux-*.desktop "$INC"/usr/local/share/applications/*.desktop; do
        [ -f "$f" ] || continue
        if desktop-file-validate "$f" >/dev/null 2>&1; then ok "desktop ${f#"$ROOT"/}"; else bad "desktop ${f#"$ROOT"/}"; fi
    done
else skip "desktop-file-validate ausente"; fi
for pair in "macoslinux-settings:macoslinux-settings" "macoslinux-control-center:macoslinux-control-center" "macoslinux-apps:macoslinux-launcher"; do
    desktop=${pair%%:*}; executable=${pair#*:}
    if grep -q "^Exec=$executable\([[:space:]]\|$\)" "$INC/usr/share/applications/$desktop.desktop" && [ -x "$INC/usr/bin/$executable" ]; then
        ok "$desktop.desktop -> $executable"
    else
        bad "$desktop.desktop sem executável correspondente"
    fi
done
for f in "$INC"/etc/skel/.config/plank/dock1/launchers/*.dockitem; do
    l=$(sed -n 's|^Launcher=file://||p' "$f")
    if [ -f "$INC$l" ]; then ok "dockitem $(basename "$f") -> $(basename "$l")"; else bad "dockitem $(basename "$f") aponta para arquivo inexistente: $l"; fi
done

section "5. Modelos (tint2, Plank, dunst): 2 temas x 3 transparências"
TMPH=$(mktemp -d)
for theme in dark light; do
    for tr in glass reduced solid; do
        mkdir -p "$TMPH/.config/macoslinux"
        printf 'THEME=%s\nTRANSPARENCY=%s\n' "$theme" "$tr" >"$TMPH/.config/macoslinux/ui.conf"
        res=$(HOME="$TMPH" XDG_CONFIG_HOME="$TMPH/.config" ML_SHARE="$INC/usr/share/macoslinux" MACOSLINUX_LIB="$INC/usr/lib/macoslinux" sh -c '
            . "$MACOSLINUX_LIB/common.sh" || exit 1
            for t in tint2.tpl plank-dock.theme.tpl dunstrc.tpl; do
                ml_render "$ML_SHARE/templates/$t" "$HOME/out-$t" || { echo "falhou:$t"; exit 1; }
            done; echo certo')
        if [ "$res" = certo ]; then ok "render $theme/$tr"; else bad "render $theme/$tr ($res)"; fi
    done
done
rm -rf "$TMPH"
if [ -f "$INC/usr/share/macoslinux/themes/dark.conf" ] && [ -f "$INC/usr/share/macoslinux/themes/light.conf" ]; then ok "tokens dos dois temas presentes"; else bad "tokens de tema ausentes"; fi
for t in MacOSLinux-Dark MacOSLinux-Light; do
    d="$INC/usr/share/themes/$t/openbox-3"
    if [ -f "$d/themerc" ] && [ -f "$d/close.xbm" ] && [ -f "$d/max.xbm" ] && [ -f "$d/iconify.xbm" ]; then ok "tema Openbox $t completo"; else bad "tema Openbox $t incompleto"; fi
done

section "6. GTK3 UI — fontes, wrappers e tema"
UI_SRC="$ROOT/apps/macoslinux-ui.c"
for f in \
    "$INC/usr/bin/macoslinux-control-center" \
    "$INC/usr/bin/macoslinux-settings" \
    "$INC/usr/bin/macoslinux-launcher" \
    "$INC/usr/share/applications/macoslinux-control-center.desktop" \
    "$INC/usr/share/applications/macoslinux-settings.desktop" \
    "$INC/usr/share/themes/MacOSLinux/index.theme" \
    "$INC/usr/share/themes/MacOSLinux/gtk-3.0/gtk.css" \
    "$INC/usr/share/themes/MacOSLinux/gtk-3.0/gtk-dark.css"; do
    if [ -s "$f" ]; then ok "presente $(basename "$f")"; else bad "ausente/vazio: ${f#"$ROOT"/}"; fi
done
if [ -s "$UI_SRC" ] && grep -q 'gtk_application_new' "$UI_SRC" && grep -q 'build_settings_window' "$UI_SRC" && grep -q 'build_control_window' "$UI_SRC" && grep -q 'build_launcher_window' "$UI_SRC"; then
    ok "fonte GTK3 inclui Centro de Controle, Configurações e Launcher"
else bad "fonte GTK3 incompleta"; fi
if grep -q 'read_cpu_model(void)' "$UI_SRC" && grep -q 'read_memory_total(void)' "$UI_SRC" && ! grep -q 'read -p ' "$UI_SRC"; then
    ok "informações de hardware lidas com APIs e fallback POSIX"
else bad "fonte GTK3 contém leitura de hardware/terminal não portátil"; fi
if grep -q '/usr/lib/macoslinux/macoslinux-ui-native --control' "$INC/usr/bin/macoslinux-control-center" && grep -q '/usr/lib/macoslinux/macoslinux-ui-native --settings' "$INC/usr/bin/macoslinux-settings" && grep -q '/usr/lib/macoslinux/macoslinux-ui-native --launcher' "$INC/usr/bin/macoslinux-launcher"; then
    ok "wrappers chamam o executável GTK3 nativo nos três modos"
else bad "wrappers GTK3 apontam para modo/incorreto"; fi
if grep -q 'UI_INSTALL := config/includes.chroot/usr/lib/macoslinux/macoslinux-ui-native' "$ROOT/Makefile" && grep -q 'install -m 0755' "$ROOT/Makefile"; then
    ok "Makefile compila e instala o executável GTK3 em caminho único"
else bad "destino de instalação do executável GTK3 ausente/incorreto"; fi
if grep -q 'bluetooth) cmd_bluetooth' "$INC/usr/bin/macoslinux-ctl" && grep -q 'rfkill unblock bluetooth' "$INC/usr/bin/macoslinux-ctl"; then
    ok "backend Bluetooth integrado via rfkill"
else bad "backend Bluetooth ausente/incompleto"; fi
if ! grep -Eq '^(python3|python3-gi|gir1.2-gtk-3.0)$' "$ROOT/config/package-lists/macoslinux-ui.list.chroot"; then
    ok "interface principal não adiciona runtime Python/GTK duplicado"
else bad "dependência Python inesperada na lista GTK3 nativa"; fi
if grep -q 'gtk-theme-name=MacOSLinux' "$INC/etc/skel/.config/gtk-3.0/settings.ini" && grep -q 'theme-name=MacOSLinux' "$INC/etc/lightdm/lightdm-gtk-greeter.conf"; then
    ok "tema MacOSLinux é padrão no usuário e no greeter"
else bad "tema GTK3 não configurado em todos os defaults"; fi
if grep -q 'key="W-c"' "$INC/etc/skel/.config/openbox/rc.xml" && grep -q 'key="W-i"' "$INC/etc/skel/.config/openbox/rc.xml"; then
    ok "atalhos Super+C e Super+I presentes"
else bad "atalhos do Centro de Controle/Configurações ausentes"; fi
if grep -q -- '--architecture amd64' "$ROOT/auto/config" && grep -q -- '--binary-image iso-hybrid' "$ROOT/auto/config" && grep -q -- '--debian-installer none' "$ROOT/auto/config"; then
    ok "auto/config usa opções recentes de Live-Build"
else bad "auto/config contém opções antigas/incompletas"; fi

section "7. Controle de entrada inválida (macoslinux-ctl)"
for args in "theme azul" "transparency x" "motion x" "blur x" "volume set abc" "dock size 99" "menu invalid"; do
    # shellcheck disable=SC2086
    MACOSLINUX_LIB="$INC/usr/lib/macoslinux" ML_SHARE="$INC/usr/share/macoslinux" HOME="$(mktemp -d)" sh "$INC/usr/bin/macoslinux-ctl" $args >/dev/null 2>&1
    rc=$?
    if [ "$rc" -eq 2 ]; then ok "rejeita: macoslinux-ctl $args"; else bad "não rejeitou (rc=$rc): macoslinux-ctl $args"; fi
done

if [ -n "$NO_X" ]; then
    skip "testes com X desativados (NO_X=1)"
elif have Xvfb && have openbox && have picom && have tint2 && have xprop; then
    section "8. Com X virtual (Xvfb :98)"
    rm -f /tmp/.X98-lock /tmp/.X11-unix/X98
    Xvfb :98 -screen 0 1366x768x24 +extension Composite +extension RANDR -nolisten tcp >/dev/null 2>&1 &
    XPID=$!
    n=0; while [ $n -lt 25 ] && ! DISPLAY=:98 xprop -root _NET_SUPPORTED >/dev/null 2>&1; do sleep 0.3; n=$((n + 1)); done
    if DISPLAY=:98 xprop -root _NET_SUPPORTED >/dev/null 2>&1; then
        export DISPLAY=:98
        for cfg in macoslinux macoslinux-lite macoslinux-safe macoslinux-blur; do
            picom --config "$INC/etc/xdg/picom/$cfg.conf" >/dev/null 2>&1 &
            P=$!; sleep 1.5
            if kill -0 "$P" 2>/dev/null; then ok "picom inicia com $cfg.conf"; else bad "picom NÃO inicia com $cfg.conf"; fi
            kill "$P" 2>/dev/null; wait "$P" 2>/dev/null
            sleep 1   # deixa o X liberar a seleção de compositor antes do próximo perfil
        done
        TH=$(mktemp -d); mkdir -p "$TH/.config/openbox"
        cp "$INC/etc/skel/.config/openbox/rc.xml" "$INC/etc/skel/.config/openbox/menu.xml" "$TH/.config/openbox/"
        # o tema precisa estar visível ao Openbox: usa XDG_DATA_DIRS apontando para o projeto
        OBLOG=$(mktemp)
        XDG_DATA_DIRS="$INC/usr/share:/usr/share" HOME="$TH" openbox --config-file "$TH/.config/openbox/rc.xml" >"$OBLOG" 2>&1 &
        O=$!; sleep 2
        if kill -0 "$O" 2>/dev/null; then ok "openbox carrega rc.xml e menu.xml"; else bad "openbox encerrou ao carregar"; fi
        if grep -qiE 'error|failed|invalid|unable' "$OBLOG"; then bad "openbox registrou erro: $(grep -iE 'error|failed|invalid|unable' "$OBLOG" | head -1)"; else ok "log do openbox sem erros"; fi
        kill "$O" 2>/dev/null; wait "$O" 2>/dev/null; rm -rf "$TH" "$OBLOG"
        for theme in dark light; do
            TH=$(mktemp -d); mkdir -p "$TH/.config/macoslinux"
            printf 'THEME=%s\n' "$theme" >"$TH/.config/macoslinux/ui.conf"
            HOME="$TH" XDG_CONFIG_HOME="$TH/.config" ML_SHARE="$INC/usr/share/macoslinux" MACOSLINUX_LIB="$INC/usr/lib/macoslinux" sh -c \
                '. "$MACOSLINUX_LIB/common.sh"; ml_render "$ML_SHARE/templates/tint2.tpl" "$HOME/t.rc"'
            tint2 -c "$TH/t.rc" >"$TH/t.log" 2>&1 &
            T=$!; sleep 2
            if kill -0 "$T" 2>/dev/null; then ok "tint2 inicia com o tema $theme"; else bad "tint2 NÃO inicia com o tema $theme"; fi
            # o tint2 só descarrega o log (com buffer) ao sair: encerra ANTES de contar
            kill "$T" 2>/dev/null; wait "$T" 2>/dev/null
            n=$(grep -c "Creating executor" "$TH/t.log")
            if [ "$n" -ge 8 ]; then ok "tint2 ($theme) criou $n executores (esperado 8)"; else bad "tint2 ($theme) criou só $n executores (esperado 8)"; fi
            rm -rf "$TH"
        done
    else
        bad "Xvfb não respondeu"
    fi
    kill "$XPID" 2>/dev/null; wait "$XPID" 2>/dev/null
else
    skip "testes com X: faltam Xvfb/openbox/picom/tint2/xprop"
fi

printf '\n== Resultado: %d ok, %d falha(s), %d pulado(s)\n' "$PASS" "$FAIL" "$SKIP"
[ "$FAIL" -eq 0 ]
