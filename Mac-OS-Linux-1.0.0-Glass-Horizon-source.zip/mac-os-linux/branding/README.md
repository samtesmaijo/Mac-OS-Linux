# Branding assets

Original Mac OS Linux logo, wallpapers, icons, fonts, and sounds will be created here. Do not copy Apple's logo, proprietary icons, wallpapers, or system sounds.
