# Pesquisa de interface — Mac OS Linux 1.0.0

Data da pesquisa: 17 de novembro de 2026.  
Objetivo: extrair princípios de design e referências de implementação para um desktop Linux leve, não reproduzir arquivos proprietários.

## 1. Direção de design observada no macOS 27 Golden Gate

A página oficial da Apple descreve refinamentos do Liquid Glass: maior uniformidade de refração, contraste e legibilidade; barras de ferramentas mais consistentes; barras laterais integradas às bordas; formas de janela e ícones da barra de menus revistos; e ajuste do material entre uma aparência mais transparente e uma mais tonalizada.

Para o Mac OS Linux, esses pontos foram convertidos em requisitos independentes:

- **Legibilidade primeiro:** transparência nunca pode apagar texto, rótulos ou controles. O contraste precisa sobreviver a wallpapers claros e escuros.
- **Hierarquia de superfícies:** janela principal, cartões, controles e estados ativos precisam ter profundidades distintas, mas sem sombras exageradas.
- **Bordas como separadores:** contornos claros e finos devem delimitar superfícies translúcidas.
- **Transparência configurável:** três níveis do projeto — vidro, reduzida e sólida — em vez de uma única opacidade obrigatória.
- **Consistência entre apps:** botões, escalas, switches, listas, barras de título e cartões usam a mesma linguagem.
- **Movimento discreto:** animações curtas e desligáveis. Blur é opcional, porque é caro no hardware Core 2 Duo / G41.

A implementação atual é uma interpretação GTK3 com fundos alfa e realces em CSS. Ela não implementa refração óptica real, materiais privados, nem o compositor do macOS.

## 2. Projetos Linux examinados

### WhiteSur GTK Theme

Repositório: https://github.com/vinceliuice/WhiteSur-gtk-theme  
Licença indicada pelo GitHub: MIT.  
O projeto é útil para estudar a organização de temas GTK, fontes Sass, variantes claro/escuro, cores, scripts de geração e instalação. A árvore 1.0.0 não incorpora seus CSS, SVGs, scripts ou imagens.

### WhiteSur Icon Theme

Repositório: https://github.com/vinceliuice/WhiteSur-icon-theme  
Licença indicada pelo GitHub: GPL-3.0.  
Foi examinado como referência de organização de ícones e variantes. Os ícones do Mac OS Linux continuam próprios/Adwaita neste build; o redesenho dos logos de apps será uma etapa separada.

### McMojave KDE Theme

Repositório: https://github.com/vinceliuice/McMojave-kde  
Licença declarada pelo projeto: GNU GPL v3.  
A estrutura mostra a separação entre decoração de janelas, Kvantum, esquemas de cor, temas Plasma e configurações Look-and-Feel. Não foi incorporada porque o sistema não usa KDE Plasma.

### macOS Theme for Linux

Repositório: https://github.com/MarbleLabs1/macos-theme-for-linux  
O instalador combina componentes como WhiteSur GTK, ícones, Plank, cursores e wallpapers, e declara licença MIT para seu próprio repositório. Os componentes que ele instala possuem licenças próprias; a licença do instalador não substitui a de cada dependência.

## 3. Decisão de arquitetura

O alvo tem 1,9 GiB de RAM, então a 1.0.0 preserva Xorg + Openbox + Tint2 + Plank + Picom/XRender + dunst. O Centro de Controle, Configurações e Launcher são um único executável C/GTK3, iniciado por três wrappers:

- `macoslinux-control-center` → `/usr/lib/macoslinux/macoslinux-ui-native --control`
- `macoslinux-settings` → `/usr/lib/macoslinux/macoslinux-ui-native --settings`
- `macoslinux-launcher` → `/usr/lib/macoslinux/macoslinux-ui-native --launcher`

O mesmo executável também tem o modo `--launcher`, que consulta os aplicativos instalados por GIO e cria uma grade pesquisável baseada nos arquivos `.desktop`. A aplicação delega as mudanças de estado ao script `macoslinux-ctl`, que continua sendo a camada de ações reais. Isso evita duplicar a lógica de rede, volume, tema, dock e notificações na interface gráfica.

## 4. Componentes de UI 1.0.0

- **Centro de Controle:** cartões para Wi-Fi, Bluetooth, Foco/Não Perturbe, Aparência e Configurações; escala de volume; ações de áudio; controles de brilho somente quando existe dispositivo de backlight.
- **Configurações:** Geral, Aparência, Dock, Rede, Som, Tela, Notificações e Sobre.
- **Launcher:** grade pesquisável dos aplicativos instalados, com nomes e ícones fornecidos pelos arquivos `.desktop` e pelo tema do sistema.
- **Aparência:** modo claro/escuro; níveis de transparência; movimento reduzido; desfoque experimental.
- **Dock:** ocultação automática, zoom e tamanhos 36/46/56.
- **Rede:** estado do adaptador Wi-Fi e atalho para `nm-connection-editor`.
- **Som:** escala de volume, mudo e `pavucontrol`.
- **Launcher:** grade pesquisável com `GAppInfo`, ícones do tema GTK e inicialização via GIO.

## 5. Limites e próximo ciclo

- A nova aplicação precisa ser compilada no host com `build-essential`, `pkg-config` e `libgtk-3-dev` (`make ui-build`).
- Os testes estáticos desta árvore passaram com 72 aprovações e zero falhas; os testes gráficos e a compilação GTK3 continuam pendentes.
- A aplicação GTK3 nova ainda não foi validada em execução nem na ISO 1.0.0.
- O painel usa transparência e realces; o desfoque não é ligado por padrão.
- Algumas ações dependem de hardware/serviços: Wi-Fi precisa de adaptador e NetworkManager; brilho precisa de backlight; som precisa de PipeWire/PulseAudio compatível; resolução depende de Xorg/xrandr.
- A próxima etapa visual será criar ícones/logos originais para cada aplicativo. Não usar logos, símbolos de aplicativos, wallpapers ou fontes da Apple nessa edição.

## 6. Fontes

- Apple — macOS 27 Golden Gate: https://images.apple.com/os/macos/
- Apple Developer — Platforms State of the Union, WWDC26: https://developer.apple.com/videos/play/wwdc2026/102/
- WhiteSur GTK: https://github.com/vinceliuice/WhiteSur-gtk-theme
- WhiteSur icons: https://github.com/vinceliuice/WhiteSur-icon-theme
- McMojave KDE: https://github.com/vinceliuice/McMojave-kde
- macOS Theme for Linux: https://github.com/MarbleLabs1/macos-theme-for-linux
