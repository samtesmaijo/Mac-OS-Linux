# Mac OS Linux 1.0.0 — Glass Horizon

**Versão do projeto:** 1.0.0 (prévia privada de desenvolvimento)  
**Arquitetura:** amd64 / x86_64  
**Base:** Debian 13 Trixie, montado com `live-build`  
**Alvo principal:** Intel Core 2 Duo E7500 + Intel G41 / i915, 1,9 GiB RAM

Mac OS Linux é uma distribuição independente baseada no kernel Linux e nos pacotes Debian. O projeto mantém identidade visual, configuração do sistema, shell de desktop, aplicativos próprios e processo de build. Não é um kernel novo nem uma distribuição macOS.

O usuário já construiu a ISO 0.1.0 anterior e confirmou que ela inicia no Core 2 Duo E7500 com Intel G41. **Esta árvore 1.0.0 é uma atualização de código-fonte:** a nova aplicação GTK3 ainda precisa ser compilada, incorporada em uma nova ISO e testada novamente no computador real.

## O que muda na 1.0.0

- **Centro de Controle GTK3:** painel flutuante com cartões de Wi-Fi, Foco/Não Perturbe, aparência, volume e acesso às Configurações.
- **Configurações do Sistema GTK3:** páginas Geral, Aparência, Dock, Rede, Som, Tela, Notificações e Sobre.
- **Launcher GTK3:** biblioteca de aplicativos com busca e abertura dos aplicativos instalados via GIO, em grade de ícones.
- **Tema GTK3 MacOSLinux:** folhas de estilo próprias claro/escuro, cantos arredondados, superfícies suaves, contraste e destaques discretos.
- **Ações reais:** os controles reaproveitam `macoslinux-ctl`, NetworkManager, `rfkill`, PipeWire/WirePlumber, `pavucontrol`, `xrandr` e `dunst` já usados pelo sistema.
- **Atalhos:** `Super+C` abre o Centro de Controle; `Super+I` abre Configurações.
- **Base leve preservada:** Xorg + Openbox + Tint2 + Plank + Picom/XRender + dunst. Não foi introduzido GNOME, KDE, Electron ou Python em tempo de execução.

O visual é uma interpretação original inspirada em princípios de interfaces translúcidas modernas: camadas, transparência moderada, reflexos sutis, contornos claros e boa legibilidade. O efeito não é uma implementação do material proprietário da Apple nem reproduz refração física real. O desfoque continua opcional porque medições anteriores mostraram custo alto em máquinas modestas.

## Pesquisa de interface

As decisões de UI estão documentadas em [`docs/MACOS27-RESEARCH.md`](docs/MACOS27-RESEARCH.md). Foram estudados os refinamentos publicados para macOS 27 Golden Gate e projetos Linux como WhiteSur GTK, WhiteSur Icon Theme e McMojave KDE. **Nenhum código ou asset desses temas foi incorporado nesta atualização:** o C, CSS, os temas e a marca desta versão são próprios do Mac OS Linux.

## Arquitetura e hardware

O sistema usa o kernel Debian `linux-image-amd64`, systemd, Xorg, Openbox, Tint2, Plank, Picom com backend XRender, PCManFM, LXTerminal, NetworkManager e PipeWire. A interface GTK3 é pequena e compartilha o backend shell `macoslinux-ctl`.

O Core 2 Duo E7500 / G41 tem memória limitada. O build usa bootstrap `minbase`, recomendações APT desativadas e efeitos pesados desligados por padrão. A compatibilidade AMD64 e a presença de `i915` não substituem os testes reais de vídeo, áudio, rede e USB.

## Compilar no Zorin OS / Ubuntu

No computador de desenvolvimento, instale as ferramentas de compilação GTK3:

```bash
sudo apt update
sudo apt install -y build-essential pkg-config libgtk-3-dev
```

O Live-Build utilizado neste projeto precisa aceitar a sintaxe de Debian Trixie. A versão usada no processo de desenvolvimento é `1:20250505+deb13u1`.

Na raiz do projeto:

```bash
make check-host
make prepare-iso
```

`make prepare-iso` compila `apps/macoslinux-ui.c`, instala o binário como `config/includes.chroot/usr/lib/macoslinux/macoslinux-ui-native` (sem sobrescrever outros arquivos), executa os testes estáticos e gera a configuração do Live-Build. Ele **não** inicia a compilação da ISO.

Depois:

```bash
sudo lb clean
sudo lb build 2>&1 | tee build.log
```

A ISO esperada é `live-image-amd64.hybrid.iso` na raiz do projeto. Verifique-a antes de gravar:

```bash
ls -lh live-image-amd64.hybrid.iso
file live-image-amd64.hybrid.iso
sha256sum live-image-amd64.hybrid.iso
xorriso -indev live-image-amd64.hybrid.iso -report_el_torito plain
```

Faça backup de uma ISO anterior antes de executar uma limpeza ou build na mesma pasta. A gravação de uma ISO em um pendrive apaga o conteúdo do dispositivo; confirme o dispositivo selecionado.

## Testes

```bash
make ui-test
NO_X=1 make ui-test
```

A bateria verifica sintaxe dos scripts, XML do Openbox, arquivos `.desktop`, launchers do Plank, renderização dos temas e comandos inválidos. O build GTK3 é validado separadamente por `make ui-build`, que exige os headers de desenvolvimento GTK3.

**Limite conhecido desta entrega:** o ambiente em que esta árvore foi preparada não tinha `libgtk-3-dev` nem conseguiu atualizar os índices APT, portanto o executável C ainda não foi compilado nem executado aqui. A fonte está incluída e o build deve ser feito no Zorin com as dependências acima. Não trate a UI 1.0.0 como validada até gerar a nova ISO e testar cada controle no hardware real.

## Estrutura relevante

- `apps/macoslinux-ui.c` — aplicação GTK3 (Centro de Controle, Configurações e Launcher)
- `config/includes.chroot/usr/bin/` — wrappers e backend da sessão
- `config/includes.chroot/usr/share/themes/MacOSLinux/` — tema GTK3 próprio
- `config/includes.chroot/etc/skel/.config/openbox/` — menus, atalhos e sessão
- `config/package-lists/` — pacotes da imagem Debian
- `auto/config` — configuração Live-Build compatível com Trixie
- `docs/` — pesquisa, arquitetura, build e relatório de validação
- `backups/r3-original/` — arquivos originais preservados do build R3

## Próximos passos

1. Compilar o binário GTK3 no Zorin e gerar a ISO 1.0.0.
2. Testar Centro de Controle, Configurações, rede, áudio e atalhos no Core 2 Duo.
3. Medir RAM/CPU em repouso; manter blur desligado caso o G41 apresente custo alto.
4. Em uma etapa posterior, criar um conjunto de ícones e logos de aplicativos inteiramente original, mantendo apenas a direção estética geral.
5. Depois dos testes, preparar a edição que não incorpora logos, ícones, wallpapers, fontes ou outros assets da Apple.

## Referências oficiais

- Debian Live Manual: https://live-team.pages.debian.net/live-manual/html/live-manual/index.en.html
- Debian 13 (Trixie): https://www.debian.org/releases/trixie/
- macOS 27 Golden Gate — Apple: https://images.apple.com/os/macos/
