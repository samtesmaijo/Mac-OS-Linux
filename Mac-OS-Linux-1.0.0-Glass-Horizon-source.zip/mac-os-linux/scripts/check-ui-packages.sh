#!/bin/sh
# Verifica se TODOS os pacotes de config/package-lists/*.list.chroot existem no
# repositório configurado do apt. Rode num Debian 13 (Trixie) com 'apt update' feito,
# ANTES de 'lb build'. Um pacote inexistente derruba a construção inteira.
#   sh scripts/check-ui-packages.sh
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
missing=0
for list in "$ROOT"/config/package-lists/*.list.chroot; do
    for pkg in $(grep -v '^[[:space:]]*#' "$list" | tr -s ' \t' '\n'); do
        cand=$(apt-cache policy "$pkg" 2>/dev/null | sed -n 's/^  Candidate: //p')
        if [ -z "$cand" ] || [ "$cand" = "(none)" ]; then
            printf 'FALTA   %-26s (%s)\n' "$pkg" "$(basename "$list")"
            missing=$((missing + 1))
        else
            printf 'ok      %-26s %s\n' "$pkg" "$cand"
        fi
    done
done
# shellcheck source=/dev/null
[ -f /etc/os-release ] && . /etc/os-release && echo "sistema: ${PRETTY_NAME:-?}"
if [ "$missing" -gt 0 ]; then echo "$missing pacote(s) ausente(s): corrija antes de construir."; exit 1; fi
echo "todos os pacotes disponíveis."
