# Mac OS Linux — tema do Dock (Plank 0.11). Tema: @THEME_NAME@. Transparência: @ALPHA@%.
# GERADO a partir de plank-dock.theme.tpl por macoslinux-ctl. Chaves conferidas
# contra /usr/share/plank/themes/Default/dock.theme do Plank 0.11.89.

[PlankTheme]
TopRoundness=14
BottomRoundness=14
LineWidth=1
OuterStrokeColor=255;;255;;255;;46
FillStartColor=@THEME_DOCK_TOP_RGB@;;@ALPHA255@
FillEndColor=@THEME_DOCK_BOT_RGB@;;@ALPHA255@
InnerStrokeColor=255;;255;;255;;14

[PlankDockTheme]
HorizPadding=2.5
TopPadding=1.5
BottomPadding=1.5
ItemPadding=2
IndicatorSize=6
IconShadowSize=0.5
UrgentBounceHeight=1.2
LaunchBounceHeight=0.5
FadeOpacity=1
ClickTime=200
UrgentBounceTime=600
LaunchBounceTime=500
ActiveTime=@MOTION_MS@
SlideTime=@MOTION_MS@
FadeTime=@MOTION_MS@
HideTime=@MOTION_MS@
GlowSize=30
GlowTime=10000
GlowPulseTime=2000
UrgentHueShift=150
ItemMoveTime=@MOTION_MS@
CascadeHide=true
BadgeColor=0;;0;;0;;0
