#!/bin/sh
# Regenera todos os arquivos GERADOS da interface (rodar no computador de
# desenvolvimento, NÃO dentro do ISO). Requer Python 3 + Pillow + NumPy apenas
# para imagens/temas; os modelos de configuração são renderizados em sh puro.
#   sh scripts/build-ui-assets.sh
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
INC="$ROOT/config/includes.chroot"

python3 "$ROOT/branding/generate-assets.py"
python3 "$ROOT/branding/generate-themes.py"

# Fallbacks estáticos (tema escuro, vidro, movimento completo) usados se a
# renderização em runtime falhar: tint2, tema do Plank e dunst.
export ML_SHARE="$INC/usr/share/macoslinux"
HOME=$(mktemp -d)                   # sem ui.conf => padrões
export HOME
export MACOSLINUX_LIB="$INC/usr/lib/macoslinux"
# shellcheck source=/dev/null
. "$MACOSLINUX_LIB/common.sh"
mkdir -p "$INC/etc/xdg/tint2" "$INC/usr/share/plank/themes/MacOSLinux" "$INC/etc/xdg/dunst"
ml_render "$ML_SHARE/templates/tint2.tpl"            "$INC/etc/xdg/tint2/macoslinux.tint2rc"
ml_render "$ML_SHARE/templates/plank-dock.theme.tpl" "$INC/usr/share/plank/themes/MacOSLinux/dock.theme"
ml_render "$ML_SHARE/templates/dunstrc.tpl"          "$INC/etc/xdg/dunst/dunstrc"
rm -rf "$HOME"
echo "fallbacks estáticos renderizados"
