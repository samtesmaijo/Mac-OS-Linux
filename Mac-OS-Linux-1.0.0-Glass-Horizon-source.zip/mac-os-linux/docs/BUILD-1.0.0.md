# Build da ISO — Mac OS Linux 1.0.0 / Glass Horizon

## Requisitos do host Zorin OS / Ubuntu

```bash
sudo apt update
sudo apt install -y build-essential pkg-config libgtk-3-dev
```

O host também precisa de `live-build`, `debootstrap`, `xorriso`, `squashfs-tools` e `grub-common`. Use um Live-Build compatível com as opções atuais da configuração Debian Trixie (`--architecture`, `--binary-image` e `--debian-installer none`).

## Preparar fontes, binário e configuração

Na raiz do projeto:

```bash
make check-host
make prepare-iso
```

`make prepare-iso` compila a aplicação C/GTK3, instala o executável no overlay `config/includes.chroot/`, executa os testes estáticos e gera a configuração do Live-Build. Ele não gera a ISO.

As etapas também podem ser executadas individualmente:

```bash
make ui-build
make ui-test
make configure
```

## Gerar a ISO

Antes de iniciar, feche aplicativos não essenciais. No Core 2 Duo com 1,9 GiB de RAM, o Live-Build pode exigir bastante memória; mantenha espaço livre em disco e swap disponível.

```bash
sudo lb clean
set -o pipefail
sudo lb build 2>&1 | tee build.log
```

## Verificar a imagem

```bash
ls -lh live-image-amd64.hybrid.iso
file live-image-amd64.hybrid.iso
sha256sum live-image-amd64.hybrid.iso
xorriso -indev live-image-amd64.hybrid.iso -report_el_torito plain
```

Confira a presença das entradas BIOS e UEFI. Depois grave em USB com o gravador de imagem do Zorin ou ferramenta equivalente. A gravação sobrescreve o pendrive; confirme o dispositivo selecionado.

## Teste inicial

Use primeiro o modo Live. Não instale no disco interno durante a primeira validação. Verifique boot Legacy/BIOS, tela gráfica, resolução, teclado, mouse USB, Wi-Fi, Bluetooth (se o adaptador existir), áudio e estabilidade. A ISO 0.1.0 anterior já iniciou no Core 2 Duo E7500/Intel G41, mas cada nova ISO precisa de novo teste.

## Limitações conhecidas desta entrega de código-fonte

O host usado para preparar este pacote não possui os headers GTK3 de desenvolvimento. Portanto, a aplicação C não foi compilada nem executada neste ambiente e a nova ISO 1.0.0 ainda não foi produzida aqui. O próprio `make ui-build` verifica a dependência e interrompe com uma instrução clara caso `libgtk-3-dev` esteja ausente.
