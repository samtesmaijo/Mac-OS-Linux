# System architecture

## 1. Distribution foundation

| Layer | Alpha decision | Responsibility |
|---|---|---|
| CPU target | amd64 / x86_64 | First supported desktop architecture |
| Distribution base | Debian 13 Trixie | Signed packages, security updates, hardware enablement |
| Image builder | Debian `live-build` | Reproducible live ISO assembly |
| Kernel | `linux-image-amd64` | Hardware, processes, memory, filesystems |
| Init and services | systemd | Boot and service supervision |
| Display server | Xorg | First graphical session on legacy hardware |
| Window manager | Openbox | Lightweight window placement and focus |
| Temporary panel and dock | Tint2 + Plank | Initial desktop controls pending project-owned shell |
| Graphics stack | i915 + Mesa | Intel integrated graphics and OpenGL userspace |
| Package handling | APT / Debian packages | Alpha installation and security updates |

Debian and the Linux kernel are upstream foundations. Mac OS Linux's own engineering work is the distribution configuration, visual identity, desktop shell, first-party apps, defaults, image pipeline, testing, and release process.

## 2. First target hardware

The first development system is an Intel Core 2 Duo E7500 (2 cores, 2.93 GHz), 1.9 GiB RAM, and Intel 4 Series / G41 integrated graphics (`8086:2e32`). The host reports `i915` as the active kernel driver.

This is a low-memory target. The first image should:

- Avoid GNOME, KDE Plasma, Electron, and heavy compositor effects.
- Start with Xorg + Openbox.
- Use a restrained package list and disable APT recommends in the image build.
- Keep the base package set minimal and avoid parallel source compilation. SquashFS compression uses the host `live-build` default for compatibility; the initramfs is configured for gzip.
- Keep compositing disabled by default until visual and memory tests justify it.

The project must still test graphics acceleration, resolution changes, suspend, video playback, and multi-monitor behavior on real hardware. A detected `i915` module alone does not guarantee every graphical feature works.

## 3. Desktop direction

The desktop will have its own identity; it must not include Apple's proprietary logos, artwork, fonts, or copied interface assets.

Planned project-owned components:

- **Top Bar:** application menu, workspace controls, clock, network, sound, and power status.
- **Dock:** pinned and running applications.
- **Launcher:** grade GTK3 pesquisável construída a partir dos aplicativos `.desktop` instalados via GIO.
- **Control Center:** painel GTK3 rápido para Wi-Fi, Bluetooth, volume, Foco e aparência; páginas extensas ficam no app Configurações.
- **System Settings:** interface GTK3 com páginas Geral, Aparência, Dock, Rede, Som, Tela, Notificações e Sobre.
- **File Manager:** files, locations, removable media, and network shares.
- **Session and lock screen:** consistent login, session, and power controls.

Tint2 and Plank remain lightweight scaffolding for the top bar and Dock. The 1.0.0 GTK3 applications are first-party source surfaces but do not yet replace Tint2/Plank with a fully custom shell. The C/GTK3 source is compiled into one executable (`macoslinux-ui-native`) with `--control`, `--settings` and `--launcher` modes; thin wrappers expose each app to the desktop.

## 4. Build pipeline

1. Inspect the build host and verify live-build tools.
2. Configure the ISO using `auto/config`.
3. Build a minimal live image using Debian packages.
4. Boot the ISO in QEMU or another virtual machine; do not install it on the development computer.
5. Verify boot, keyboard, mouse, graphics, network, and audio.
6. Develop and integrate project-owned shell components.
7. Add an installer and update/recovery process only after the live image is stable.
8. Publish checksums, release notes, known issues, and a tested hardware list.

## 5. Compatibility policy

The first target is 64-bit x86 PCs. Hardware support must be measured, not assumed. The project will record tested GPU, Wi-Fi, Ethernet, audio, USB, and input-device models. Legacy Intel G4x graphics use the kernel `i915` driver; the first desktop uses Xorg to reduce variables during initial bring-up.

## 6. Security and maintenance

- Use Debian security updates and signed repositories.
- Pin build configuration and record package manifests for each ISO.
- Keep build scripts reviewable and fail on errors.
- Do not run build or installer steps as root unless the documented step specifically requires it.
- Do not include proprietary Apple software, assets, or trademarks in the distribution.
