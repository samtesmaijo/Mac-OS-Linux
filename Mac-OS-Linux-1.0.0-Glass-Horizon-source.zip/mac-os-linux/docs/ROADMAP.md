# Roadmap — Mac OS Linux

## Fase 0 — Fundação (concluída)

- [x] Definir identidade, arquitetura inicial e princípios do projeto.
- [x] Registrar o Core 2 Duo E7500 / Intel G41.
- [x] Selecionar Debian 13 + Live-Build com sessão Xorg/Openbox leve.

## Fase 1 — ISO Live inicial (concluída pelo usuário para a versão 0.1.0)

- [x] Construir uma ISO Debian Trixie amd64 com entrada BIOS e UEFI.
- [x] Confirmar que a ISO inicia no Core 2 Duo E7500 / Intel G41.
- [x] Confirmar que a sessão gráfica abre no hardware real.

## Fase 2 — Desktop inicial UI R1 (concluída como base)

- [x] Barra Tint2, Dock Plank, Openbox, Picom/XRender e dunst.
- [x] Temas claro/escuro, wallpapers, ícones de projeto e atalhos.
- [x] Scripts de sessão e backend `macoslinux-ctl`.
- [x] ISO 0.1.0 iniciada pelo usuário no Core 2 Duo.

## Fase 3 — UI 1.0.0 / Glass Horizon (fonte criada; validação pendente)

- [x] Pesquisar refinamentos de macOS 27 e estruturas de temas GTK/Linux.
- [x] Criar tema GTK3 original claro/escuro.
- [x] Criar aplicação C/GTK3 com Centro de Controle, Configurações e Launcher pesquisável.
- [x] Integrar ações com `macoslinux-ctl`, NetworkManager, rfkill, PipeWire, dunst e utilitários existentes.
- [x] Atualizar atalhos, menu do Openbox, launcher do Plank e integração GTK.
- [x] Executar bateria estática: 72 aprovações, zero falhas; compilação e runtime ainda pendentes.
- [ ] Compilar o C/GTK3 no Zorin com `make ui-build`.
- [ ] Rodar `make ui-test` e corrigir erros encontrados.
- [ ] Gerar a ISO 1.0.0 com `sudo lb build`.
- [ ] Testar Centro de Controle, Configurações, rede, som e Dock na ISO.
- [ ] Repetir boot BIOS/UEFI no Core 2 Duo / G41 e medir RAM/CPU.

**Condição de saída:** ISO 1.0.0 inicia no Core 2 Duo e os controles documentados funcionam no hardware disponível.

## Fase 4 — Identidade visual própria (próxima etapa)

- [ ] Criar logos de aplicativos 100% originais, sem reproduzir símbolos da Apple ou de apps Apple.
- [ ] Desenvolver uma família visual consistente de ícones, estados e tamanhos.
- [ ] Criar mais telas nativas para Files, launcher e área de trabalho, conforme o orçamento de RAM.

## Fase 5 — Engenharia de distribuição

- [ ] Definir instalação, atualização, repositório assinado e recuperação.
- [ ] Criar instalador gráfico seguro e fluxo de instalação.
- [ ] Testar em hardware adicional e documentar compatibilidade.

## Fase 6 — Release

- [ ] Testar boot, instalação, atualização, hardware e recuperação.
- [ ] Publicar manifesto de pacotes, checksum, changelog e limitações.
- [ ] Preparar uma versão de distribuição com todos os assets originais e avisos de licenças.
