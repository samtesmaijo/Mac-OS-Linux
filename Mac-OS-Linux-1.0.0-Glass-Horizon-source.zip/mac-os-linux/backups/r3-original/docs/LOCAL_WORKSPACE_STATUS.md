# Estado e limites deste pacote

Este pacote é um **starter de código-fonte e brief de interface**, montado a partir do ZIP R3 que estava guardado na Library e das últimas alterações textuais registradas nesta conversa.

Ele contém os arquivos de base R3 e inclui as alterações conhecidas de interface: Picom, configuração de Tint2, inicialização Openbox, launchers Plank para Arquivos e Terminal, pacote `polkitd` e suporte auxiliar. Também inclui `docs/PROMPT_CLAUDE_MACOS27_INTERFACE.md`.

**Não é uma cópia integral do diretório local mais recente do Zorin.** O ZIP original disponível tinha 17.932 bytes e não continha a ISO de 593 MB nem o tema local completo do ISOLINUX. Por isso, este pacote não inclui `binary.hybrid.iso`, `config/bootloaders/isolinux` do diretório local, `.build`, `chroot`, `binary` ou logs da compilação.

Estado da ISO conforme o log fornecido pelo usuário em 2026-11-08: a imagem `binary.hybrid.iso` foi criada com 593 MB (ISO 9660 bootável; MBR; `filesystem.squashfs`; módulos ISOLINUX `.c32` verificados). O comando `lb build` retornou código 1 posteriormente na etapa auxiliar Zsync porque `binary.hybrid.iso.zsync.xz` já existia. A ISO local foi verificada como arquivo, mas esta cópia ZIP não contém seus bytes.

Para o Claude trabalhar sobre a cópia exata mais recente, o desenvolvedor deve fornecer também os arquivos locais de `config/bootloaders/isolinux` e, se desejar que a ISO seja examinada, `binary.hybrid.iso` separadamente.
